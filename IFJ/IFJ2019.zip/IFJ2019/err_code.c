#include "err_code.h"


int call_error(int code, int specific){


	ERR_CODE type = code;

	switch (type){

	case 1:
		fprintf(stderr,"%d: LEX_ERROR\n", specific);
		break;
	case 2:
		fprintf(stderr,"%d: SYNTAX_ERROR\n",specific);
		break;
	case 3:
		fprintf(stderr,"%d: SEMANTIC_ERROR\n",specific);
		break;
	case 9:
		fprintf(stderr,"%d: ZERO_DIVISION_ERROR\n",specific);
		break;
	case 99:
		fprintf(stderr,"%d: INTERNAL_ERROR\n",specific);
		break;

	}

	return code;

}
