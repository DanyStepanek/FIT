var searchData=
[
  ['methodid',['methodId',['../structAppData.html#af79d9bf119a0591176fce8326a51576b',1,'AppData']]],
  ['methods',['methods',['../structAppData.html#aff38c888b298fdee1c14d5b97b42b64b',1,'AppData']]]
];
