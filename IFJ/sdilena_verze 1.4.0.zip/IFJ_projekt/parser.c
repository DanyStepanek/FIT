#include "parser.h"


void takeToken(){
	for(int i=0; i<5;i++){
		printf("dej mi token\n");
//	while(get_token(file) != 1){
		get_token(file);
	}
}