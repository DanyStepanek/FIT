/******************************************************************** 
 *  About: Main function          									*
 *		   															*
 *		    	 													*
 *																	*
 ********************************************************************
 *	IFJ projekt: "Implementace prekladace                       	*
 *				  imperativniho jazyka IFJ18."      				*
 *	Author(s): Daniel Stepanek (xstepa61)                       	*
 *	Date: 10.11.2018                                            	*
 *	VUT FIT Brno 2BIT                                           	*
 *                                                                  *
 *******************************************************************/
#include<stdio.h>
#include<stdlib.h>

#include "scanner.h"
#include "parser.h"
#include "err_code.h"




int main(int argc,char *argv[]){

	//inicializace struktury pro ukladani nactenych tokenu
	Tlist *t = init_Tlist();
	
	buffer = (char *) malloc(sizeof(char)*100);
	if(buffer == NULL){
		fprintf(stderr,"Buffer allocation failed\n");
		exit(1);
	}

	if(argc == 2){
		file = fopen(argv[1],"r");
		if (file == NULL){
			fprintf(stderr,"The file cannot be opened.\n");
			exit(1);
		}
		syntax();	
			
	}
		//dealokace veskere alokovane pameti pouzite v Tlist
		free_Tlist(t);
		// dealokace pro scanner 
		free(buffer);
		fclose(file);
return 0;
}
