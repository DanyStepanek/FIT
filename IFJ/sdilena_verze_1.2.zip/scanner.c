/* TODO: neurcita velikost poli, viceradkovy komentar,

		desetinna cisla,
		upravit funkci na stringy(pokud chybi druha uvozovka " tak to detekuje jako promennou (isVar())
spoustet jako: ./vystupTest nejakysoubor
*/
#include "scanner.h"



int resize_buffer(char *buffer,int size){
	buffer = realloc(buffer, (sizeof(buffer)+(sizeof(char)*50)));
	size = sizeof(buffer)-1;
	return 0;
}

void sendToken(char *buffer, int t){
	printf("Buffer: ");
	for(int i=0;buffer[i]!='\0';i++)
		printf("%c",buffer[i]);
	printf(", %s",types[t]);
	printf("\n");
	
}


int isKeyWord(char *str){
	if(strcmp("def",str)==0)
		return DEF;
	if(strcmp("do",str)==0)
		return DO;
	if(strcmp("else",str)==0)
		return ELSE;
	if(strcmp("end",str)==0)
		return END;
	if(strcmp("if",str)==0)
		return IF;
	if(strcmp("not",str)==0)
		return NOT;
	if(strcmp("nil",str)==0)
		return NIL;
	if(strcmp("then",str)==0)
		return THEN;
	if(strcmp("while",str)==0)
		return WHILE;
	
	return -1;	//if "str" is not a keyword
}

int operators(int c){
	if(c == '=' || c == '+' || c == '-' || c == '*' || c == '/'){
		buffer[0] = c;
		buffer[1] = '\0';
		sendToken(buffer,4);
		return 1;
	}
	else
		return 0;
}

void others(int c){
	int i = 0;
	while(isalpha(c)){
		buffer[i] = c;
		c = fgetc(file);
		i++;
	}
	buffer[i] = '\0';
	sendToken(buffer,6);	
}

void comments(int c){
	int i = 0;
	
	while((c = fgetc(file)) != '\n'){
		buffer[i] = c;
		i++;
	}
	buffer[i] = '\0';
	sendToken(buffer,5);	
}

void strings(int c){
	int i = 0;
	
	while((c = fgetc(file)) != '"'){
		if(c == '\n')
			break;
		buffer[i] = c;
		i++;
		
	}
	buffer[i++] = '\0';
	sendToken(buffer,2);
	
}

void variables(char *buffer){
	int keyword = -1;

	//keyword checking
	keyword = isKeyWord(buffer);
	enum defaultWords key = keyword;
	
	switch (key){

	case 0:
		buffer = "def";
		break;
	case 1:
		buffer = "do";
		break;
	case 2:
		buffer = "else";
		break;
	case 3:
		buffer = "end";
		break;
	case 4:
		buffer = "if";
		break;
	case 5:
		buffer = "not";
		break;
	case 6:
		buffer = "nil";
		break;
	case 7:
		buffer = "then";
		break;
	case 8:
		buffer = "while";
		break;
	}

	if(keyword == -1 )
		sendToken(buffer,3);
	else
		sendToken(buffer,7);
	
	
}



void read(FILE* file){
	int c = 0;
	int i = 0;
			
	if((c = fgetc(file)) != EOF){
		
		//Condition for numbers
		if(isdigit(c)){
			i = 0;
		
			while(isdigit(c)){
				buffer[i] = c;
				c = fgetc(file);
				i++;
			}

			buffer[i] = '\0';
			sendToken(buffer,0);
		}
			
		//Condition for identifiers
		if((c == '_') || islower(c)){
			i = 0;
			while((!(isspace(c)) && !(ispunct(c))) || c == '!' || c == '_' || c == '?' ){		
				buffer[i]=c;
				c = fgetc(file);
				i++;
			}
			buffer[i] = '\0';
			variables(buffer);
		}
	
		//Condition for strings
		if(c == '"'){
			strings(c);
		}
		
		if(c == 35){		//if c == "#"
			comments(c);
		}		
		
		//Condition for operators
		if(c == '='|| c== '*'|| c== '/' || c == '+' || c == '-'){
			operators(c);
		}
		
		if(isupper(c))
			others(c);
	}		

}


int main(int argc,char *argv[]){

	if(argc == 2){
		file = fopen(argv[1],"r");
		if (file == NULL){
			fprintf(stderr,"The file cannot be opened.\n");
			exit(1);
		}

		read(file);	
//		free(buffer);
		fclose(file);
	}
return 0;
}
