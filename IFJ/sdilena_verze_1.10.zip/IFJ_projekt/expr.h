/************************************************************************
 *	IFJ projekt: "Implementace prekladace                       	*
 *				  imperativniho jazyka IFJ18."      	*
 *	Author(s): Daniel Stepanek (xstepa61) 	*
 *	Date: 30.11.2018                                            	*
 *	VUT FIT Brno 2BIT                                           	*
 *                                                                  	*
 ************************************************************************/



#ifndef EXPR_H_INCLUDED
#define EXPR_H_INCLUDED

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


#include "dynamic_string.h"
#include "parser.h"



#endif