/* TODO: neurcita velikost poli, viceradkovy komentar,

		desetinna cisla,
		upravit funkci na stringy(pokud chybi druha uvozovka " tak to detekuje jako promennou (isVar())
spoustet jako: ./vystupTest nejakysoubor
*/
#include "scanner.h"


void sendToken(char *buffer, int t){
	int size = 0;
	Token *newToken = init_Token();

//	printf("Buffer: ");
	for(int i=0;buffer[i]!='\0';i++){
//		printf("%c",buffer[i]);
		size++;
	}
	fill_Token(newToken, buffer, size);
//	printf("%s ",newToken->value->string);
//	printf(", %s",types[t]);
//	printf(", %d",size);
//	printf("\n");
	free_Token(newToken);	
}


int isKeyWord(char *str){
	if(strcmp("def",str)==0)
		return DEF;
	if(strcmp("do",str)==0)
		return DO;
	if(strcmp("else",str)==0)
		return ELSE;
	if(strcmp("end",str)==0)
		return END;
	if(strcmp("if",str)==0)
		return IF;
	if(strcmp("not",str)==0)
		return NOT;
	if(strcmp("nil",str)==0)
		return NIL;
	if(strcmp("then",str)==0)
		return THEN;
	if(strcmp("while",str)==0)
		return WHILE;
	if(strcmp("=begin",str)==0)
		return BEGINC;
	if(strcmp("=end",str)==0)
		return ENDC;
	
	return -1;	//if "str" is not a keyword
}

void operators(int c){
	
	buffer[0] = c;
	buffer[1] = '\0';
	sendToken(buffer,4);


}

void others(int c, int buf_len){
	int i = 0;

	while(isalpha(c)){
		buffer[i] = c;
		c = fgetc(file);
		i++;
		if(i == buf_len-1){
			if((buffer = realloc(buffer, sizeof(char)*50 + buf_len)))
				buf_len += 50;
			else {
				fprintf(stderr,"Reallocation failed\n");
				free(buffer);
				exit(1);
			}
		}
	}
	buffer[i] = '\0';
	sendToken(buffer,6);	
}

void comments(int c, int buf_len){
	int i = 0;
	
	while((c = fgetc(file)) != '\n'){
		buffer[i] = c;
		i++;
		if(i == buf_len-1){
			if((buffer = realloc(buffer, sizeof(char)*50 + buf_len)))
				buf_len += 50;
			else {
				fprintf(stderr,"Reallocation failed\n");
				free(buffer);
				exit(1);
			}
		}
	}
	buffer[i] = '\0';
//	sendToken(buffer,5);	
}

void strings(int c, int buf_len){
	int i = 0;
	
	while((c = fgetc(file)) != '"'){
		if(c == '\n')
			break;
		buffer[i] = c;
		i++;
		if(i == buf_len-1){
			if((buffer = realloc(buffer, sizeof(char)*50 + buf_len)))
				buf_len += 50;
			else {
				fprintf(stderr,"Reallocation failed\n");
				free(buffer);
				exit(1);
			}	
		}
	}
	buffer[i++] = '\0';
	sendToken(buffer,2);
	
}

void variables(char *buffer){
	int keyword = -1;

	//keyword checking
	keyword = isKeyWord(buffer);
	enum defaultWords key = keyword;
	
	switch (key){

	case 0:
		buffer = "def";
		break;
	case 1:
		buffer = "do";
		break;
	case 2:
		buffer = "else";
		break;
	case 3:
		buffer = "end";
		break;
	case 4:
		buffer = "if";
		break;
	case 5:
		buffer = "not";
		break;
	case 6:
		buffer = "nil";
		break;
	case 7:
		buffer = "then";
		break;
	case 8:
		buffer = "while";
		break;
	case 9:
		buffer = "=begin";
		break;
	case 10:
		buffer = "=end";
	}

	if(keyword == -1 )
		sendToken(buffer,3);
	else
		sendToken(buffer,7);
	
	
}



int read(FILE* file){
	int buf_len = BUFFER_SIZE;	//na zacatku je delka bufferu 100 prvku
	int c = 0;
	int i = 0;
	
	
	while((c = fgetc(file)) != EOF){
		
		//Condition for numbers
		if(isdigit(c)){
			i = 0;
		
			while(isdigit(c)){
				buffer[i] = c;
				c = fgetc(file);
				i++;
			}

			buffer[i] = '\0';
			sendToken(buffer,0);
		}
			
		//Condition for identifiers
		if((c == '_') || islower(c)){
			i = 0;
			while((!(isspace(c)) && !(ispunct(c))) || c == '!' || c == '_' || c == '?' ){	
				buffer[i]=c;
				c = fgetc(file);
				i++;
				if(i == buf_len-1){
					if((buffer = realloc(buffer,sizeof(char)*50 + buf_len)))
						buf_len += 50;
					else {
						fprintf(stderr,"Reallocation failed.\n");
						free(buffer);
						exit(1);
					}
				}
			}
			buffer[i] = '\0';
			variables(buffer);
		}

	
		//Condition for strings
		if(c == '"'){
			operators(c);
			strings(c, buf_len);
		}
		
		if(c == '#'){		
			operators(c);
			comments(c, buf_len);
		}		
		
		//Condition for operators
		if(ispunct(c) && c != '_' && c != '#'){
			operators(c);
		}
		
		if(isupper(c))
			others(c, buf_len);

	//	return 1;	
	}		
	
		return 0;
}


int main(int argc,char *argv[]){
	int end = 0;
	buffer = (char *) malloc(sizeof(char)*100);
	if(buffer == NULL){
		fprintf(stderr,"Buffer allocation failed\n");
		exit(1);
	}

	if(argc == 2){
		file = fopen(argv[1],"r");
		if (file == NULL){
			fprintf(stderr,"The file cannot be opened.\n");
			exit(1);
		}
		end = read(file);	
		free(buffer);
		fclose(file);
	}
return 0;
}


