//hlavickovy soubor parseru

#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>

#include "scanner.h"
#include "err_code.h"


void takeToken();


#endif


