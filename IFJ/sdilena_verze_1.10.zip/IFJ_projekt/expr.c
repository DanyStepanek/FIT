
#include "expr.h"


//Rules
#define E 0	//equal
#define R 1	//reduce
#define S 2	//shift
#define F 3	//failure



int precedence_table[8][8] = {//+-. */,  \ ,  r, (,  ),   i  , $
												{ R , S, S, R, S, R, S, R},	// +-
												{ R , R, R, R, S, R, S, R},	//	*/
												{ R , S, R, R, S, R, S, R},	//	\ /
												{ S , S, S, F, S, R, S, R},	//	== <> < <= > >=
												{ S , S, S, S, S, E, S, F},	//	(
												{ R , R, R, R, F, R, F, R},	//	)
												{ R , R, R, R, F, R, F, R},	//	id, integer, double, string
												{ S , S, S, S, S, F, S, F}	//	special sign "$"
};


