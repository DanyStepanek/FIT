/* TODO: viceradkovy komentar,
	*/

#include "scanner.h"
const char *types[] = {"Integer","Float","String","Id","Op","Comm","Other","KeyWord"};
int check = 0;
int c = 0;
char* tmp_buffer[1];

Token *sendToken(char *buffer, int t){
	
}

int isKeyWord(char *str){
	if(strcmp("def",str)==0)
		return DEF;
	if(strcmp("do",str)==0)
		return DO;
	if(strcmp("else",str)==0)
		return ELSE;
	if(strcmp("end",str)==0)
		return END;
	if(strcmp("if",str)==0)
		return IF;
	if(strcmp("not",str)==0)
		return NOT;
	if(strcmp("nil",str)==0)
		return NIL;
	if(strcmp("then",str)==0)
		return THEN;
	if(strcmp("while",str)==0)
		return WHILE;
	if(strcmp("=begin",str)==0)
		return BEGINC;
	if(strcmp("=end",str)==0)
		return ENDC;
	if(strcmp("begin",str)==0)
		return BEGIN;
	
	return -1;	//if "str" is not a keyword
}

void operators(){
	int i = 1;
	buffer[0] = c;
	while(ispunct(c = getchar()) && (c == '=' || c == '>')){
		buffer[i] = c;
		i++;
	}
	//	c = fseek(file, -1, SEEK_CUR);
		buffer[i] = '\0';
	


}

int others(int buf_len){
	int i = 0;

	while(isalpha(c)){
		buffer[i] = c;
		c = getchar();
		i++;
		if(i == buf_len-1){
			if((buffer = realloc(buffer, sizeof(char)*50 + buf_len)))
				buf_len += 50;
			else {
				fprintf(stderr,"Reallocation failed\n");
				return 2;
			}
		}
	}
	buffer[i] = '\0';
	sendToken(buffer,6);	
	return 2;
}

void comments(){

}

int strings(int buf_len){
	int i = 0;
	
	while((c = getchar()) != '"'){
		if(c == '\n'){
			lines++;
			return 2;
		}
		
		buffer[i] = c;
		i++;
		if(i == buf_len-1){
			if((buffer = realloc(buffer, sizeof(char)*50 + buf_len)))
				buf_len += 50;
			else {
				fprintf(stderr,"Reallocation failed\n");
				return 2;
			}	
		}
	}
	lines++;
	buffer[i] = '\0';
	return 0;
	
}

int variables(char *buffer){
	int keyword = -1;

	//keyword checking
	keyword = isKeyWord(buffer);
	enum defaultWords key = keyword;
	
	switch (key){

	case 0:
		buffer = "def";
		break;
	case 1:
		buffer = "do";
		break;
	case 2:
		buffer = "else";
		break;
	case 3:
		buffer = "end";
		break;
	case 4:
		buffer = "if";
		break;
	case 5:
		buffer = "not";
		break;
	case 6:
		buffer = "nil";
		break;
	case 7:
		buffer = "then";
		break;
	case 8:
		buffer = "while";
		break;
	case 9:
		buffer = "=begin";
		break;
	case 10:
		buffer = "=end";
		break;
	case 11:
		buffer = "begin";
		break;
	}

	return keyword;
		
}

int numbers(){
	int i = 0;
	int type = 0;

	while(isdigit(c)){
		buffer[i] = c;
		c = getchar();
				
		i++;
	}
	
	//float
	if(c == '.'){	//zapis xx.xx
		buffer[i] = c;
		i++;
		while(isdigit(c = getchar())){
			buffer[i] = c;
			i++;
		}
		fseek(file, -1, SEEK_CUR);	//posun o znak zpet
		type = 1;
	}
	else if(tolower(c) == 'e'){	//zapis xxe(+-)xx 
			buffer[i] = c;
			i++;
			c = fgetc(file);
			while(isdigit(c) || c == '-' || c == '+'){
				buffer[i] = c;
				c = getchar();
				i++;
			}
			fseek(file, -1, SEEK_CUR);	//posun o znak zpet 
		type = 1;
	}
	
	buffer[i] = '\0';
	
	if(type != 1)
		if((atof(buffer)) > INT_MAX)
			type = check = 2 ;
	
	
	
	return type;
}

int get_token(){
	int buf_len = BUFFER_SIZE;	//na zacatku je delka bufferu 100 prvku
	int i = 0;
	check = 0;
	
	
	while(1){
	
		c = getchar();
		
		if(c == EOF)
			return 1;
		
		if(c == '\n'){
			lines++;
	
		}
		
		
		//Condition for numbers
		if(isdigit(c)){
			int num = numbers();
			
			if(num == 0)
				sendToken(buffer,0);	//integer
			else if(num == 1)
				sendToken(buffer,1);	//float
			
			if(c == '\n'){
			lines++;
			}
			
			break;
		}
			

		//Condition for identifiers
		if((c == '_') || islower(c)){
			i = 0;
			while((!(isspace(c)) && !(ispunct(c))) || c == '!' || c == '_' || c == '?' ){	
				buffer[i]=c;
				c = getchar();
				i++;
				if(i == buf_len-1){
					if((buffer = realloc(buffer,sizeof(char)*50 + buf_len)))
						buf_len += 50;
					else {
						fprintf(stderr,"Reallocation failed.\n");
						check = 2;
						break;
					}
				}
			}
			
			buffer[i] = '\0';
			
			if(check == 2)
				break;
			
			int isKeyword = variables(buffer);
			
			if(c == '\n'){
			lines++;
			}
			
			if(isKeyword == -1 )
				sendToken(buffer,3);
			else
				sendToken(buffer,7);
			break;
		}

	
		//Condition for strings
		if(c == '"'){
			if((check = strings(buf_len))== 0)
				sendToken(buffer,2);
			

			break;
		}
		
		//Condition for comments
		if(c == '#'){		
			while((c = getchar()) != '\n'){}
						
			lines++;
			buffer[0] = c;
			buffer[1] = '\0';
			sendToken(buffer, 4);

			break;
		}		
	
		//Condition for operators
		if(ispunct(c) && c != '_' && c != '#'){
			operators();
			sendToken(buffer,4);
			break;
		}
		
		if(isupper(c)){
			check = others(buf_len);
			
			if(c == '\n'){
			lines++;
			}
			
			break;
		}
	}	
	
	//zpracovani chyby
	if (check == 2){
		call_error(check, lines);
		return check;
	}
	
	return 0;	
}



















