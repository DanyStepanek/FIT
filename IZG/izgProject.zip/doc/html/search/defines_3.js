var searchData=
[
  ['queue_5fback',['QUEUE_BACK',['../queue_8h.html#ace4353596ccfb99587bf0fddb48b23eb',1,'queue.h']]],
  ['queue_5ffront',['QUEUE_FRONT',['../queue_8h.html#a37211e1ceb4d4f2ff1e3307ca9cae7dd',1,'queue.h']]]
];
