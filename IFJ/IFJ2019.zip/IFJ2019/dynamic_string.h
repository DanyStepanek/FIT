//
// Created by juraj on 03.12.19.
//

#ifndef IFJ_DYNAMIC_STRING_H
#define IFJ_DYNAMIC_STRING_H

#define STRING_LENGTH_INC 8

typedef struct {
    char *str;          // pointer to the string
    unsigned length;	// real length of string
    unsigned allocSize;	// size of allocated memory
} Dynamic_string;



int string_init(Dynamic_string *s);


void string_free(Dynamic_string *s);


void string_clear(Dynamic_string *s);


int string_add_char(Dynamic_string *s1, char c);


int string_add_Cstr(Dynamic_string *s1, char *s2);


int string_copy_Cstr(Dynamic_string *s1, char *s2);


char *string_get_string(Dynamic_string *s);


#endif //IFJ_DYNAMIC_STRING_H
