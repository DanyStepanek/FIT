var searchData=
[
  ['appdata',['AppData',['../structAppData.html',1,'']]],
  ['arguments',['Arguments',['../structArguments.html',1,'']]]
];
