var searchData=
[
  ['callbackanddata',['CallbackAndData',['../structCallbackAndData.html',1,'']]]
];
