var searchData=
[
  ['callback',['callback',['../structCallbackAndData.html#ad476378cedbec0eb6d0f94230f748985',1,'CallbackAndData']]],
  ['callbackdata',['callbackData',['../structWindow.html#a149e9e3b4ca65e5feb3a492b3a3eaca1',1,'Window']]],
  ['cameraanglex',['cameraAngleX',['../structAppData.html#a940aa8b96b641cd01005116f135064ef',1,'AppData']]],
  ['cameraangley',['cameraAngleY',['../structAppData.html#a81c378f9608263b527ac780e960bc163',1,'AppData']]],
  ['cameradistance',['cameraDistance',['../structAppData.html#a03a75b6250d4fd9f164684f8b522e9cd',1,'AppData']]],
  ['cameraposition',['cameraPosition',['../globals_8c.html#a2ae2553412ead34e3a4e23019d4f052e',1,'cameraPosition():&#160;globals.c'],['../globals_8h.html#a2ae2553412ead34e3a4e23019d4f052e',1,'cameraPosition():&#160;globals.c']]],
  ['clearcolor',['clearColor',['../structGPU.html#af7acb677fa94d1584c8b87af141ee584',1,'GPU']]],
  ['cleardepth',['clearDepth',['../structGPU.html#a7136e6c78dbae48e165ca1d431810fba',1,'GPU']]],
  ['color',['color',['../structGPUFramebuffer.html#abcb6c852e61831c6f4ac4f2f082bf151',1,'GPUFramebuffer']]],
  ['column',['column',['../structMat4.html#a89c6922a5ca3584062e9841090709592',1,'Mat4']]],
  ['commandqueue',['commandQueue',['../structGPU.html#a87774e200e97ede957982fa4aa22ada6',1,'GPU']]]
];
