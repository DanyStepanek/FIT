/******************************************************************** 
 *  About: Scanner is the first part of Lexical analysis.           *
 *		   Scanner takes input file and analyze each line.  *
 *		   Detects lexems and divides them into the tables. *
 *	Tables: identifiers: x, a, i, sum,                          *
 *			literals: "music", 5, 5.2,                  *
 *			keywords: IF, THEN, DO, WHILE, BEGIN,       *
 *					  END, NILL,                *	
 *	 		separators: (),{},                          *
 *			operators: +, -, *, /, =,                   *
 *			comments:  #..., =begin ... =end            *
 ********************************************************************
 *	IFJ projekt: "Implementace prekladace                       *
 *				  imperativniho jazyka IFJ18."      *
 *	Author(s): Daniel Stepanek (xstepa61)                       *
 *	Date: 11.10.2018                                            *
 *	VUT FIT Brno 2BIT                                           *
 *                                                                  *
 *******************************************************************/
#ifndef SCANNER_H_INCLUDED
#define SCANNER_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>
#include<limits.h>

#include "Tlist.h"
#include "err_code.h"

#define BUFFER_SIZE 100



FILE *file;
char *buffer;

enum defaultWords{
	DEF,	//0
	DO,	
	ELSE,
	END,
	IF,
	NOT,
	NIL,
	THEN,
	WHILE,
	BEGINC,	//begin multiline comment
	ENDC,	//end multiline comment
	BEGIN
};




//Functions definitons

void sendToken(char *, int );
int isKeyWord(char *);
void operators(int );
int others(int , int );
void comments(int , int );
int strings(int , int );
int variables(char *);
int numbers(int );
int get_token(FILE* );

#endif










