/******************************************************************** 
 *  About: Main function          									*
 *		   															*
 *		    	 													*
 *																	*
 ********************************************************************
 *	IFJ projekt: "Implementace prekladace                       	*
 *				  imperativniho jazyka IFJ18."      				*
 *	Author(s): Daniel Stepanek (xstepa61)                       	*
 *	Date: 10.11.2018                                            	*
 *	VUT FIT Brno 2BIT                                           	*
 *                                                                  *
 *******************************************************************/
#include<stdio.h>
#include<stdlib.h>

#include "scanner.h"
#include "parser.h"
#include "err_code.h"
#include "generator.h"



int main(int argc,char *argv[]){
	int check = 0;
	
	//inicializace struktury pro ukladani nactenych tokenu
	Tlist *t = init_Tlist();
	
	buffer = (char *) malloc(sizeof(char)*100);
	if(buffer == NULL){
		fprintf(stderr,"Buffer allocation failed\n");
		exit(1);
	}
	if(argc == 1){
		check = syntax();
		
		if(check != 0){
			int line_n = 0;
			while(num_of_lines[line_n] != -1){
				fprintf(stderr,"%s:%d:  error:  \n", argv[2], num_of_lines[line_n]);
				line_n++;
			}
			
			fprintf(stderr,"***  Error [%d]: Compilation failed.  ***\n",  check);
			
		}
		else { 
			printf("*** Compilation succeeded.  ***\n");
			printf("num of lines: %d\n", lines);
		}
	}
	
	//dealokace veskere alokovane pameti pouzite v Tlist
	free_Tlist(t);

	// dealokace pro scanner 
	free(buffer);
	
return 0;
}
