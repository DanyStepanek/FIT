#include "parser.h"

#define GET_TOKEN()

#define 	NUMBER	1
#define 	NUMBER_DOUBLE	2
#define 	IDENTIFIER	3 
#define 	KEYWORD	4
#define 	OPERATOR	5
#define 	STRING	6
#define 	EOL	7
#define 	tEOF	8


int syntax(){
	
	int type = 0;
	Token *token;
	
//	generator_start();
	
	do {
		
		token = get_token();
		type = token->id; 
		printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
		
		
		switch(type){
			
			
			case NUMBER:
			
			break;
			
			case NUMBER_DOUBLE:
			
			break;
			
			case IDENTIFIER:
			
			break;
			
			case KEYWORD:
			
			break;
			
			case OPERATOR:
			
			break;
			
			case STRING:
			
			break;
			
			case EOL:
			
			break;
			
			
			
			
			
			
		}	//end of switch(type)
		
		
		
		
		
		
		
		
				
/*******************************/	
			
		free_Token(token);
			
	} while (type != tEOF);
	
	//generator_clear_stream();

	return 0;
}
	
	

