
#include "parser.h"

STable* global_frame;
STable* local_frame;
STable* tmp_frame;
TList* frame_list;
Tstack* token_stack;
Parse_data* parser_data;
struct TData* id;
FILE *file;

int expr_(struct Token* token){

	int res;
//  printf("EXPR\n");
  //rozhodnuti jestli jsme ve funkci (resit i lokalni promenne) nebo mimo funkci
  if(parser_data->function){
    res = process_expression(token, parser_data, file,global_frame,local_frame,tmp_frame);
  }
  else{
    res =process_expression(token, parser_data, file,global_frame,local_frame,tmp_frame);
  }

  if (res != 0)
  {
	//  printf("EROR\n");
	  call_error(res, res);
    return res;
  }

  return 0;
}

void parse_string(char* input){

  for(int i = 0; input[i] != '\0'; i++){
    if(input[i] == '\\'){

      switch(input[i+1]){
        case 'x':
          if(isxdigit(input[i+2])  && isxdigit(input[i+3])){
            int ch[7] = {'\'',input[i], input[i+1], input[i+2], input[i+3], '\0', '\''};
            printf("%s", ch);
            i += 3;
          }
        break;
        case 'n':
          printf("\n");
          i++;
        break;
        case 't':
          printf("\t");
          i++;
        break;
        case 'b':
          printf("\b");
          i++;
        break;
        case 'v':
          printf("\v");
          i++;
        break;
        case '\'':
          printf("'");
          i++;
        break;
        case '\"':
          printf("\"");
          i++;
        break;
        case '\\':
          printf("\\");
          i++;
        break;
        default:
          printf("%c%c", input[i], input[i+1]);
          i++;
        break;
      }
    }
    else{
      printf("%c", input[i]);
    }

  }

  return;
}

int print_(struct Token* token){

  if(strcmp(token->val, "(") != 0 ){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

  char* tmp_string;
  int str_length;
  int err_code = 0;

  while(strcmp(token->val, ")") != 0){

    if(token->type == T_ID){

      parser_data->r_value = true;
      err_code = id_(token);
      parser_data->r_value = false;
      tmp_string = id->value;

    }
    else if(token->type >= T_DBL_ES && token->type <= T_STRING){
      str_length = strlen(token->val);
      tmp_string = token->val;

    }
    else{
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(err_code != SEMANTIC_ERROR){
      parse_string(tmp_string);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") == 0){
      printf(" ");
      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    }
    else if(strcmp(token->val, ")") == 0){
      ;
    }
    else{
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(token->type != T_EOL && token->type != T_EOF){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  return 0;
}

// nevim jestli ma zacinat a koncit uvozovkama nebo ne( ' ' ) ???
int inputs_(struct Token* token){

  char* line = NULL;
  size_t len = 0;
  size_t line_size = 0;
  bool is_correct = true;

  line_size = getline(&line, &len, stdin);

  for(__u_int i = 0; i < line_size - 1; i++){
      if(!isalnum(line[i])){
        is_correct = false;
        break;
      }
  }

  if(is_correct){
  //  printf("inputs: %s\n", line);
  }
  else{
    return -1;
  }

//  free(line);

  return 0;
}

int inputi_(struct Token* token){

  char* line = NULL;
  size_t len = 0;
  size_t line_size = 0;
  bool is_correct = true;

  int output = 0;

  line_size = getline(&line, &len, stdin);

  for(__u_int i = 0; i < line_size - 1; i++){
      if(!isdigit(line[i])){
        is_correct = false;
        break;
      }
  }

  if(is_correct){
  //  printf("inputi: %s\n", line);
    output = atoi(line);
  }
  else{
    return -1;
  }

  free(line);

  return output;
}

double inputf_(struct Token* token){


  return 0;
}

int len_(struct Token* token){

  int length = 0;
  CodeType type = C_LEN;
  int i = 0;
  CodeData* data[3];

//  data[0] = fill_code_data("len", NULL, NULL);

  if(strcmp(token->val, "(") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    data[1] = fill_code_data(token->val, NULL, NULL);

    if(token->type == T_STRING){
      length = strlen(token->val);
  //      printf("%d\n", length);
    }
    else if(token->type == T_ID){
      parser_data->r_value = true;
      id_(token);
      parser_data->r_value = false;

      length = strlen(id->value);
  //    printf("%d\n", length);

    }
    else{
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") == 0){
      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      if(token->type == T_EOL){
  //      InnerCode* code = fill_inner_code(type, data, 2);
  //      generate(code);
  //      free_inner_code(code);
        return length;
      }
      else{
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
        exit(SYNTAX_ERROR);
      }
    }
    else{
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }

  return 0;
}

int substr_(struct Token* token){

    char* tmp_string;
    int begin = 0;
    int str_length = 0;
    int len = 0;

    if(strcmp(token->val, "(") != 0 ){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_STRING){
      str_length = strlen(token->val);
      tmp_string = token->val;
    }
    else if(token->type == T_ID){

      parser_data->r_value = true;
      id_(token);
      parser_data->r_value = false;

      str_length = strlen(id->value);
      tmp_string = id->value;
    }
    else{
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_INTEGER){
      begin = atoi(token->val);
      if(begin < 0 || begin > str_length){
        call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        parser_data->run_err_code = SEMANTIC_ERROR;
        exit(SEMANTIC_ERROR);
      }
    }
    else if(token->type == T_ID){

      parser_data->r_value = true;
      id_(token);
      parser_data->r_value = false;

      begin = atoi(id->value);
      if(begin < 0 || begin > str_length){
        call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        parser_data->run_err_code = SEMANTIC_ERROR;
        exit(SEMANTIC_ERROR);
      }
    }
    else{
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_INTEGER){
      len = atoi(token->val);
      if(len < 0){
        call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        parser_data->run_err_code = SEMANTIC_ERROR;
        exit(SEMANTIC_ERROR);
      }
    }
    else if(token->type == T_ID){

      parser_data->r_value = true;
      id_(token);
      parser_data->r_value = false;

      len = atoi(id->value);
      if(len < 0){
        call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        parser_data->run_err_code = SEMANTIC_ERROR;
        exit(SEMANTIC_ERROR);
      }
    }
    else{
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }

    str_length = strlen(tmp_string);
    for(int i = begin; i <= len; i++){
      printf("%c",tmp_string[i]);
      if(i == str_length){
        break;
      }
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

  return 0;
}

int ord_(struct Token* token){

    char* tmp_string;
    int value = 0;
    int str_length = 0;

    if(strcmp(token->val, "(") != 0 ){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_STRING){
      str_length = strlen(token->val);
      tmp_string = token->val;

    }
    else if(token->type == T_ID){

      parser_data->r_value = true;
      id_(token);
      parser_data->r_value = false;

      str_length = strlen(id->value);
      tmp_string = id->value;
    }
    else{
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_INTEGER){
      value = atoi(token->val);
      if(value < 0 || value > str_length){
        call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        parser_data->run_err_code = SEMANTIC_ERROR;
        exit(SEMANTIC_ERROR);
      }

    }
    else if(token->type == T_ID){
      parser_data->r_value = true;
      id_(token);
      parser_data->r_value = false;

      value = atoi(id->value);
      if(value < 0 || value > str_length){
        call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        parser_data->run_err_code = SEMANTIC_ERROR;
        exit(SEMANTIC_ERROR);
      }
    }
    else{
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }

  //  printf("%c %d\n",tmp_string[value], tmp_string[value]);

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }

  return 0;
}

char chr_(struct Token* token){

  int value = 0;
  if(strcmp(token->val, "(") != 0 ){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

  if(token->type == T_INTEGER){
    value = atoi(token->val);
    if(value < 0 || value > 255){
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }
  }
  else if(token->type == T_ID){

    parser_data->r_value = true;
    id_(token);
    parser_data->r_value = false;

    value = atoi(id->value);
    if(value < 0 || value > 255){
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
      parser_data->run_err_code = SEMANTIC_ERROR;
      exit(SEMANTIC_ERROR);
    }
  }
  else{
    call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
    parser_data->run_err_code = SEMANTIC_ERROR;
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, ")") != 0){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(token->type != T_EOL){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  return (char)value;
}

int pass_(struct Token* token){
  if(token->type == T_EOL){
    return 0;
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }
}

int else_(struct Token* token){

  if(strcmp(token->val, ":") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }
  else{

    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

	int uroven = 0;
	int vracena_uroven = 0;
	int err_code = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = ++parser_data->uroven;
		if(vracena_uroven != uroven){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}

		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
			err_code = id_(token);
			if(err_code != 0){
				call_error(err_code, err_code);
				exit(err_code);
			}
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
			else if(token->type == T_EOF){
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}
	}
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  return 0;
}

int if_(struct Token* token){

  parser_data->if_stat = true;
  expr_(token);

  if(strcmp(token->val, ":") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

	int uroven = 0;
	int vracena_uroven = 0;
	int err_code = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = ++parser_data->uroven;
		if(vracena_uroven != uroven){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
	 		err_code = id_(token);
			if(err_code != 0){
				call_error(err_code, err_code);
				exit(err_code);
			}
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
			else if(token->type == T_EOF){
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL && token->type != T_EOF && token->type != T_DEDENT){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  parser_data->if_stat = false;
  return 0;
}

int while_(struct Token* token){

  parser_data->while_stat = true;
  expr_(token);

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, ":") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }

	int uroven = 0;
	int vracena_uroven = 0;
	int err_code = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = ++parser_data->uroven;
		if(vracena_uroven != uroven){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
			err_code = id_(token);
			if(err_code != 0){
				call_error(err_code, err_code);
				exit(err_code);
			}
			else if(token->type == T_EOF){
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}
	}
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  parser_data->while_stat = false;
  return 0;
}

int return_(struct Token* token){

  //return muze byt jen ve funkci
  if(!parser_data->def_function){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  if(token->type != T_EOL){
		parser_data->return_stat = true;
		int tmp = expr_(token);
		parser_data->return_stat = false;
		return tmp;
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }
}

int def_(struct Token* token){

	parser_data->def_function = true;
	parser_data->function = true;

  char* function_name;
  int params_count = 0;
  CodeType type;
  int i = 0;
  CodeData* data[100];

  tmp_frame = malloc(sizeof(STable));
  if(check_malloc(tmp_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  init_table(tmp_frame);

  if(token->type == T_ID){
      function_name = token->val;
      parser_data->name = token->val;
//      data[i++] = fill_code_data(parser_data->name, NULL, NULL);
//      type = C_FUNC;
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, "(") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    while(strcmp(token->val, ")") != 0){
  //    data[i++] = fill_code_data(token->val, NULL, NULL);

    	if(token->type == T_ID){
				//create parameter as a local variable in frame.
				strcpy(id->name, token->val);
      	put_item(tmp_frame, id);

      	parser_data->params[params_count] = token->val;
        params_count += 1;
      }
      else{
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
        exit(SYNTAX_ERROR);
      }

      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      if(strcmp(token->val, ",") == 0){
        if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      }
      else if(strcmp(token->val, ")") == 0){
        ;
      }
      else{
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
        exit(SYNTAX_ERROR);
      }
    }
	}
  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
	if(strcmp(token->val, ":")){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(token->type != T_EOL){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

	int uroven = 0;
	int vracena_uroven = 0;
	int err_code = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = ++parser_data->uroven;
		if(vracena_uroven != uroven){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					break;
				}
			}
			err_code = id_(token);
			if(err_code != 0){
				call_error(err_code, err_code);
				exit(err_code);
			}
			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					break;
				}
			}
			else if(token->type == T_EOF){
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}
	}
  else{
  	call_error(SYNTAX_ERROR, SYNTAX_ERROR);
  	parser_data->run_err_code = SYNTAX_ERROR;
  	exit(SYNTAX_ERROR);
  }

	list_insert_item(frame_list, tmp_frame, function_name, parser_data->params, params_count);

  tmp_frame = NULL;

	parser_data->def_function = false;
	parser_data->function = false;

	return 0;
}

int assign_(struct Token* token){

  if(strcmp(token->val, "=") == 0){
  //  printf("ASSIGN\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
			parser_data->assign_stat = true;
    	expr_(token);
			parser_data->assign_stat = false;
  }
	else{
		call_error(SYNTAX_ERROR, SYNTAX_ERROR);
		exit(SYNTAX_ERROR);
	}

  return 0;
}

int check_params(struct Token* token){

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, "(") == 0){
      for(int i = 0; i < parser_data->params_count; i++){
      	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      	if(token->type == T_ID || (token->type >= T_DBL_ES && token->type <= T_STRING)){
        	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
        	if((i + 1) == parser_data->params_count){
          	break;
        	}
        	if(strcmp(token->val, ",") != 0){
          	call_error(SYNTAX_ERROR, SYNTAX_ERROR);
          	parser_data->run_err_code = SYNTAX_ERROR;
          	exit(SYNTAX_ERROR);
        	}
      	}
      	else{
        	call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
        	parser_data->run_err_code = SEMANTIC_ERROR;
        	exit(SEMANTIC_ERROR);
      	}
    	}

    	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    	if(strcmp(token->val, ")") == 0){
      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      if(token->type != T_EOL){
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
        exit(SYNTAX_ERROR);
      }
    }
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  return 0;
}

int id_(struct Token* token){

  if(strcmp(token->val, "print") == 0){
  //  printf("PRINT\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    print_(token);
  }
  else if(strcmp(token->val, "inputs") == 0){
  //  printf("INPUTS\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    inputs_(token);
  }
  else if(strcmp(token->val, "inputi") == 0){
  //  printf("INPUTI\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    inputi_(token);
  }
  else if(strcmp(token->val, "inputf") == 0){
  //  printf("INPUTF\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    inputf_(token);
  }
  else if(strcmp(token->val, "len") == 0){
  //  printf("LEN\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    len_(token);
  }
  else if(strcmp(token->val, "substr") == 0){
  //  printf("SUBSTR\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    substr_(token);
  }
  else if(strcmp(token->val, "ord") == 0){
  //  printf("ORD\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    ord_(token);
  }
  else if(strcmp(token->val, "chr") == 0){
  //  printf("CHR\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    chr_(token);
  }
  else if(strcmp(token->val, "pass") == 0){
  //  printf("PASS\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    pass_(token);
  }
  else if(strcmp(token->val, "if") == 0){
  //  printf("IF\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if_(token);
  }
  else if(strcmp(token->val, "else") == 0){
  //  printf("ELSE\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    else_(token);
  }
  else if(strcmp(token->val, "while") == 0){
  //  printf("WHILE\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    while_(token);
  }
  else if(strcmp(token->val, "return") == 0){
  //  printf("RETURN\n");
  	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    return_(token);
  }
  else if(strcmp(token->val, "def") == 0){
  //  printf("DEF\n");
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		if(parser_data->def_function){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}
    def_(token);

  }
  // ID
  else{
  //  printf("ID\n");
    if(!parser_data->r_value){
      parser_data->actual_id->name = token->val;
      //pokud ID je funkce
			if(parser_data->def_function){
				strcpy(id->name, token->val);
				put_item(tmp_frame, id);
				if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
				assign_(token);
			}
      else{
        if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
        assign_(token);
      }
    }
    else{
      if(parser_data->function){
        //pokud ID neni funkce
        if((local_frame = list_get_item(frame_list, token->val, parser_data->params, &parser_data->params_count)) == NULL){
          if(in_table(global_frame, token->val)){
            get_item(global_frame, id, token->val);
            parser_data->name = token->val;
            parser_data->frame = "GF";
          }
          else{
            call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
            parser_data->run_err_code = SEMANTIC_ERROR;
            exit(SEMANTIC_ERROR);
          }
        }
        else{
          parser_data->name = token->val;
          if(in_table(local_frame, token->val)){
            get_item(local_frame, id, token->val);
            parser_data->frame = "LF";
            parser_data->op_code = C_ID;
          }
          else if(in_table(global_frame, token->val)){
            get_item(global_frame, id, token->val);
            parser_data->frame = "GF";
            parser_data->op_code = C_ID;
          }
          else if(
						check_params(token) != 0){
            call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
            parser_data->run_err_code = SEMANTIC_ERROR;
            exit(SEMANTIC_ERROR);
          }
          else{
            call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
            parser_data->run_err_code = SEMANTIC_ERROR;
            exit(SEMANTIC_ERROR);
          }
        }
      }
      else{
        if(in_table(global_frame, token->val)){
          get_item(global_frame, id, token->val);
        }
        else{
          call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
          parser_data->run_err_code = SEMANTIC_ERROR;
          exit(SEMANTIC_ERROR);
        }
      }
    }
  }

  return parser_data->run_err_code;
}

// <prog>
int prog_(struct Token* token){

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

  while(token->type != T_EOF && bylEOF == 0){

    CodeData* data[100];
    InnerCode* code;

    switch(token->type){
      case T_ID:
        parser_data->run_err_code = id_(token);
        break;
      case T_TAB:
        break;
      case T_EOL:
        parser_data->r_value = false;
        break;
      case T_SPC:
				printf("spc\n");
        break;
      case T_INDENT:
        break;
      case T_DEDENT:
				if(isEmptyLexStack(LexStack)){
					return parser_data->run_err_code;
				}

        break;
      default:

        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
    }

		if(parser_data->run_err_code != 0){
			return parser_data->run_err_code;
		}

    if(!parser_data->function){
        if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    }
    else{
      parser_data->function = false;
    }
  }

  return parser_data->run_err_code;
}

int parse(FILE* f){

  frame_list = malloc(sizeof(TList));
  if(check_malloc(frame_list) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  global_frame = malloc(sizeof(STable));
  if(check_malloc(global_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  local_frame = malloc(sizeof(STable));
  if(check_malloc(local_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  tmp_frame = malloc(sizeof(STable));
  if(check_malloc(tmp_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  token_stack = malloc(sizeof(Tstack));
  if(check_malloc(token_stack) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  parser_data = malloc(sizeof(Parse_data));
  if(check_malloc(parser_data) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  id = malloc(sizeof(struct TData));
  if(check_malloc(id) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }
  id->name = malloc(sizeof(char) * 100);
  id->value = malloc(sizeof(char) * 100);

  struct Token* t = malloc(sizeof(struct Token));
  if(check_malloc(t) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  file = f;

/********INIT**********************************/
  initToken(t);
  init_table(global_frame);
  init_table(local_frame);
  list_init(frame_list);
  init_table(tmp_frame);

  parser_data->token = malloc(sizeof(struct Token));
  if(check_malloc(parser_data->token) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  parser_data->actual_id = malloc(sizeof(struct TData));
  if(check_malloc(parser_data->actual_id) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }
  parser_data->actual_func = malloc(sizeof(char) * 100);  //nazev aktualni funkce ve ktere jsem.. globalni ramec == NULL
  if(check_malloc(parser_data->actual_func) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  parser_data->l_value = false;  //leva strana prirazeni(a = 2) => l_value = a
  parser_data->function = false;
  parser_data->while_stat = false;  //if in while_statement
  parser_data->if_stat = false; //if in if_statement
  parser_data->defined = false; //if promenna nebo funkce je definovana
  parser_data->declare = false;
  parser_data->r_value = false;
  parser_data->first_error = true;

  parser_data->name = malloc(sizeof(char) * 1000);
  parser_data->value = malloc(sizeof(char) * 2000);
  parser_data->frame = malloc(sizeof(char) * 4);

/*********MAIN_LOOP***********************/
  int err_code = 0;
	parser_data->uroven = 0;

  //<prog>->begin
  if((err_code = prog_(t)) != 0){
    call_error(err_code, err_code);

  }

/**********FREE_ALL*************************/

  free(parser_data->token);
  free(parser_data->actual_id);
  free(parser_data->actual_func);
  free(parser_data->name);
  free(parser_data->value);
  free(parser_data->frame);
  free(parser_data);


  resetToken(t);
  clear_table(global_frame);

//  clear_table(local_frame);
  clear_table(tmp_frame);


  list_clear(frame_list);

  free(frame_list);
  free(t);
  free(global_frame);
  free(local_frame);

  return err_code;
}
