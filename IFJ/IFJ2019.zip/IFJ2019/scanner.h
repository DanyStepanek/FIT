//
// Created by tmaje on 13.10.2019.
//

#ifndef IFJ_SCANNER_H
#define IFJ_SCANNER_H
#include <stdio.h>
#include <stdlib.h>
#include "err_code.h"


/*GLOBALNI PROMENNE*/
int bylEOL;
int znovuDedent;
int dedentValue;
int bylEOF;
struct LexStack* LexStack;




typedef enum{
    START = 0, //pocatecni stav



    //komentare
    COM_LX = 100, //radkovy komentar
    COM_X, //tmp blokovy koment
    COM_X1,
    COM_X2,
    COM_X3,
    COM_X4,
    COM_X5,

    //cisla
    INT = 200,//integer
    ZERO, //NULA
    DBL_X, //tmp na double
    DBL, //double
    DBL_EX, //tmp na exponent
    DBL_E, //exponent
    DBL_ESX, //TMP na signed exponent
    DBL_ES, //signed exponent

    //string
    STR_X = 300, //tmp na string
    STR_X1, //tmp na string
    STR_HXX, //tmp na hex string
    STR, //string

    //identifikator
    ID = 400, //identifikator

    //jednoduché datové typy, enbo co to je
    LB = 500, //left bracket
    EOL, //end of line
    EOFF, //end of file
    RB, //right bracket
    COMM, //comma - carka
    MULT, //multiplication
    MINUS,
    PLUS,
    DIV,
    IDIV, //celociselne deleni
    MT, //more than >
    MET, //more-equal than >=
    LT, //lesser than <
    LET, //lesser-equal than <=
    ASS, //zadek, nebo prirazeni =
    EQ, //equality ==
    NEQ_X, //tmp pro NEQ !
    NEQ, //not equality !=
    TAB, //tabulator
} Tstate;




// hodnoty které se ukládájí do atributu tokenu type
typedef enum {
    T_OPERATOR = 1000, //pro jednomistne operatory
    T_DBL_ES = 1001, //double signed exponent
    T_DBL_E = 1002, //double exponent
    T_DBL = 1003, //double
    T_INTEGER = 1004, //ZERO taky
    T_STRING = 1005,
    T_ID = 1006, //identifikator
    T_TAB = 1007, //tabulator
    T_EOL = 1008,
    T_EOF = 1009,
    T_SPC = 1010,
    T_INDENT = 1011,
    T_DEDENT = 1012
} Ttype;

typedef enum {
    S_TERM = 1,
    S_NON_TERM = 0

} Terminal_state_E;


// struktura reprezentující token
struct Token
{
    // typ tokenu (identifikátor, celé číslo, ...)
    Ttype type;
    // současná délka řetezce val
    int lentgh;
    // maximální délka řetězce val
    int size;
    // hodnota tokenu
    char * val;
    // terminal/neterminal
    Terminal_state_E Terminal_state;

};


/**
 *
 * @param f Ukazatel na soubor odkud se čte
 * @param t ukazatel na token se kterým se pracuje
 * @return 1 pokud správně, 0 pokud token invalid
 */
int getToken(FILE * f, struct Token * t);

/**
 *
 * @param f Ukazatel na soubor odkud se čte
 * @return počet vymazaných znaků
 */
int lTrim(FILE * f);

/**
 *
 * @param t Ukazatel na token k nicializaci
 */
void initToken(struct Token* t);

/**
 *
 * @param t Ukazatel na token k uvolnění
 */
void resetToken(struct Token *t);


int spoctiMezery(FILE * f);


/********
 * ZASOBNIK A JEHO VECI
 */
struct LexStack{
    int top;
    unsigned capacity;
    int* array;
};


struct LexStack* createLexStack();

int isEmptyLexStack(struct LexStack* stack);

void pushLexStack(struct LexStack* stack, int item);

int popLexStack(struct LexStack* stack);

int peekLexStack(struct LexStack* stack);

#endif //IFJ_SCANNER_H
