var searchData=
[
  ['idlecallback',['idleCallback',['../structWindow.html#aca8fcf0113fd079f5bc4050c1f72a93b',1,'Window']]],
  ['idlecallbackdata',['idleCallbackData',['../structWindow.html#a91eae2aff16e63ff29644aa0d287abb1',1,'Window']]],
  ['indices',['indices',['../structGPUVertexPuller.html#a043bd88d5a8baa834418369b993a01b6',1,'GPUVertexPuller']]],
  ['infragment',['inFragment',['../structGPUFragmentShaderData.html#aa286b4180c0efb8593bbe0ecb8c6e60a',1,'GPUFragmentShaderData']]],
  ['invertex',['inVertex',['../structGPUVertexShaderData.html#a5744e11986f6ac290817370ed6b45726',1,'GPUVertexShaderData']]]
];
