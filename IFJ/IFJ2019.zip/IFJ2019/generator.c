#include "generator.h"


CodeData* fill_code_data(char* name, char* value, char* frame){


  CodeData* data = malloc(sizeof(CodeData));
  if(check_malloc(data) == -1){
    exit(-1);
  }

  if(name != NULL){
    data->name = malloc(sizeof(char) * strlen(name) + 1);
    if(check_malloc(data->name) == -1){
      exit(-1);
    }
    strcpy(data->name, name);
  }
  else{
    data->name = NULL;
  }

  if(value != NULL){
    data->value = malloc(sizeof(char) * strlen(value) + 1);
    if(check_malloc(data->value) == -1){
      exit(-1);
    }
    strcpy(data->value, value);
  }
  else{
    data->value = NULL;
  }

  if(frame != NULL){
    data->frame = malloc(sizeof(char) * strlen(name) + 1);
    if(check_malloc(data->frame) == -1){
      exit(-1);
    }
    strcpy(data->frame, frame);
  }
  else{
    data->frame = NULL;
  }

  return data;
}

InnerCode* fill_inner_code(CodeType op_code, CodeData* params[], int params_count){
  InnerCode* code = malloc(sizeof(InnerCode));
  if(check_malloc(code) == -1){
    exit(-1);
  }

  code->params_count = params_count;
  for(int i = 0; i < params_count; i++){
    code->params[i] = malloc(sizeof(CodeData));
    if(check_malloc(code) == -1){
      exit(-1);
    }

    if(params[i]->name != NULL){
      code->params[i]->name = malloc(sizeof(char) * strlen(params[i]->name) + 1);
      strcpy(code->params[i]->name, params[i]->name);
    }
    else{
      code->params[i]->name = NULL;
    }

    if(params[i]->value != NULL){
      code->params[i]->value = malloc(sizeof(char) * strlen(params[i]->value) + 1);
      strcpy(code->params[i]->value, params[i]->value);
    }
    else{
      code->params[i]->value = NULL;
    }

    if(code->params[i]->frame != NULL){
      code->params[i]->frame = malloc(sizeof(char) * strlen(params[i]->frame) + 1);
      strcpy(code->params[i]->frame, params[i]->frame);
    }
    else{
      code->params[i]->frame = NULL;
    }

  }

  code->op_code = op_code;

  return code;
}

void free_inner_code(InnerCode* code){

  int i = 0;
  int size = code->params_count;

  while(i < size){
    free_code_data(code->params[i]);
    i++;
  }

  return;
}

void free_code_data(CodeData* data){

  free(data->name);
  free(data->value);
  free(data->frame);

  return;
}

void generate(InnerCode* code){

  switch(code->op_code){
    case C_ID:
      printf("%s@%s\n", code->params[0]->frame, code->params[0]->name);
      break;
    case C_FUNC:
      printf("function %s\n", code->params[0]->name);
      break;
    case C_LEN:
      printf("len %s\n", code->params[1]->name);
      break;
    default:
      printf("default\n");
      break;
  }
  return;
}
