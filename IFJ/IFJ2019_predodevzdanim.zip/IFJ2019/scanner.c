/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Tomas Majerech (xmajer18)                            *
 *	Date: 2.10.2019                                                 *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/
#include "scanner.h"

int check_dedent(int pocetMezer, int tmpVyska){

  int check = 0;

  for(int i = 0; i < tmpVyska; i++){
    if(pocetMezer != LexStack->array[i]){
      check = -1;
    }
    else{
      check = 0;
      break;
    }
  }

  return check;
}

int getToken(FILE * f, struct Token * t){
//    fprintf(stdout,"getToken enter\n");

    int len = 0;
    char c = 0;
    Tstate state = START;
    int STOP = 0;
    int FAIL = 0;

    int pocetMezer = 0;
    int tmpPocet = 0;
    int tmpVyska = 0;


    t->size = 50;
    //alokace zakladniho mista na obsah tokenu
    t->val = malloc(sizeof(char) * 50);
    if (t->val == NULL)
    {
        fprintf(stderr,"malloc fail, getToken - 1");
        exit(LEXICAL_ERROR);
    }

    //pročistím whitespace na začátku
    lTrim(f);

    if(bylEOF){

        if(LexStack->top < 0){
          exit(LEXICAL_ERROR);
        }else{
            t->type = T_DEDENT;
            return popLexStack(LexStack);
        }
    }

    if(bylEOL){
        pocetMezer = spoctiMezery(f);
        if(pocetMezer < min_level){
          call_error(LEXICAL_ERROR, LEXICAL_ERROR);
          exit(LEXICAL_ERROR);
        }

        if(pocetMezer > peekLexStack(LexStack)){
            pushLexStack(LexStack, pocetMezer);
            t->type = T_INDENT;

            bylEOL = 0;
            return pocetMezer;
        }else if(pocetMezer < peekLexStack(LexStack)){
            tmpVyska = LexStack->top;

            if(tmpVyska < 0){
                //dosli sme na dno zasobniku -> chyba
                fprintf(stderr, "sme pod dnem stacku \n");

                exit(LEXICAL_ERROR);
            }

            if(check_dedent(pocetMezer, tmpVyska) == -1){
              call_error(SYNTAX_ERROR, SYNTAX_ERROR);
              exit(SYNTAX_ERROR);
            }

            while(pocetMezer < peekLexStack(LexStack)){
              tmpPocet = popLexStack(LexStack);
            }

            t->type = T_DEDENT;
            bylEOL = 0;
            znovuDedent = 0;
            return pocetMezer;

          }

        bylEOL = 0;
    }


    //nastartujem čtení
    while(1) {

        c = getc(f);

        //dev
        //printf("while znak: %c \n",c);

        //tabulator
        if(state == START && c == '\t' ){
            t->type = T_TAB;
            t->val[0] = c;
            t->val[1] = '\0';
            return pocetMezer;
        }

        switch (state){
            case START:

                if(c == ':' || c == '(' || c == ')' || c == ',' || c == '*' || c == '-' || c == '+' ){
                    //operator
                    t->type = T_OPERATOR;
                    t->val[0] = c;
                    STOP = 1;
                }else if(c == ' ' ){
                //    break;
                    t->type = T_SPC;
                    t->val[0] = c;
                    STOP = 1;
                }else if(c == '/' ){
                    state = DIV;
                    t->type = T_OPERATOR;
                    t->val[0] = c;
                }else if(c == '>' ){
                    state = MT;
                    t->type = T_OPERATOR;
                    t->val[0] = c;
                }else if(c == '<' ){
                    state = LT;
                    t->type = T_OPERATOR;
                    t->val[0] = c;
                }else if(c == '=' ){
                    state = ASS;
                    t->type = T_OPERATOR;
                    t->val[0] = c;
                }else if(c == '!' ){
                    state = NEQ_X;
                    t->val[0] = c;
                }else if(c == '\n' ){
                    state = EOL;
                    t->type = T_EOL;
                    t->val[0] = c;
                    bylEOL = 1;
                    STOP = 1;
                }else if(c == '#' ){ //line comment
                    state = COM_LX;
                }else if(c == '"' ){ //BLOCK COMMENT
                    state = COM_X;
                }else if(c == '_' || ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') ){ //IDENTIFIKATOR
                    state = ID;
                    t->type = T_ID;
                    t->val[0] = c;
                }else if(c == '\'' ){ //string
                    state = STR_X;
                    //t->val[0] = c; //nechceme ve stringu uvozovky
                }else if(c == '0' ){ //ZERO
                    state = ZERO;
                    t->type = T_INTEGER;
                    t->val[0] = c;
                }else if( '1' <= c && c <= '9'  ){ //INT
                    state = INT;
                    t->type = T_INTEGER;
                    t->val[0] = c;
                }else if( c == EOF  ){ //end of file
                    state = EOFF;
                    t->type = T_EOF;
                    t->val[0] = c;
                    bylEOF = 1;
                    STOP = 1;
                }else{
                    FAIL = 1;
                }
                //printf("STARTLOOP: %d \n", state);
                break;//START


                // operatory
            case DIV:
                if(c == '/' ) {
                    state = IDIV;
                    t->type = T_OPERATOR;
                    t->val[++len] = c;
                }else{
                    ungetc(c,f);
                }
                STOP = 1;
                break;//DIV
            case MT:
                if(c == '=' ) {
                    state = MET;
                    t->type = T_OPERATOR;
                    t->val[++len] = c;
                }else{
                    ungetc(c,f);
                }
                STOP = 1;
                break;//MT
            case LT:
                if(c == '=' ) {
                    state = LET;
                    t->type = T_OPERATOR;
                    t->val[++len] = c;
                }else{
                    ungetc(c,f);
                }
                STOP = 1;
                break;//LT
            case ASS:
                if(c == '=' ) {
                    state = EQ;
                    t->type = T_OPERATOR;
                    t->val[++len] = c;
                }else{
                    ungetc(c,f);
                }
                STOP = 1;
                break;
            case NEQ_X:
                if(c == '=' ) {
                    state = NEQ;
                    t->type = T_OPERATOR;
                    t->val[++len] = c;
                }else{
                    FAIL = 1;
                }
                STOP = 1;
                break;

                //COMENTARE
            case COM_LX: //radkovy
                if(c != '\n'){
                    state = state;
                }else{
                  //  lTrim(f); //riznem bile znaky
                    ungetc(c, f);
                    state = START; //pokracujem k validnimu tokenu
                    //dev
              //      fprintf(stdout,"linecoment\n");
                }
                break;
                //blokovy
            case COM_X:
                if(c == '"'){
                    state = COM_X1;
                }else{
                    FAIL = 1;
                }
                break;
            case COM_X1:
                if(c == '"'){
                    state = COM_X2;
                }else{
                    FAIL = 1;
                }
                break;
            case COM_X2:
                if(c == '\\'){
                    state = COM_X3;
                }else if(c == '"'){
                    state = COM_X4;
                }
                else{
                    state = COM_X2; //zustavame
                }
                break;
            case COM_X3:
                if(c != EOF){
                    state = COM_X2;
                }else{
                    FAIL = 1;
                }
                break;
            case COM_X4:
                if(c == '"'){
                    state = COM_X5;
                }else if(c != EOF){
                    state = COM_X2;
                }else{
                    FAIL = 1;
                }
                break;
            case COM_X5:
                if(c == '"'){
                    state = START;
                    lTrim(f);
                }else if(c != EOF){
                    state = COM_X2;
                }else{
                    FAIL = 1;
                }
                break;

                //IDENTIFIKATOR
            case ID:
                if(c == '_' || ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('0' <= c && c <= '9')  ){
                    state = state;
                    t->val[++len] = c;
                }else{
                    ungetc(c,f);
                    t->type = T_ID;
                    STOP = 1;
                }
                break;

                //STRING
            case STR_X:
                if(c == '\''){
                    state = STR;
                    t->type = T_STRING;
                    t->val[len] = '\0'; //nechceme ve stringu uvozovky
                    STOP = 1;
                }else if(c == '\\'){
                    state = STR_X1;
                    t->val[len++] = c;
                }else if(c != EOF && c != '\n'){
                    state = state;
                    t->val[len++] = c;
                }else {
                    FAIL = 1;
                }
                break;
            case STR_X1:
                if(c == 'x'){
                    state = STR_HXX;
                    t->val[len++] = c;
                }else if(c == EOF || c == '\n' ){
                    FAIL = 1;
                }else{
                    state = STR_X;
                    t->val[len++] = c;
                }
                break;
            case STR_HXX:
                if(('a' <= c && c <= 'z') || ('A' <= c && c <= 'F') || ('0' <= c && c <= '9')){
                    state = STR_X;
                    t->val[len++] = c;
                }else{
                    FAIL = 1;
                }
                break;

                //cisla
            case INT:
                if('0' <= c && c <= '9'){
                    state = state;
                    t->val[++len] = c;
                } else if(c == 'e' || c == 'E'){
                    state = DBL_EX;
                    t->val[++len] = c;
                }else if(c == '.'){
                    state = DBL_X;
                    t->val[++len] = c;
                }else{
                    t->type = T_INTEGER;
                    ungetc(c,f);
                    STOP = 1;
                }
                break;
            case ZERO:
                if(c == '.'){
                    state = DBL_X;
                    t->val[++len] = c;
                }
                else if(isdigit(c)){
                    call_error(LEXICAL_ERROR, LEXICAL_ERROR);
                    exit(LEXICAL_ERROR);
                }
                else {
                    t->type = T_INTEGER;
                    ungetc(c,f);
                    STOP = 1;
                }
                break;
            case DBL_X:
                if('0' <= c && c <= '9'){
                    t->type = T_DBL;
                    state = DBL;
                    t->val[++len] = c;
                }else{
                    FAIL = 1;
                }
                break;
            case DBL:
                if('0' <= c && c <= '9'){
                    t->type = T_DBL;
                    state = state;
                    t->val[++len] = c;
                }else if( c == 'e' || c == 'E'){
                    state = DBL_EX;
                    t->val[++len] = c;
                }else{
                    ungetc(c,f);
                    STOP = 1;
                }
                break;
            case DBL_EX:
                if(c == '+' || c == '-'){
                    state = DBL_ESX;
                    t->val[++len] = c;
                }else if('0' <= c && c <= '9'){
                    state = DBL_E;
                    t->val[++len] = c;
                }else{
                    FAIL = 1;
                }
                break;
            case DBL_ESX:
                if('0' <= c && c <= '9'){
                    state = DBL_ES;
                    t->val[++len] = c;
                }else{
                    FAIL = 1;
                }
                break;
            case DBL_ES:
                if('0' <= c && c <= '9'){
                    t->type = T_DBL_ES;
                    state = state;
                    t->val[++len] = c;
                }else {
                    STOP = 1;
                    ungetc(c,f);
                }
                break;
            case DBL_E:
                if('0' <= c && c <= '9'){
                    t->type = T_DBL_E;
                    state = state;
                    t->val[++len] = c;
                }else {
                    STOP = 1;
                    ungetc(c,f);
                }
                break;

            default:
                FAIL = 1;
                fprintf(stderr, "DEFAULT CASE V LEXU  \n");
                break;

        }//end STATE switch


        if(FAIL == 1){
            //fprintf(stderr, "FAIL V LEXU\n");
            exit(LEXICAL_ERROR);
        }

        if(STOP == 1){ //koncime while
            break;
        }


        //musime prifouknout pole pro value
        if(t->size == len + 1){
            t->val = realloc(t->val,sizeof(char) * (t->size + 20));
            if (t->val == NULL)
            {
                fprintf(stderr,"realloc fail endwhile\n");
                exit(INTERNAL_ERROR);
            }
            t->size = t->size + 20;
        }

    }//END WHILE

    //token nebyl spravne urcen

    if(t->type == 0){
        fprintf(stderr,"token nebyl spravne urcen\n");
        exit(LEXICAL_ERROR);
    }

    //prida delku tokenu
    t->lentgh = ++len;

    //ukonci val (string)
    t->val[len] = '\0';

    return pocetMezer;
}//END GETTOKEN




//ořízne bílé znaky před tokenem, EOL nechává, tab je token
int lTrim(FILE * f){
    char c = fgetc(f);
    int i = 1;
    while (c == '\v' || c == '\f' || c == '\r' || c == '\t' || (c == ' ' && !bylEOL) ){
        c = fgetc(f);
    //    fprintf(stderr,"lTRIM: %c \n", c);
        i++;

    }
    //vratime se pred znak ktery uz nechceme filtrovat
    ungetc(c,f);
    i--;

    return i;

}

// počáteční inicializace tokenu t
void initToken(struct Token * t)
{
    t->val = NULL;
    t->lentgh = 0;
    t->size = 0;
    t->type = 0;
	t->Terminal_state = S_TERM;
}

// uvolní paměť atributu val v tokenu t a reinicializuje token
void resetToken(struct Token *t)
{
    if (t->val != NULL)
    {
        free(t->val);
        t->val = NULL;
    }
    t->lentgh = 0;
    t->size = 0;
    t->type = 6;
	t->Terminal_state = S_TERM;
}

int spoctiMezery(FILE * f){
    char c = fgetc(f);
    int i = 1;
    while (c == ' ' ){
        c = fgetc(f);

        i++;
    }

//    fprintf(stderr,"spoctimezery: %d \n", i);

    //zacatek radkoveho komentare
    if(c == '#'){
        while(c != '\n' && c != EOF){
            c = fgetc(f);
        }
        return spoctiMezery(f);
    }
    if(c == '\n'){
        return spoctiMezery(f);
    }

    //vratime se pred znak ktery uz nechceme filtrovat
    ungetc(c,f);
    i--;

    return i;

}










/********
 * ZASOBNIK A JEHO VECI
 */


//inicializace
struct LexStack* createLexStack(){
    struct LexStack* stack = (struct LexStack*)malloc(sizeof(struct LexStack));
    stack->capacity = 2000;
    stack->top = -1;
    stack->array = (int*)malloc(stack->capacity * sizeof(int));
    pushLexStack(stack,0);
    return stack;
}

int isEmptyLexStack(struct LexStack* stack)
{
    return stack->array[stack->top] == 0;
}

void pushLexStack(struct LexStack* stack, int item)
{
    stack->array[++(stack->top)] = item;
  //  printf("%d pushed to stack\n", item);
}

int popLexStack(struct LexStack* stack)
{

    return stack->array[(stack->top)--];
}

int peekLexStack(struct LexStack* stack)
{
    return stack->array[stack->top];
}
