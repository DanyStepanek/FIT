var searchData=
[
  ['takescreenshot',['takeScreenShot',['../structArguments.html#aa5763070ed323e09f16efd294aa0315a',1,'Arguments']]],
  ['todo_20list',['Todo List',['../todo.html',1,'']]],
  ['translate_5fmat4',['translate_Mat4',['../linearAlgebra_8c.html#a4ea2f3b452065b47f0068eb9b4cc4ca9',1,'translate_Mat4(Mat4 *const output, float const tx, float const ty, float const tz):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a4ea2f3b452065b47f0068eb9b4cc4ca9',1,'translate_Mat4(Mat4 *const output, float const tx, float const ty, float const tz):&#160;linearAlgebra.c']]],
  ['transpose_5fmat4',['transpose_Mat4',['../linearAlgebra_8c.html#af2abaae108c4a9bfb7c97e96e0b929be',1,'transpose_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#af2abaae108c4a9bfb7c97e96e0b929be',1,'transpose_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c']]],
  ['triangle3ddata',['Triangle3dData',['../structTriangle3dData.html',1,'']]],
  ['triangledata',['TriangleData',['../structTriangleData.html',1,'']]],
  ['type',['type',['../structGPUUniform.html#acff779e71ac51bdf6849cc509cf45a4c',1,'GPUUniform::type()'],['../structGPUVertexPullerHead.html#a9089a3fc5f91332981d4fc5cb9c0226c',1,'GPUVertexPullerHead::type()'],['../structGPUIndices.html#aab36cd5f0fb486ff3b6e91e89006f3b4',1,'GPUIndices::type()'],['../structGPUCommand.html#acd0826c4736e3a3275e99b359f9d99aa',1,'GPUCommand::type()']]]
];
