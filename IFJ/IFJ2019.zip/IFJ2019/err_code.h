/********************************************************************
 *	IFJ projekt: "Implementace prekladace                           *
 *				  imperativniho jazyka IFJ19."                            *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 30.10.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#ifndef IFJ_ERR_CODE_H
#define IFJ_ERR_CODE_H

#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>

#define DEBUG_OUTPUT 0
#define	LEXICAL_ERROR 1
#define	SYNTAX_ERROR 2
#define	SEMANTIC_ERROR 3
#define	INTERNAL_ERROR 99


typedef enum err_code{
    ERR_LEX               = 1,
    ERR_SYNTAX            = 2,
    ERR_SEMANTIC          = 3,
    ERR_ZERO_DIVISION     = 9,
    ERR_INTERNAL          = 99,
    /*TODO*/


} ERR_CODE;

int call_error(int code, int specific);

#endif
