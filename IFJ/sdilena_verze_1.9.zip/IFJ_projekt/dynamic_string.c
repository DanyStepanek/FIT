
#include "dynamic_string.h"

#define DYNAMIC_STRING_LENGTH 10

bool init_DString(DString *s){
	
	s = malloc(sizeof(DString));
	s->string = (char *) malloc(DYNAMIC_STRING_LENGTH);
	if(s->string == NULL) return false;
	
	s->length = 0;
	s->string[s->length] = '\0';
	return true;
}

int fill_DString(DString *s, char* inputs){

	int new_size = 0;

	if(s != NULL  && inputs != NULL){  // kontrola spravnosti ukazatelu
		if(strlen(inputs) >= s->length){
			new_size = strlen(inputs) + 1;
			s->string =  (char*) realloc(s->string, new_size); // alokace pameti pro pole znaku
		}
		
		if(s->string != NULL){		// kontrola alokace pameti
			strcpy(s->string, inputs);	// vlozeni stringu do alok. pam
			s->length += new_size;
			s->aloc = new_size;
			return 0;
		}
		else {
			return -1;
		}

	}
	else {
		return -1;
	}

}

bool addstr_DString(DString *s, char* inputs){

	unsigned int inputs_len = strlen(inputs);
	
	if(s->length <= (inputs_len + 1)){
		int new_size = s->length + inputs_len + 1;		
		s->string = (char*) realloc(s->string, new_size);
		if(s->string == NULL){
			fprintf(stderr,"Reallocation failed\n");
			return false;
		}

		s->aloc = new_size;
	}
	
	
	s->length += strlen(inputs);
	strcat(s->string, inputs);
	s->string[s->length] = '\0';

	return true;
}

void free_DString(DString *s){
	
	free(s->string);
	free(s);
	
	
}