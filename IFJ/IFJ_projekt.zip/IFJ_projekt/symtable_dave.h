/*
	autor: David Triska
	login: xtrisk05
*/


#ifndef SYMTABLE_H_INCLUDED
#define SYMTABLE_H_INCLUDED

#include <stdbool.h>
#include "RString.h"
typedef enum{
	tNIL,			//kvuli scanneru (tNIL) protoze tam uz  je NIL jednou definovany
	INT,
	FLOAT,
	//CHAR,
	STRING
}dat_type_enum;

typedef enum{
	CONSTANT,
	VARIABLE,
	FUNCTION,
	UNKNOWN
}catg_enum;


typedef struct Node{
	unsigned long id;
	struct Node * l_ptr;
	struct Node * r_ptr;
	struct Data * data;
} Node;

typedef struct Data{
	dat_type_enum dat_type;
	catg_enum category;
	RString * name;
	int int_val;
	float float_val;
	bool fun;
	RString * string_val;
	int argc;
	RString * argv; // fill_RString(data.argv, "param1$param2$param3");
	Node *local_tab;
} Data;

/*
	DJB2 pro vytvoreni unikatniho klice uzlu stromu, z jeho identifikatrou
	http://www.cse.yorku.ca/~oz/hash.html
*/
unsigned long djb2(char* , int );

/*---------------------------------------------------*/
/*				   Node								 */
/****************************************************/

void Node_init(Node** );
/*
	Funkce vytvori novy uzel, pokud neexistuje, pokud existuje aktualizuje jeho category
*/

/*
	Vraci ukazatel na nove vytvorenou instanci Data, pokud se jedna o funkci volat Data_fce_fill
	@param catg_enum cat - kategorie (constant, variable, function)
	@param Data * data - ukazatel na strukturu Data, ze ktery prekopiruje udaje 

*/
Data* Data_construct( Data * );
void Data_name(Data*, char*, int);
void Data_stringVal(Data*, char*, int );
void Data_intVal(Data*, char*);
void Data_floatVal(Data*, char*);
void Data_isFunction(Data*);
void Data_locTabNodeAdd(Data*, catg_enum, Data*);
void Data_functionArgAdd(Data*, char*, int);
void Data_locTabNodeAdd(Data*, catg_enum, Data*);
void Data_reset(Data*);
void Data_changeCat(Data*, catg_enum);
/*	
	@param Node** root - ukazatel na uzel
	
*/
void Node_create(Node**, Data * );
Node* find_Node(Node** , char* );
void print_tree(Node** );
void Node_delete(Node** , char* );
void Tree_delete(Node** );

#endif
