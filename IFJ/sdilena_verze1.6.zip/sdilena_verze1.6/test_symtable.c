#include "symtable.h"


//void Data_function(Data*data, int argc, )

int main(){
	
	Node *root;					//ukazatel na korenovy uzel
	Data data;					//instance dat, pres kterou budeme vytvaret nove uzly
	Node_init(&root);			
	data.name = init_RString();	rewrite_RString(data.name, "", 1);
	data.argv = init_RString();	rewrite_RString(data.name, "", 1);

	////////////////////////////prvni uzel, funkce
		rewrite_RString(data.name, "ahoj", strlen("ahoj") );
		data.argc = 3; 
		data.dat_type = 0;
		data.local_tab = NULL;
		rewrite_RString(data.argv, "param1$param2$param3", strlen("param1$param2$param3"));
		
		Node_create(&root, 0 , &data);
	/////////////////////////////////////////


	////////////////////////////////////druhy uzel, int promenna
		rewrite_RString(data.name, "ahojfsaf", strlen("ahojfsaf") );
		data.int_val = 458;

		Node_create(&root, VARIABLE , &data);
	////////////////////////////////////////////////////////////

	/////////////////////////////////////////treti uzel	
	data.dat_type = 2;
	rewrite_RString(data.name, "polibmimarku", strlen("polibmimarku"));
	
	Node_create(&root, CONSTANT, &data);
	////////////////////////////////////////////////////////////////

	Node *hledany;
	Node_init(&hledany);

	hledany = find_Node(&root, "ahojfsaf");
	print_tree(&root);
	Node_delete(&root, "ahojfsaf");
	printf("po vymazani 'ahojfsaf' \n------------------------------------\n");


		
	print_tree(&root);

	Tree_delete(&root);

	Node_delete(&hledany, hledany->data->name->string);

	free_RString(data.name);
	free_RString(data.argv);
	
	printf("deleting\n");
	print_tree(&root);
	
	return 0;
}