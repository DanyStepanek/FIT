#ifndef STACK_H
#define STACK_H
#include <stdio.h>
#include <stdlib.h>

#define EMPTY 0
#define DATA_INIT_SIZE 30
#define DATA_RESIZE_CHUNK 10

// datov� typ z�sobn�k
typedef struct tstack
{
	void* ptr; // ukazatel na data
	int top; // index vrcholu
	int size; // kapacita
} Tstack;

// inicializuje z�sobn�k name na typ type s po��te�n� kapacitou DATA_INIT_SIZE 
#define stackinit(name, type) \
{\
    (name)->ptr = malloc(sizeof(type) * DATA_INIT_SIZE);\
    (name)->size = DATA_INIT_SIZE;\
    (name)->top = EMPTY;\
}
// zv�t�� kapacitu z�sobn�ku o DATA_RESIZE_CHUNK
#define stackresize(name, type) \
{\
    (name)->ptr = realloc((name)->ptr, sizeof(type) * ((name)->size + DATA_RESIZE_CHUNK));\
    (name)->size = (name)->size + DATA_RESIZE_CHUNK;\
}
// vlo�� na vrchol z�sobn�ku hodnotu var s typem type
# define stackpush(name,type, var) \
{\
    *((type*)(name)->ptr + (name)->top) = var;\
    (name)->top = (name)->top + 1;\
}
// vr�t� hodnotu z vrcholu z�sobn�ku s typem type
#define stacktop(name, type) *((type*)name->ptr + (name->top - 1))

// sma�e hodnotu vrcholu z�sobn�ku
void stackpop(Tstack* s);
// vr�t� 1 pokud je z�sobn�k pln�
int stackfull(Tstack* s);
// vr�t� 1 pokud je z�sobn�k pr�zdn�
int stackempty(Tstack* s);
// uvoln� pam� dat z�sobn�ku
void stackdispose(Tstack* s);
// vr�t� 1 pokud byla �sp�n� alokovan� pam� pro data
int stackinitsucc(Tstack* s);


#define CheckSize(name, type)\
{\
	if (stackfull(name))\
	{\
		stackresize(name,type);\
	}\
}\

#endif
