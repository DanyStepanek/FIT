var searchData=
[
  ['parameters',['parameters',['../structGPUCommand.html#a1c5e80394a5f4183597746a3de06357e',1,'GPUCommand']]],
  ['phongdata',['phongData',['../group__cpu__side.html#gaf80898fd19b8fe287ae668bf03e6de72',1,'phongMethod.c']]],
  ['position',['position',['../structBunnyVertex.html#a2d228a475dea955ec6c696ee545ac731',1,'BunnyVertex']]],
  ['prg',['prg',['../structPhongData.html#abe8d787c8d298a58614c7d98dbf43a91',1,'PhongData::prg()'],['../structPointBoxData.html#acec81e47d56286a7994aef662694fc42',1,'PointBoxData::prg()'],['../structPointCircleData.html#a91256a054d456b6c3f661d1fc90c2038',1,'PointCircleData::prg()'],['../structPointData.html#ae5c008d1b00565769b1467128a348c21',1,'PointData::prg()'],['../structPointSquareData.html#ad5b410843ab9cbbde5701a75eccbd0e0',1,'PointSquareData::prg()'],['../structTriangle3dData.html#abfd2853f289db26e7c2bef0bdc6930f5',1,'Triangle3dData::prg()'],['../structTriangleData.html#a9bdda6d3ffdde266d800f8b8461e5c36',1,'TriangleData::prg()']]],
  ['programs',['programs',['../structGPUPrograms.html#acd9c5b21b7e31c1ad4c31310606e9bc0',1,'GPUPrograms::programs()'],['../structGPU.html#a78eb40077ccd6d3c43805961cfb69917',1,'GPU::programs()']]],
  ['projectionmatrix',['projectionMatrix',['../globals_8c.html#a1f344d924f733a22d7659db612a0efe8',1,'projectionMatrix():&#160;globals.c'],['../globals_8h.html#a1f344d924f733a22d7659db612a0efe8',1,'projectionMatrix():&#160;globals.c']]],
  ['pullers',['pullers',['../structGPUVertexPullers.html#aebb98d9d41cb7c160972337cb8805ce8',1,'GPUVertexPullers::pullers()'],['../structGPU.html#a1463956b595e58bdbc5221d995173fd6',1,'GPU::pullers()']]]
];
