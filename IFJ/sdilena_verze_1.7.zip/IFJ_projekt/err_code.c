#include "err_code.h"
int j = 0;

int call_error(int code, int line){
	
	if(j < 100){
		num_of_lines[j] = line;
		j++;
		num_of_lines[j] = -1;
	}	
	else			//more than 100 errors
		return 100;
	
	ERR_CODE type = code;
	
	switch (type){

	case 2:
		fprintf(stderr,"%d:LEX_ERROR\n", line);
		break;
	case 4:
		fprintf(stderr,"SYNTAX_ERROR\n");
		break;
	case 6:
		fprintf(stderr,"SEMANTIC_ERROR\n");
		break;
	case 8:
		fprintf(stderr,"ZERO_DIVISION_ERROR\n");
		break;
	case 10:
		fprintf(stderr,"INCOMPATIBLE_TYPE_ERROR\n");
		break;
	case 12:
		fprintf(stderr,"NUMERIC_CONVERSION\n");
		break;
/*	case 14:
		fprintf(stderr,"LEX_ERROR\n");
		break;
	case 16:
		fprintf(stderr,"LEX_ERROR\n");
		break;
	case 18:
		fprintf(stderr,"LEX_ERROR\n");
		break;
	case 20:
		fprintf(stderr,"LEX_ERROR\n");
		break;
	*/
	}
	
	return code;
	
}	
