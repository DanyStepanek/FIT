/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 25.11.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/


 #ifndef IFJ_LIST_H
 #define IFJ_LIST_H

 #include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include "symtable.h"
 #include "err_code.h"
 #include "other_functions.h"



  struct TItem{
    char* table_name; //jmeno funkce
    char* params[100]; //parametry funkce
    int params_count;
    STable* table;
    struct TItem* next;
    struct TItem* prev;
  };

  typedef struct {
    struct TItem* first;
    struct TItem* act;
    int count;
  } TList;



  void list_init(TList* l);

  void list_clear(TList* l);

/* Returns if empty 1 else 0
 *
 *
 */
int list_empty(TList* l);

/* Returns 1 if in table else 0
 *
 *
 */
int in_list(TList* t, char* name);

/*
 *  Predpoklad: l->act ukazuje na posledni vlozeny prvek, tudiz staci vlozit za aktivni a prenest aktivitu
 *
 */
void list_insert_item(TList* l, STable* item, char* table_name, char** params, int params_count);

/*
 * Vraci tabulku pokud je v seznamu, jinak NULL. Predava pocet parametru a samotne parametry pres parametry
 * params, params_count.
 */
STable* list_get_item(TList* l, char* table_name, char** params, int* params_count);

 #endif
