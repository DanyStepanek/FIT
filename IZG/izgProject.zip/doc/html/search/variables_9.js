var searchData=
[
  ['lightposition',['lightPosition',['../globals_8c.html#a1dca963621731fbfc9099646aa00a723',1,'lightPosition():&#160;globals.c'],['../globals_8h.html#a1dca963621731fbfc9099646aa00a723',1,'lightPosition():&#160;globals.c']]]
];
