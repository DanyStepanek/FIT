/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 2.10.2019                                                 *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/
 #ifndef IFJ_SYMTABLE_H
 #define IFJ_SYMTABLE_H

#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include "err_code.h"


#define MAX_SYMTABLE_SIZE 27457

#define DEBUG_OUTPUT 0


struct TData{
  char* name;
  char* value;
  int type;
  struct TData* next;
};

typedef struct {
  int items_count;
  int size;
  struct TData* items[MAX_SYMTABLE_SIZE];
} STable;


/*
 * Inicializace tabulky symbolu.
 */
void init_table(STable *t);

/*
 * Pokud je polozka s klicem key v tabulce, vraci 1 jinak 0.
 *
 *
 */
int in_table(STable* t, char* key);

/**
 * Calculates index to table (hash).
 * GNU Hash ELF. Algorithm implementation used in UNIX ELF.
 * @link https://blogs.oracle.com/ali/gnu-hash-elf-sections
 * @link https://en.wikipedia.org/wiki/PJW_hash_function
 *
 * @param str String from which hash will be calculated.
 * @return Returns calculated hash.
 */
int get_hashkey(char* str);

/*
 * Vlozi polozku typu TData do tabulky symbolu.
 */
void put_item(STable* t, struct TData* data);

/*
 * Uvolni vsechny polozky v tabulce.
 */
void clear_table(STable* t);

/*
 * Vrati data typu TData z tabulky. Predpoklada se zavolani funkce
 * in_table() pred zavolanim teto funkce. Jinak hrozi segfault.
 */
void get_item(STable* t, struct TData* data, char* key);


#endif
