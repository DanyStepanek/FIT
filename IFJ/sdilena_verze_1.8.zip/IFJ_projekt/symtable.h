/*
	autor: David Triska
	login: xtrisk05
*/


#ifndef SYMTABLE_H_INCLUDED
#define SYMTABLE_H_INCLUDED

#include "RString.h"

typedef struct Node{
	unsigned long id;
	int category;
	struct Node * l_ptr;
	struct Node * r_ptr;
	struct Data * data;
} Node;

typedef struct Data{
	int dat_type;
	RString * name;
	int int_val;
	float float_val;
	char char_val;
	RString * string_val;
	int argc;
	RString * argv; // fill_RString(data.argv, "param1$param2$param3");
	Node *local_tab;
} Data;

/*
	DJB2 pro vytvoreni unikatniho klice uzlu stromu, z jeho identifikatrou
	http://www.cse.yorku.ca/~oz/hash.html
*/
unsigned long djb2(char* , int );

/*---------------------------------------------------*/
/*				   Node								 */
/****************************************************/
typedef enum{
	tNIL,			//kvuli scanneru (tNIL) protoze tam uz  je NIL jednou definovany
	INT,
	FLOAT,
	CHAR,
	STRING
}dat_type_enum;

typedef enum{
	CONSTANT,
	VARIABLE,
	FUNCTION
}catg_enum;

void Node_init(Node** );
/*
	Funkce vytvori novy uzel, pokud neexistuje, pokud existuje aktualizuje jeho category
*/

/*
	Vraci ukazatel na nove vytvorenou instanci Data, pokud se jedna o funkci volat Data_fce_fill
	@param catg_enum cat - kategorie (constant, variable, function)
	@param Data * data - ukazatel na strukturu Data, ze ktery prekopiruje udaje 

*/
Data* Data_construct(catg_enum , Data * );
/*	
	@param Node** root - ukazatel na uzel
	
*/
void Node_create(Node** ,catg_enum , Data * );
Node* find_Node(Node** , char* );
void print_tree(Node** );
void Node_delete(Node** , char* );
void Tree_delete(Node** );

#endif
