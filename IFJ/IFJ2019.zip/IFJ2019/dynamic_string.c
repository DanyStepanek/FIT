//
// Created by juraj on 03.12.19.
//

#include "dynamic_string.h"
#include <stdlib.h>
#include <string.h>

#define ERROR 0
#define SUCCES 1

int string_init(Dynamic_string *s) {
    if ((s->str = (char *) malloc(STRING_LENGTH_INC)) == NULL) {
        return ERROR;
    }
    s->str[0] = '\0';
    s->length = 0;
    s->allocSize = STRING_LENGTH_INC;
    return SUCCES;
}

void string_free(Dynamic_string *s) {
    free(s->str);
}

void string_clear(Dynamic_string *s) {
    s->str[0] = '\0';
    s->length = 0;
}

int string_add_char(Dynamic_string *s, char c) {
    if ((s->length + 1) >= s->allocSize) {
        if ((s->str = (char *) realloc(s->str, s->length + STRING_LENGTH_INC)) == NULL) {
            return ERROR;
        }
        s->allocSize = s->length + STRING_LENGTH_INC;
    }
    s->str[s->length] = c;
    (s->length)++;
    s->str[s->length] = '\0';
    return SUCCES;
}

int string_add_Cstr(Dynamic_string *s1, char *s2) {
    if ((s1->length + strlen(s2)) >= s1->allocSize) {
        if ((s1->str = (char *) realloc(s1->str, s1->length + strlen(s2) + STRING_LENGTH_INC)) == NULL) {
            return ERROR;
        }
        s1->allocSize = s1->length +  (unsigned)strlen(s2) + STRING_LENGTH_INC;
    }
    strcat(&(s1->str[s1->length]), s2);
    s1->length += strlen(s2);
    s1->str[s1->length] = '\0';
    return SUCCES;
}

int string_copy_Cstr(Dynamic_string *s1, char *s2) {
    unsigned newLength = (unsigned)strlen(s2);
    if (newLength >= s1->allocSize) {
        // not enough memory allocated for s1
        if ((s1->str = (char*) realloc(s1->str, newLength + 1)) == NULL)
            return ERROR;
        s1->allocSize = newLength + 1;
    }
    strcpy(s1->str, s2);
    s1->length = newLength;
    return SUCCES;
}

char *string_get_string(Dynamic_string *s) {
    return s->str;
}