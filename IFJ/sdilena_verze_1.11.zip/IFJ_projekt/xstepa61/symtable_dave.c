#include "symtable.h"


unsigned long djb2(char *str, int slength)
{
        unsigned long h = 5381;
        int c;
        int i = 0;

        while (i < slength){
           	c = *str++;
            h = ((h << 5) + h) + c; /* h * 33 + c */
        	i++;
        }	
        return h;
}	


void Data_name(Data* data, char* name, int nameLen){
	data->name = init_RString();
	fill_RString(data->name, name, nameLen);

}

void Data_stringVal(Data* data, char* name, int nameLen){
	data->dat_type = STRING;
	data->string_val = init_RString();
	fill_RString(data->string_val, name, nameLen);

}

void Data_intVal(Data* data, char* num){
	data->dat_type = INT;
	data->int_val = atoi(num);
}

void Data_floatVal(Data* data, char* num){
	data->dat_type = FLOAT;
	data->float_val = atof(num);
}

void Data_isFunction(Data *data){
	data->fun = true;
	data->local_tab = NULL;
}

void Data_changeCat(Data* data, catg_enum cat){

	data->category = cat;

	if (cat == FUNCTION){

		Data_isFunction(data);
	}

}

void Data_reset(Data *data){

	if( data->dat_type == STRING){
		free_RString(data->string_val);
	}

	if( data->argc > 0){
		free_RString(data->argv);
		data->argc = 0;
		data->fun = false;
	}

	free_RString(data->name);

	data->int_val = 0;
	data->float_val = 0;
	data->dat_type = tNIL;
	data->category = UNKNOWN;

	// if( data->local_tab != NULL){
	// 	Tree_delete(&data->local_tab);
	// }

}
// void Data_locTabNodeAdd(Data * data,catg_enum category ,Data * loc){

// 	Node_create(data->local_tab, category, loc);
// }

void Data_functionArgAdd(Data* data, char* param, int len){

	char* storedParams = NULL;
	int newLen = len;

	if(data->fun){

		if(data->argc > 0){					//uz jsou nektere argumenty ulozeny
			newLen += data->argv->size;
			strcpy(storedParams, data->argv->string);
			strcat(storedParams, "$");			
			strcat(storedParams, param);

			free_RString(data->argv);
			data->argv = init_RString();
			fill_RString(data->argv, storedParams, newLen);

			data->argc += 1;

		}else{
			data->argv = init_RString();
			fill_RString(data->argv, param, len);
			data->argc += 1;
		}
	}

}


void Node_init(Node **node){
	*node = NULL;
}

// void Node_create(Node** root, catg_enum cat, char* name, int nameLen){

// 	if(*root == NULL){			//prazdny uzel

// 		printf("Tvorba\n");

// 		*root = malloc(sizeof(struct Node));		//alokace pameti pro uzel (ne pro jeho data!)

// 		if(*root == NULL){
// 			fprintf(stderr, "Node_insert chyba alokace pameti (symtable.c:14)\n");
// 			return;
// 		} else{

// 			(*root)->data = malloc(sizeof(struct Data));
// 			//(*root)->data = Data_construct(cat,dType,name, nameLen, ival, fval, cval, sval, slen, argc);

// 			if((*root)->data != NULL){

// 				(*root)->l_ptr = NULL;
// 				(*root)->r_ptr = NULL;
// 				(*root)->category = cat;
// 				(*root)->id = djb2(name, nameLen);
// 			//printf(" root: %d id, %d catagory\n",root->id, root->category);

// 			}else{
// 				fprintf(stderr, "Node_insert chyba alokace pameti (symtable.c:26)\n");
// 				return;
// 			}

// 		}
	
// 	}else{



// 		if((*root)->id == djb2(name, nameLen) ){					//aktualizace uzlu
		
// 			(*root)->category = cat;
// 			printf("Aktualizace\n");
			

// 		}else if((*root)->id <djb2(name, nameLen)){			//v pravo 

// 			Node_create(&(*root)->r_ptr, cat, name, nameLen);

// 		}else if((*root)->id > djb2(name, nameLen)){			//v levo

// 			Node_create(&(*root)->l_ptr, cat, name, nameLen);

// 		}
// 	}

// //	printf(" root: %d id, %d catagory\n",root->id, root->category);


// }

void Node_create(Node** root, Data * data){

	if(*root == NULL){			//prazdny uzel

		printf("Tvorba\n");

		*root = malloc(sizeof(struct Node));		//alokace pameti pro uzel (ne pro jeho data!)

		if(*root == NULL){
			fprintf(stderr, "Node_insert chyba alokace pameti (symtable.c:14)\n");
			return;
		} else{

			//(*root)->data = malloc(sizeof(struct Data));
			(*root)->data = Data_construct(data);

			if((*root)->data != NULL){

				(*root)->l_ptr = NULL;
				(*root)->r_ptr = NULL;
				(*root)->id = djb2(data->name->string, data->name->size);
			//printf(" root: %d id, %d catagory\n",root->id, root->category);

			}else{
				fprintf(stderr, "Node_insert chyba alokace pameti (symtable.c:26)\n");
				return;
			}

		}
	
	}else{



		if((*root)->id == djb2(data->name->string, data->name->size) && strcmp((*root)->data->name->string, data->name->string)==0 ){					//aktualizace uzlu
		
			//(*root)->category = cat;
			(*root)->data = data;
			printf("Aktualizace\n");
			

		}else if((*root)->id <djb2(data->name->string, data->name->size)){			//v pravo 

			Node_create(&(*root)->r_ptr, data);

		}else if((*root)->id > djb2(data->name->string, data->name->size)){			//v levo

			Node_create(&(*root)->l_ptr, data);

		}
	}

//	printf(" root: %d id, %d catagory\n",root->id, root->category);


}


Data* Data_construct( Data * data)
{
	Data* nDat = malloc(sizeof(struct Data));
	
	if(nDat != NULL){

		nDat->dat_type = data->dat_type;
		nDat->name = init_RString();		
		fill_RString(nDat->name, data->name->string, data->name->aloc);
		
		switch(data->category){

			case UNKNOWN: case CONSTANT: case VARIABLE: 

				switch(data->dat_type){

					case tNIL:
						break;

					case INT:
						nDat->int_val = data->int_val;
						break;

					case FLOAT:
						nDat->float_val = data->float_val;
						break;

					case STRING:
						nDat->string_val = init_RString();
						fill_RString(nDat->string_val, data->string_val->string, data->string_val->size);
						break;
				}

				break;

			case FUNCTION:

				nDat->fun = true;
				nDat->argc = data->argc;

				if(data->argc > 0){
					// nDat->argv = init_RString();
					// fill_RString(nDat->argv, data->argv->string, data->argv->size);
				}

				break;
		}

		return nDat;

	}else{
		fprintf(stderr, "Data_construct chyba alokace pameti (symtable.c:81)\n");
		return NULL;
	}

}

void print_tree(Node** root){
	static int i = 0;


	if(*root != NULL){
		//printf("NOT NULL");
		printf("%d) root: %lu id, %d category, %d dat.type, %s name, %d int_val\n", i, (*root)->id, (*root)->data->category, (*root)->data->dat_type, (*root)->data->name->string, (*root)->data->int_val);
		i++;
		print_tree(&(*root)->l_ptr);
		print_tree(&(*root)->r_ptr);
		//i = 0;
	}else{
		//printf("NULL\n");
	}
}


Node* find_Node(Node** node, char* name){

	unsigned long id = djb2(name, strlen(name));

	if(*node != NULL){

		if(strcmp(name, (*node)->data->name->string) == 0){	//nalezly jsme hledany uzel

			Node* newNode;
			Node_init(&newNode);
			Node_create(&newNode, (*node)->data);

			return newNode;

		}else{

			if( id > (*node)->id){			//pruchod v pravo
				return find_Node(&(*node)->r_ptr, name);
			}
			
			if( id < (*node)->id){			//pruchod v pravo
				return find_Node(&(*node)->l_ptr, name);
			}
		}

	}

	return NULL;
}

void Data_delete(Node** node){

	free_RString((*node)->data->name);					//uvolneni pameti pro text identifikator
	
	if((*node)->data->category == 0 || (*node)->data->category == 1 || (*node)->data->category == 3){	//jedna se o konstantu nebo promenou

		if((*node)->data->dat_type == STRING){			//byla alokovana pamet pro retezec

			free_RString((*node)->data->string_val);	//uvolneni pameti pro hodnotu retezce
		}
		


	}else if((*node)->data->category == 2){					//jedna se funkci

		
		if((*node)->data->argc > 0){

			free_RString((*node)->data->argv);
		}										
		
	}

	free((*node)->data);

}

void ReplaceByMostRight(Node* replaced, Node** root){

	if(root != NULL){
	
		if((*root)->r_ptr == NULL){
	
			// replaced->id = (*root)->id;
			// replaced->category = (*root)->category;
			// replace->l_ptr = ()
			// replaced->data = (*root)->data;
			
			replaced = (*root);
		
		}else{
			ReplaceByMostRight(replaced, &(*root)->r_ptr);
		}
	}
}

void Node_delete(Node** node, char* name){

	Node* tmp = NULL;
	//Node** dataTmp = NULL;
	unsigned long id = djb2(name, strlen(name));

	if((*node) != NULL){

		if(strcmp((*node)->data->name->string, name) == 0){			//shoda

			tmp = *node;			//docasne ulozeni mazaneho prvku
			//dataTmp = node;
			if((*node)->l_ptr == NULL && (*node)->r_ptr == NULL){		//uzel nema zadne syny
				
				//printf("CHILDLES FOUND\n");

				Data_delete(node);

				free(*node);						//uvolneni uzlu
				*node = NULL;
				

			}else if((*node)->l_ptr == NULL && (*node)->r_ptr != NULL){	// pouze pravy podstrom

				// printf("R CHILD\n");


				*node = (*node)->r_ptr;
				Data_delete(&tmp);
				free(tmp);

			}else if((*node)->l_ptr != NULL && (*node)->r_ptr == NULL){	//pouze levy podstrom

				// printf("L CHILD\n");

				*node = (*node)->l_ptr;
				Data_delete(&tmp);
				free(tmp);

			}else if((*node)->l_ptr != NULL && (*node)->r_ptr != NULL){	// oba podstromy

				//printf("LR CHILD\n");

				ReplaceByMostRight(tmp, &(*node)->l_ptr);
				Node_delete(&(*node)->l_ptr,name);

			}


		}else{
			//printf("ziju\n");
			

			if(id > (*node)->id){
				
				if((*node)->r_ptr != NULL){
					Node_delete(&(*node)->r_ptr, name);	
				
				}
			}else if( id < (*node)->id){
				if((*node)->l_ptr != NULL){
				
					Node_delete(&(*node)->l_ptr, name);	
				
				}
			}

		}

	}
}

void Tree_delete(Node** root){
	if(*root != NULL){

		if((*root)->l_ptr != NULL){
			Tree_delete(&(*root)->l_ptr);
		}

		if((*root)->r_ptr != NULL){
			Tree_delete(&(*root)->r_ptr);
		}

		if((*root)->r_ptr == NULL && (*root)->l_ptr == NULL){
			
			// free(*root);
			// *root = NULL;
			Node_delete(root, (*root)->data->name->string);

		}

	}
}