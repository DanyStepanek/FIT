/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Juraj Lazorik (xlazor02)                             *
 *	Date: 11.12.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#include "generator_j.h"

#define built_in_function_len                           \
        "\nLABEL &length"                               \
        "\nPUSHFRAME"                                   \
        "\nDEFVAR LF@&return"                           \
        "\nSTRLEN LF@&return LF@%1"                     \
        "\nPOPFRAME"                                    \
        "\nRETURN\n"

#define built_in_function_substr                        \
        "\nLABEL &substr"                               \
        "\nPUSHFRAME"                                   \
        "\nDEFVAR LF@&return"                           \
        "\nDEFVAR LF@length"                            \
        "\nDEFVAR LF@help"                              \
        "\nDEFVAR LF@string"                            \
        "\nDEFVAR LF@bool"                              \
        "\nDEFVAR LF@index"                             \
        "\nMOVE LF@string string@"                      \
        "\nMOVE LF@index LF@%2"                         \
        "\nSTRLEN LF@length LF@%1"                      \
        "\nGT LF@bool LF@%2 LF@length"                  \
        "\nJUMPIFEQ $fatal_end$ LF@bool bool@true"      \
        "\nLT LF@bool LF@%2 int@0"                      \
        "\nJUMPIFEQ $fatal_end$ LF@bool bool@true"      \
        "\nLT LF@bool LF@%3 int@0"                      \
        "\nJUMPIFEQ $fatal_end$ LF@bool bool@true"      \
        "\nSUB LF@length LF@length LF@index"            \
        "\nGT LF@bool LF@%3 LF@length"                  \
        "\nSTRLEN LF@length LF@%1"                      \
        "\nJUMPIFEQ $big_n$ LF@bool bool@true"          \
        "\nJUMP $its_ok$"                               \
        "\nLABEL $big_n$"                               \
        "\nLT LF@bool LF@index LF@length"               \
        "\nJUMPIFEQ $the_end$ LF@bool bool@false"       \
        "\nGETCHAR LF@help LF@%1 LF@index"              \
        "\nADD LF@index LF@index int@1"                 \
        "\nCONCAT LF@string LF@string LF@help"          \
        "\nJUMP $big_n$"                                \
        "\nLABEL $its_ok$"                              \
        "\nLABEL $its_ok_loop$"                         \
        "\nEQ LF@bool LF@%3 int@0"                      \
        "\nJUMPIFEQ $end_loop$ LF@bool bool@true"       \
        "\nGT LF@bool LF@length LF@index"               \
        "\nJUMPIFEQ $the_end$ LF@bool bool@false"       \
        "\nGETCHAR LF@help LF@%1 LF@index"              \
        "\nCONCAT LF@string LF@string LF@help"          \
        "\nADD LF@index LF@index int@1"                 \
        "\nSUB LF@%3 LF@%3 int@1"                       \
        "\nJUMP $its_ok_loop$"                          \
        "\nLABEL $end_loop$"                            \
        "\nLABEL $the_end$"                             \
        "\nMOVE LF@&return LF@string"                   \
        "\nJUMP $no_fatal_end$"                         \
        "\nLABEL $fatal_end$"                           \
        "\nMOVE LF@&return nil@nil"                     \
        "\nLABEL $no_fatal_end$"                        \
        "\nPOPFRAME"                                    \
        "\nRETURN\n"

#define built_in_function_ord \
        "\nLABEL &ord"                                  \
        "\nPUSHFRAME"                                   \
        "\nDEFVAR LF@&return"                           \
        "\nDEFVAR LF@bool"                              \
        "\nDEFVAR LF@length"                            \
        "\nMOVE LF@&return nil@nil"                     \
        "\nSTRLEN LF@length LF@%1"                      \
        "\nLT LF@bool LF@%2 int@0"                      \
        "\nJUMPIFEQ $ord_end$ LF@bool bool@true"        \
        "\nLT LF@bool LF@%2 LF@length"                  \
        "\nJUMPIFEQ $ord_end$ LF@bool bool@false"       \
        "\nSTRI2INT LF@&return LF@%1 LF@%2"             \
        "\nLABEL $ord_end$"                             \
        "\nPOPFRAME"                                    \
        "\nRETURN\n"

#define built_in_function_chr \
        "\nLABEL &chr"                                  \
        "\nPUSHFRAME"                                   \
        "\nDEFVAR LF@&return"                           \
        "\nDEFVAR LF@badsize"                           \
        "\nLT LF@badsize LF@%1 int@0"                   \
        "\nJUMPIFEQ $nomatch LF@badsize bool@true"      \
        "\nGT LF@badsize LF@%1 int@255"                 \
        "\nJUMPIFEQ $nomatch LF@badsize bool@true"      \
        "\nINT2CHAR LF@&return LF@%1"                   \
        "\nJUMP $match"                                 \
        "\nLABEL $nomatch"                              \
        "\nEXIT int@4"                                  \
        "\nLABEL $match"                                \
        "\nPOPFRAME"                                    \
        "\nRETURN\n"

Dynamic_string main_string;
Dynamic_string function;


void convert_string2codeString(char *input, Dynamic_string *outputString) {

    for(int i = 0; input[i] != '\0'; i++){
        if (input[i] == '#'){
            string_add_Cstr(outputString, "\\035");
        }
        else {

            if (input[i] == ' ') {
                string_add_Cstr(outputString, "\\032");
            } else {
                if (input[i] == '\\') {
                    switch (input[i + 1]) {
                        case 'n':
                            string_add_Cstr(outputString, "\\010");
                            i++;
                            break;
                        case 't':
                            string_add_Cstr(outputString, "\\009");
                            i++;
                            break;
                        default:
                            string_add_Cstr(outputString, "\\092");
                            break;
                    }
                } else{
                    string_add_char(outputString, input[i]);
                }
            }
        }
    }
}

void generate_start()
{
    string_init(&function);
    string_init(&main_string);

    string_add_Cstr(&function, ".IFJcode19\n");
    string_add_Cstr(&function, "DEFVAR GF@&exp_result\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand1\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand3\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand1_type\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand3_type\n");
    string_add_Cstr(&function, "JUMP &main&\n");

    string_add_Cstr(&function, built_in_function_len);
    string_add_Cstr(&function, built_in_function_substr);
    string_add_Cstr(&function, built_in_function_ord);
    string_add_Cstr(&function, built_in_function_chr);

    string_add_Cstr(&main_string, "LABEL &main&\n");
    string_add_Cstr(&main_string, "CREATEFRAME\n");
    string_add_Cstr(&main_string, "PUSHFRAME\n");

}

void generate_print_code() {
    printf("%s\n%s\n", string_get_string(&function), string_get_string(&main_string));
}

void generate_function_start(char* actual_func)
{
    string_add_Cstr(&function, "\nLABEL &");
    string_add_Cstr(&function, actual_func);
    string_add_Cstr(&function, "\n");
    string_add_Cstr(&function, "PUSHFRAME\n");
    string_add_Cstr(&function, "DEFVAR LF@&return\n");
    string_add_Cstr(&function, "MOVE LF@&return nil@nil\n");
    string_add_Cstr(&function, "MOVE GF@&exp_result nil@nil\n");

}

void generate_function_end()
{
    string_add_Cstr(&function, "POPFRAME\n");
    string_add_Cstr(&function, "RETURN\n");

}

void generate_new_param(char* param, char* index)
{
    string_add_Cstr(&function, "DEFVAR LF@");
    string_add_Cstr(&function, param);
    string_add_char(&function, '\n');
    string_add_Cstr(&function, "MOVE LF@");
    string_add_Cstr(&function, param);
    string_add_Cstr(&function, " LF@%");
    string_add_Cstr(&function, index);
    string_add_char(&function, '\n');

}


void generate_createFrame(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "CREATEFRAME\n");
    }
    else
    {
        string_add_Cstr(&main_string, "CREATEFRAME\n");
    }

}

void generate_new_argument_id(Parse_data* parser_data,char* arg_name, char *index)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "DEFVAR TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "MOVE TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, ' ');
        string_add_Cstr(&function, "LF@");
        string_add_Cstr(&function, arg_name);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main_string, "DEFVAR TF@%");
        string_add_Cstr(&main_string, index);
        string_add_char(&main_string, '\n');
        string_add_Cstr(&main_string, "MOVE TF@%");
        string_add_Cstr(&main_string, index);
        string_add_char(&main_string, ' ');
        string_add_Cstr(&main_string, "LF@");
        string_add_Cstr(&main_string, arg_name);
        string_add_char(&main_string, '\n');
    }
}

void generate_new_argument_value(Parse_data* parser_data,char* value, char* type, char *index)
{
    if(parser_data->function) {
        string_add_Cstr(&function, "DEFVAR TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "MOVE TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, ' ');
        string_add_Cstr(&function, type);
        string_add_Cstr(&function, "@");
        string_add_Cstr(&function, value);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main_string, "DEFVAR TF@%");
        string_add_Cstr(&main_string, index);
        string_add_char(&main_string, '\n');
        string_add_Cstr(&main_string, "MOVE TF@%");
        string_add_Cstr(&main_string, index);
        string_add_char(&main_string, ' ');
        string_add_Cstr(&main_string, type);
        string_add_Cstr(&main_string, "@");
        string_add_Cstr(&main_string, value);
        string_add_char(&main_string, '\n');
    }
}

void generate_function_call(Parse_data* parser_data,char* function_name)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "CALL &");
        string_add_Cstr(&function, function_name);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main_string, "CALL &");
        string_add_Cstr(&main_string, function_name);
        string_add_char(&main_string, '\n');
    }
}

void generate_MOVE_retval_to_Lvalue(Parse_data* parser_data,char *l_value_fnc)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "MOVE LF@");
        string_add_Cstr(&function, l_value_fnc);
        string_add_Cstr(&function, " TF@&return\n");
    }
    else
    {
        string_add_Cstr(&main_string, "MOVE LF@");
        string_add_Cstr(&main_string, l_value_fnc);
        string_add_Cstr(&main_string, " TF@&return\n");
    }
}

void generate_while_head(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "# ************************ WHILE <> DO ************************* #\n");
        string_add_Cstr(&function, "LABEL $loop%start%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main_string, "# ************************ WHILE <> DO ************************* #\n");
        string_add_Cstr(&main_string, "LABEL $loop%start%");
        string_add_Cstr(&main_string, labelID);
        string_add_char(&main_string, '\n');
    }
}

void generate_conditional_jump(Parse_data* parser_data, char *labelID)
{
    if(parser_data->function){
        if(parser_data->while_stat) {
            string_add_Cstr(&function, "JUMPIFEQ $loop%end%");
            string_add_Cstr(&function, labelID);
            string_add_Cstr(&function, " GF@%exp_result bool@false\n");
        }
        else {
            string_add_Cstr(&function, "JUMPIFEQ $%else%");
            string_add_Cstr(&function, labelID);
            string_add_Cstr(&function, " GF@&exp_result bool@false\n");
        }
    }
    else {
        if(parser_data->while_stat) {
            string_add_Cstr(&main_string, "JUMPIFEQ $loop%end%");
            string_add_Cstr(&main_string, labelID);
            string_add_Cstr(&main_string, " GF@&exp_result bool@false\n");
        }
        else {
            string_add_Cstr(&main_string, "JUMPIFEQ $%else%");
            string_add_Cstr(&main_string, labelID);
            string_add_Cstr(&main_string, " GF@&exp_result bool@false\n");
        }
    }
}

void generate_while_end(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function) {
        string_add_Cstr(&function, "JUMP $loop%start%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "# ************************* END WHILE ************************** #\n");
        string_add_Cstr(&function, "LABEL $loop%end%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else {
        string_add_Cstr(&main_string, "JUMP $loop%start%");
        string_add_Cstr(&main_string, labelID);
        string_add_char(&main_string, '\n');
        string_add_Cstr(&main_string, "# ************************* END WHILE ************************** #\n");
        string_add_Cstr(&main_string, "LABEL $loop%end%");
        string_add_Cstr(&main_string, labelID);
        string_add_char(&main_string, '\n');
    }
}

void generate_if_head(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "# ************************* IF <> THEN ************************* #\n");

    }
    else
    {
        string_add_Cstr(&main_string, "# ************************* IF <> THEN ************************* #\n");

    }
}

void generate_else(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "JUMP $if%end%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "# **************************** ELSE **************************** #\n");
        string_add_Cstr(&function, "LABEL $%else%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main_string, "JUMP $if%end%");
        string_add_Cstr(&main_string, labelID);
        string_add_char(&main_string, '\n');
        string_add_Cstr(&main_string, "# **************************** ELSE **************************** #\n");
        string_add_Cstr(&main_string, "LABEL $%else%");
        string_add_Cstr(&main_string, labelID);
        string_add_char(&main_string, '\n');
    }
}

void generate_if_end(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "# *************************** END IF *************************** #\n");
        string_add_Cstr(&function, "LABEL $if%end%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main_string, "# *************************** END IF *************************** #\n");
        string_add_Cstr(&main_string, "LABEL $if%end%");
        string_add_Cstr(&main_string, labelID);
        string_add_char(&main_string, '\n');
    }
}

void generate_PUSHS_id(Parse_data* parser_data,char* identifier)
{

    if(parser_data->function)
    {
        string_add_Cstr(&function, "PUSHS LF@");
        string_add_Cstr(&function, identifier);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main_string, "PUSHS LF@");
        string_add_Cstr(&main_string, identifier);
        string_add_char(&main_string, '\n');
    }
}

void generate_PUSHS_value(Parse_data* parser_data,char* type, char* value)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "PUSHS ");
        string_add_Cstr(&function, type);
        string_add_Cstr(&function, "@");
        string_add_Cstr(&function, value);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main_string, "PUSHS ");
        string_add_Cstr(&main_string, type);
        string_add_Cstr(&main_string, "@");
        string_add_Cstr(&main_string, value);
        string_add_char(&main_string, '\n');
    }
}

void generate_stack_OPERATION(Parse_data* parser_data,int operator) {
    switch(operator) {
        case I_PLUS:
            (parser_data->function)
            ? string_add_Cstr(&function, "ADDS\n")
            : string_add_Cstr(&main_string, "ADDS\n");
            break;
        case I_MINUS:
            (parser_data->function)
            ? string_add_Cstr(&function, "SUBS\n")
            : string_add_Cstr(&main_string, "SUBS\n");
            break;
        case I_MULTIPLY:
            (parser_data->function)
            ? string_add_Cstr(&function, "MULS\n")
            : string_add_Cstr(&main_string, "MULS\n");
            break;
        case I_DIVIDE:
            (parser_data->function)
            ? string_add_Cstr(&function, "DIVS\n")
            : string_add_Cstr(&main_string, "DIVS\n");
            break;
        case I_DIVIDE_FULL:
            (parser_data->function)
            ? string_add_Cstr(&function, "IDIVS\n")
            : string_add_Cstr(&main_string, "IDIVS\n");
            break;
        case I_LOWER:
            (parser_data->function)
            ? string_add_Cstr(&function, "LTS\n")
            : string_add_Cstr(&main_string, "LTS\n");
            break;
        case I_LOWER_EQUAL:
            if(parser_data->function) {
                string_add_Cstr(&function, "GTS\n");
                string_add_Cstr(&function, "NOTS\n");
            }
            else {
                string_add_Cstr(&main_string, "GTS\n");
                string_add_Cstr(&main_string, "NOTS\n");
            }
            break;
        case I_GREATER:
            (parser_data->function)
            ? string_add_Cstr(&function, "GTS\n")
            : string_add_Cstr(&main_string, "GTS\n");
            break;
        case I_GREATER_EQUAL:
            if(parser_data->function) {
                string_add_Cstr(&function, "LTS\n");
                string_add_Cstr(&function, "NOTS\n");
            }
            else {
                string_add_Cstr(&main_string, "LTS\n");
                string_add_Cstr(&main_string, "NOTS\n");
            }
            break;
        case I_EQUAL:
            (parser_data->function)
            ? string_add_Cstr(&function, "EQS\n")
            : string_add_Cstr(&main_string, "EQS\n");
            break;
        case I_NOT_EQUAL:
            if(parser_data->function) {
                string_add_Cstr(&function, "EQS\n");
                string_add_Cstr(&function, "NOTS\n");
            }
            else {
                string_add_Cstr(&main_string, "EQS\n");
                string_add_Cstr(&main_string, "NOTS\n");
            }
            break;
    }
}

void generate_POPS_toEXPresult(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "POPS GF@&exp_result\n");
    }
    else
    {
        string_add_Cstr(&main_string, "POPS GF@&exp_result\n");
    }
}

void generate_MOVE_exp_to_Lvalue(Parse_data* parser_data,char* lvalue_id)
{
    if (parser_data->function) {
        string_add_Cstr(&function, "MOVE LF@");
        string_add_Cstr(&function, lvalue_id);
        string_add_Cstr(&function, " GF@&exp_result\n");
    } else {
        string_add_Cstr(&main_string, "MOVE LF@");
        string_add_Cstr(&main_string, lvalue_id);
        string_add_Cstr(&main_string, " GF@&exp_result\n");
    }
}

void generate_update_return(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "MOVE LF@$return GF@&exp_result\n");
    }
    else
    {
        string_add_Cstr(&main_string, "MOVE LF@$return GF@&exp_result\n");
    }
}

void generate_READ(Parse_data* parser_data,char* value_id, char* value_type) {
    if (parser_data->function)
    {
        string_add_Cstr(&function, "READ LF@");
        string_add_Cstr(&function, value_id);
        string_add_char(&function, ' ');
        string_add_Cstr(&function, value_type);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main_string, "READ GF@");
        string_add_Cstr(&main_string, value_id);
        string_add_char(&main_string, ' ');
        string_add_Cstr(&main_string, value_type);
        string_add_char(&main_string, '\n');
    }
}

void generate_WRITE_id(Parse_data* parser_data,char *identifier)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "WRITE LF@");
        string_add_Cstr(&function, identifier);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main_string, "WRITE LF@");
        string_add_Cstr(&main_string, identifier);
        string_add_char(&main_string, '\n');
    }
}

void generate_WRITE(Parse_data* parser_data,char *string)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "WRITE string@");
        string_add_Cstr(&function, string);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main_string, "WRITE string@");
        string_add_Cstr(&main_string, string);
        string_add_char(&main_string, '\n');
    }
}


void generate_DEFVAR(Parse_data* parser_data,char *identifier) {
    if (parser_data->function) {
        string_add_Cstr(&function, "DEFVAR LF@");
        string_add_Cstr(&function, identifier);
        string_add_char(&function,'\n');
    }
    else {
        string_add_Cstr(&main_string, "DEFVAR LF@");
        string_add_Cstr(&main_string, identifier);
        string_add_char(&main_string,'\n');
    }
}