#!/usr/bin/python 3
# -*- coding: utf-8 -*-
"""
Created on Mon March  20 21:58:01 2019

@author: Daniel Stepanek xstepa61
"""

import sys
import re
import xml.etree.ElementTree


def ParseXML():

    def __init__(self):
        pass

def Instruction(object):

    def __init__(self):
        pass

def Run():

    def __init__(self):
        pass

def CheckInput():

    def __init__(self):
        pass

def CheckSource():

    def __init__(self):
        pass

#Parameter --help
def PrintHelp():
    print("Help")


if __name__ == "__main__":

    #Input Parameters
    isSource = False
    isInput = False

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--help"):
            PrintHelp()
            exit(0)

        source_list = re.search(r'(?<=--source=)(.+)', sys.argv[1])
        if(source_list):
            source = source_list.group(1)
            isSource = True
        input_list = re.search(r'(?<=--input=)(.+)', sys.argv[1])
        if(input_list):
            input = input_list.group(1)
            isInput = True

        if((isSource == False) & (isInput == False)):
            sys.stderr.write("Wrong input parameters\n")
            exit(10)

    elif(len(sys.argv) == 3):
        for item in sys.argv:
            source_list = re.search(r'(?<=--source=)(.+)', item)
            if(source_list):
                source = source_list.group(1)
                isSource = True

            input_list = re.search(r'(?<=--input=)(.+)', item)
            if(input_list):
                input = input_list.group(1)
                isInput = True

        if((isSource == False) | (isInput == False)):
            sys.stderr.write("Wrong input parameters\n")
            exit(10)
    else:
        sys.stderr.write("Wrong input parameters\n")
        exit(10)
