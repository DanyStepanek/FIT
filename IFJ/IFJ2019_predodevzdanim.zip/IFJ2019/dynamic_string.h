/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Juraj Lazorik (xlazor02)                             *
 *	Date: 11.12.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#ifndef IFJ_DYNAMIC_STRING_H
#define IFJ_DYNAMIC_STRING_H

#define STRING_LENGTH_INC 1000

typedef struct {
    char *str;          // pointer to the string
    unsigned length;	// real length of string
    unsigned allocSize;	// size of allocated memory
} Dynamic_string;


/*
 * Inicializace dynamickeho stringu
 */
int string_init(Dynamic_string *s);

/*
 * Uvolneni dynamickeho stringu
 */
void string_free(Dynamic_string *s);

/*
 * Vlozeni inicializacnich hodnot do prvku dynamickeho stringu.
 */
void string_clear(Dynamic_string *s);

/*
 * Vlozeni jednoho znaku do stringu.
 */
int string_add_char(Dynamic_string *s1, char c);

/*
 * Vlozeni stringu s2 do stringu s1.
 */
int string_add_Cstr(Dynamic_string *s1, char *s2);

/*
 * Zkopiruje hodnotu s2 do s1.
 */
int string_copy_Cstr(Dynamic_string *s1, char *s2);

/*
 * Vrati hodnotu dynamickeho stringu.
 */
char *string_get_string(Dynamic_string *s);


#endif //IFJ_DYNAMIC_STRING_H
