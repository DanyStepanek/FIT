var searchData=
[
  ['normalize_5fvec2',['normalize_Vec2',['../linearAlgebra_8c.html#aef887725c2f4d11256731400b232a1bf',1,'normalize_Vec2(Vec2 *const output, Vec2 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#aef887725c2f4d11256731400b232a1bf',1,'normalize_Vec2(Vec2 *const output, Vec2 const *const input):&#160;linearAlgebra.c']]],
  ['normalize_5fvec3',['normalize_Vec3',['../linearAlgebra_8c.html#a29413d309c1692fac4d63a4fc080903c',1,'normalize_Vec3(Vec3 *const output, Vec3 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a29413d309c1692fac4d63a4fc080903c',1,'normalize_Vec3(Vec3 *const output, Vec3 const *const input):&#160;linearAlgebra.c']]],
  ['normalize_5fvec4',['normalize_Vec4',['../linearAlgebra_8c.html#a8333ef95a3ea4503121bd0f8ec2e5a93',1,'normalize_Vec4(Vec4 *const output, Vec4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a8333ef95a3ea4503121bd0f8ec2e5a93',1,'normalize_Vec4(Vec4 *const output, Vec4 const *const input):&#160;linearAlgebra.c']]]
];
