/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 2.10.2019                                                 *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#include<stdio.h>
#include<stdlib.h>

#include "scanner.h"
#include "parser.h"

int main() {

    //freopen("assign.txt", "r", stdin);
    FILE * f = stdin;
  
    int err_code = 0;
    LexStack = createLexStack();

    if((err_code = parse(f)) != 0){
    //  fprintf(stderr, "Parse Error: ERROR CODE= %d\n", err_code);
      return err_code;
    };


    return 0;


}
