
#include "stack.h"
int stackfull(Tstack* s)
{
	return s->top == s->size;
}
int stackempty(Tstack* s)
{
	return s->top == EMPTY;
}
void stackdispose(Tstack* s)
{
	free(s->ptr);
}
void stackpop(Tstack* s)
{
	s->top = s->top > EMPTY ? s->top - 1 : EMPTY;
}
int stackinitsucc(Tstack* s)
{
	return s->ptr != NULL;
}
