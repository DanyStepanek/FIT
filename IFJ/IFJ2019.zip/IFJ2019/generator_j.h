//
// Created by juraj on 02.12.19.
//

#ifndef IFJ_GENERATOR_J_H
#define IFJ_GENERATOR_J_H

#include "expression.h"
#include "dynamic_string.h"

void generate_function_header();
void generate_main_header();
void generate_built_in_functions();
void generate_start();
void generate_function_start(char* actual_func);
void generate_function_end();
void generate_new_param(char* param, char* index);
void generate_createFrame(Parse_data* parser_data);
void generate_new_argument_id(Parse_data* parser_data,char* arg_name, char *index);
void generate_new_argument_value(Parse_data* parser_data,char* value, char* type, char *index);
void generate_function_call(Parse_data* parser_data,char* function_name);
void generate_MOVE_retval_to_Lvalue(Parse_data* parser_data,char *l_value_fnc);
void generate_while_head(Parse_data* parser_data,char *labelID);
void generate_conditional_jump(Parse_data* parser_data, char *labelID);
void generate_while_end(Parse_data* parser_data,char *labelID);
void generate_if_head(Parse_data* parser_data);
void generate_else(Parse_data* parser_data,char *labelID);
void generate_if_end(Parse_data* parser_data,char *labelID);
void generate_NIL_value(Parse_data* parser_data,char *identifier);
void generate_PUSHS_id(Parse_data* parser_data,char* identifier);
void generate_PUSHS_value(Parse_data* parser_data,char* type, char* value);
void generate_INT2FLOAT(Parse_data* parser_data,bool operand1);
void generate_POPS_toEXPresult(Parse_data* parser_data);
void generate_MOVE_exp_to_Lvalue(Parse_data* parser_data,char* lvalue_id);
void generate_update_return(Parse_data* parser_data);
void generate_READ(Parse_data* parser_data,char* value_id, char* value_type);
void generate_WRITE_id(Parse_data* parser_data,char *identifier);
void generate_WRITE(Parse_data* parser_data,char *string);
void generate_DIV_by_0(Parse_data* parser_data);
void generate_DIV_by_0f(Parse_data* parser_data);
void generate_truly_false(Parse_data* parser_data);



#endif //IFJ_GENERATOR_J_H
