/*******************************************************************
 *	IFJ projekt: Implementace prekladace                   	       *
 *				  imperativniho jazyka IFJ19.	                           *
 *	Author(s): Daniel Stepanek (xstepa61)                          *
 *	Date: 11.11.2019                                               *
 *	VUT FIT Brno                                                   *
 *                                                                 *
 *******************************************************************/

#ifndef IFJ_OTHER_FUNCTIONS_H
#define IFJ_OTHER_FUNCTIONS_H
#include<stdio.h>
#include<stdlib.h>

  int check_malloc(void* pointer);


#endif
