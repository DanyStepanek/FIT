var searchData=
[
  ['globals_2ec',['globals.c',['../globals_8c.html',1,'']]],
  ['globals_2eh',['globals.h',['../globals_8h.html',1,'']]],
  ['gpu_2ec',['gpu.c',['../gpu_8c.html',1,'']]],
  ['gpu_2eh',['gpu.h',['../gpu_8h.html',1,'']]]
];
