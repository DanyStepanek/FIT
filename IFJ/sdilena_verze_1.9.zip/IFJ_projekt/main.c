/******************************************************************** 
 *  About: Main function          									*
 *		   															*
 *		    	 													*
 *																	*
 ********************************************************************
 *	IFJ projekt: "Implementace prekladace                       	*
 *				  imperativniho jazyka IFJ18."      				*
 *	Author(s): Daniel Stepanek (xstepa61)                       	*
 *	Date: 10.11.2018                                            	*
 *	VUT FIT Brno 2BIT                                           	*
 *                                                                  *
 *******************************************************************/
#include<stdio.h>
#include<stdlib.h>

#include "scanner.h"
#include "parser.h"
#include "err_code.h"
#include "generator.h"



int main(int argc,char *argv[]){
	int check = 0;
	
	//inicializace struktury pro ukladani nactenych tokenu
	Tlist *t = init_Tlist();

	
	buffer = (char *) malloc(sizeof(char)*100);
	if(buffer == NULL){
		fprintf(stderr,"Buffer allocation failed\n");
		exit(1);
	}
	if(argc == 1){
		check = syntax();
		
		if(check != 0){
			fprintf(stderr,"\n***\tTarget is incorrect\t***\n***\tError [%d]: Compilation failed.\t***\n",  check);
			
		}
		else { 
			printf("\n***\tTarget is correct.\t***\n***\tCompilation succeeded.\t***\n");
		}
	}
	
	//dealokace veskere alokovane pameti pouzite v Tlist
	free_Tlist(t);

	// dealokace pro scanner a parser
	free(buffer);
	
	
return 0;
}
