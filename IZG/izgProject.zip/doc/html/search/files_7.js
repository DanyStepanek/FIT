var searchData=
[
  ['stack_2ec',['stack.c',['../stack_8c.html',1,'']]],
  ['stack_2eh',['stack.h',['../stack_8h.html',1,'']]]
];
