//hlavickovy soubor interpret.c


#ifndef INTERPRET_H_INCLUDED
#define INTERPRET_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

#include "err_code.h"
#include "parser.h"

void gen_string(Token * );
void gen_id(Token* );
void gen_expr(Token* );
void gen_func(Token* );
void gen_keyword(Token* );





#endif