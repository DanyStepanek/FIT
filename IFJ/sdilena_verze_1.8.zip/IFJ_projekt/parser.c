#include "parser.h"


int syntax(){
	int control = 0;
	int check = 0;	
	Token* token;
	
	printf(".IFJcode18\n");
	for(int i = 0;i<100;i++)
		token = get_token();
	
//	if(token->id != 0)
//		gen_print(token);
	
//	free_Token(token);
/*	while(1){
		
		token = get_token();
	
		if(control == 0){	//if get_token return valid token
			switch(token->id){
				case 0:
					
					break;
			
				case 1:
			
					break;
				
				case 2:
					gen_print(token);
					break;
			
				case 3:
					if(strcmp(token->value->string, "print")){ 
						free_Token(token);
					//	get_token(file);
					}
					else
						gen_id(token);
					break;
				
				case 4:
					
					break;
					
				case 5:
					
					break;
				
				case 6:
					
					break;
					
				case 7:
					
					
					break;
				
				case 8:
				
					break;
				
				case 9:
					
					break;
				default:
					break;
			
			}
				free_Token(token);
		}
		else if(control == 1){	//EOF
			break;
		}
		else
			check = control;

		
	}
		
	//Something get wrong
	if(check != 0)
		return check;
*/
	return 0;
}