

/*
	IFJ Projekt 2018
	autor: David Triska
	login: xtrisk05
*/

#include "Tlist.h"

/*
	DOPSAT

	Vezme soubor ze ktereho nacte, rozdeli VSECHNY tokeny, ulozi do Tlist, vraci pocet nactenych tokenu
	@param Tlist* list - ukazatel na INICIALIZOVANY Tlist * strukturu, pro ulozeni Tokenu
	@paran FILE* inputFile - vstupni soubor pro prelozeni 
	@return >= 0 pocet nactenych tokenu
			<  0 CHYBA
			 
*/
int scanner_ALL(Tlist* list, FILE* inputFile);

/*

	Asi by chtelo napsat i funkci ktera by nacitala pouze cast zdrojaku,
	po nejakych blocich, napr do konce radku, nebo v pripade definovani
	funkce celou jeji definici, tedy od "def" do "end", nebo i u cyklu, atd..
*/
