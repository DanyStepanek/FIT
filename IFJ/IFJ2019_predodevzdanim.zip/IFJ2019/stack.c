/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Juraj Lazorik (xlazor02)                             *
 *	Date: 11.12.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#include "stack.h"
int stackfull(Tstack* s)
{
	return s->top == s->size;
}
int stackempty(Tstack* s)
{
	return s->top == EMPTY;
}
void stackdispose(Tstack* s)
{
	free(s->ptr);
}
void stackpop(Tstack* s)
{
	s->top = s->top > EMPTY ? s->top - 1 : EMPTY;
}
int stackinitsucc(Tstack* s)
{
	return s->ptr != NULL;
}

void parser_stack_init(PStack* s){
	s->top = EMPTY;
	s->size = DATA_INIT_SIZE;

	return;
}

void parser_stack_resize(PStack* s){
	int* temp;
	temp = realloc(s->levels, (sizeof(int) * (s->size + DATA_RESIZE_CHUNK)));

	*s->levels = *temp;
	s->size = s->size + DATA_RESIZE_CHUNK;
}

int parser_stack_push(PStack* s, int level){
	if(s->top == s->size){
		parser_stack_resize(s);
	}

	s->levels[++s->top] = level;
	return 0;
}

int parser_stack_top(PStack* s){
	if(s->top == 0){
		return -1;
	}

	return s->levels[s->top];
}

int parser_stack_pop(PStack* s){
	if(s->top == 0){
		return -1;
	}

	return s->levels[s->top--];
}
