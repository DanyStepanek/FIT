//hlavickovy soubor stacku (zasobniku)

/*                @Project: IFJ
-----------------------------------------------------
  @Author: Ondrej Bravenec xbrave03@stud.fit.vutbr.cz
-----------------------------------------------------
*/

#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>


/*
 *Deklarace
 */

typedef struct tSElement //element
{
	struct tSElement *ptr_next; //ukazatel na dalsi prvek
	int data;
} *tElement;


typedef struct //zasobnik
{
	tElement First; //ukazatel na prvni prvek
} tStack;

/*
 *Funkce
 */

 void stack_init(tStack *);
 void stack_Push(tStack *, int);
 void stack_pop(tStack *, int);
 void stack_free(tStack *);
 int stack_empty(tStack *);
