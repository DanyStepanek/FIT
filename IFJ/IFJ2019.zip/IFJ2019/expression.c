#include "expression.h"

TablePriority_t PrecTable[ARRAY_SIZE][ARRAY_SIZE] = {
	{H,L,L,H,L,H,H},
	{H,H,L,H,L,H,H},
	{L,L,L,E,L,L,N},
	{H,H,N,H,N,H,H},
	{H,H,N,H,N,H,H},
	{L,L,L,H,L,N,H},
	{L,L,L,N,L,L,N},
};


int process_expression(struct Token* token, Parse_data* parser_data, FILE* file,STable* global_frame,STable* local_frame,STable* tmp_frame)
{

	struct Token* var2 = malloc(sizeof(struct Token));
	struct Token* operand = malloc(sizeof(struct Token));
	struct Token* var4 = malloc(sizeof(struct Token));

	struct Token* tmp = malloc(sizeof(struct Token));
	struct Token* dollar = malloc(sizeof(struct Token));
	struct Token* reduce_symbol = malloc(sizeof(struct Token));
    struct Token* replace_generate_token = malloc(sizeof(struct Token));

    initToken(var2);
    initToken(operand);
    initToken(var4);
    initToken(tmp);
    initToken(dollar);
    initToken(reduce_symbol);
    initToken(replace_generate_token);

	Tstack* basic_stack = malloc(sizeof(struct Token));
	Tstack* input_stack = malloc(sizeof(struct Token));
	Tstack* tmp_stack = malloc(sizeof(struct Token));

	stackinit(basic_stack, struct Token);
	stackinit(input_stack, struct Token);
	stackinit(tmp_stack, struct Token);

	char* Instruction = malloc(sizeof(char)*10);

	dollar->type = T_OPERATOR;
	dollar->lentgh = 1;
	dollar->size = 1;
	dollar->val = "$";
	dollar->Terminal_state = S_TERM;

	reduce_symbol->type = T_OPERATOR;
	reduce_symbol->lentgh = 1;
	reduce_symbol->size = 1;
	reduce_symbol->val = "#";
    reduce_symbol->Terminal_state = S_NON_TERM;

    replace_generate_token->type = T_ID; //nahradit pri generovani
    replace_generate_token->lentgh = 1;
    replace_generate_token->size = 1;
    replace_generate_token->val = "x";
    replace_generate_token->Terminal_state = S_NON_TERM;

	if (parser_data->assign_stat == true)
	{
        CheckSize(basic_stack, struct Token);
		stackpush(basic_stack, struct Token, *dollar);

		while (*(token->val) != '\n' && *(token->val) != EOF)
		{
            CheckSize(tmp_stack, struct Token);
			stackpush(tmp_stack, struct Token, *token);
			getToken(file, token);
		}

        CheckSize(tmp_stack, struct Token);
		stackpush(tmp_stack, struct Token, *dollar);

		while (stackempty(tmp_stack) != 1)
		{
            CheckSize(input_stack, struct Token);
			stackpush(input_stack, struct Token, stacktop(tmp_stack, struct Token));
			stackpop(tmp_stack);
		}
		//v basic stack je nas stack
		//v Input stack mame vstupujuce tokeny a na spodku $

		//a je zasobnik a b je vstup
		int i=0;
		while (token_val_to_Toperator_t(stack_terminal_top(basic_stack)) != O_DOLLAR || token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))) != O_DOLLAR)
		{
			Toperator_t a = token_val_to_Toperator_t(stack_terminal_top(basic_stack));
			Toperator_t b = token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))); //mam jeho hodnotu ale este
																				                         //ostal na zasobniku nezabudni POP!!!
			printf("Krok: %d\n",i);										                             //stackpop(input_stack) = getToken
			i++;
			switch (PrecTable[a][b])
			{
			case E :
				printf("symbol: =\n");

				CheckSize(basic_stack, struct Token);
				stackpush(basic_stack, struct Token, stacktop(input_stack, struct Token));
				stackpop(input_stack); //dalsi token
				break;
			case L : //shift
				printf("symbol: <\n");

				*tmp = stacktop(basic_stack, struct Token);

				while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) == O_NON_TERMINAL) //check it
				{
                    CheckSize(tmp_stack, struct Token);
					stackpush(tmp_stack, struct Token, *tmp);
					stackpop(basic_stack);
					*tmp = stacktop(basic_stack, struct Token);
				}

				CheckSize(basic_stack, struct Token);
				stackpush(basic_stack, struct Token, *reduce_symbol);

				while (!stackempty(tmp_stack))
				{
					*tmp = stacktop(tmp_stack, struct Token);
					stackpop(tmp_stack);
                    CheckSize(basic_stack, struct Token);
					stackpush(basic_stack, struct Token, *tmp);
				}

				CheckSize(basic_stack, struct Token);
				stackpush(basic_stack, struct Token, stacktop(input_stack, struct Token));
				stackpop(input_stack); //dalsi token

				break;
                case H : //reduce
                {
                    printf("symbol: >\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    //najdenie symbolu < reduce
                    while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) != O_TYPE_TO_REDUCE) //check it stackempty podmienku
                    {
                        *var2 = stacktop(basic_stack, struct Token);
                        stackpop(basic_stack);
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *var2);
                        *tmp = stacktop(basic_stack, struct Token);

                    }

                    if (token_val_to_Toperator_t(tmp) == O_TYPE_TO_REDUCE) //vyhodim reduce symbol a do var2 ulozim vrchol tmp a teda ID
                    {
                        stackpop(basic_stack);
                        *var2 = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                    }
                    else
                    {
                        return SYNTAX_ERROR;
                    }

                    //T->id
                    if (token_val_to_Toperator_t(var2) == O_ID)
                    {

                        var2->Terminal_state = S_NON_TERM;
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *var2);

                    }
                    else
                    {
                        //E->(E)
                        if  (token_val_to_Toperator_t(var2) == O_LEFTCOL)
                        {
                            if (stackempty(tmp_stack))
                            {
                                return SYNTAX_ERROR;
                            }

                            *operand = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (token_val_to_Toperator_t(operand) != O_NON_TERMINAL)
                            {
                                return SYNTAX_ERROR;
                            }

                            if (stackempty(tmp_stack))
                            {
                                return SYNTAX_ERROR;
                            }

                            *var4 = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_LEFTCOL && token_val_to_Toperator_t(var4) == O_RIGHTCOL && token_val_to_Toperator_t(operand) == O_NON_TERMINAL)
                            {
                                //generuj kood pre var2 operand var 4 a vrat result
                                //push result to basic stack
                                CheckSize(basic_stack, struct Token);
                                stackpush(basic_stack,struct Token,*replace_generate_token); //docasne riesenie
                            }
                            else
                            {
                                return SYNTAX_ERROR;
                            }
                        }
                        else {

                            //ak je na vrchole neterminal(spracovane ID)
                            if (token_val_to_Toperator_t(var2) == O_NON_TERMINAL) {

                                if (stackempty(tmp_stack)) {

                                    return SYNTAX_ERROR;
                                }

                                *operand = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                //T-> E+E -> E-E -> E*E -> E/E -> E//E -> E<>==E dorobit este zatvorky
                                if (token_val_to_Toperator_t(operand) != O_PLUS_MINUS &&
                                    token_val_to_Toperator_t(operand) != O_MULTIPLY_DIVIDE_DIVIDE_FULL &&
                                    token_val_to_Toperator_t(operand) != O_H_HE_L_LE_E_NE) {
                                    return SYNTAX_ERROR;
                                } else {
                                    printf("operand:%s\n", operand->val);

                                    switch (token_val_to_Instruction(operand)) {
                                        case I_PLUS:

                                            strcpy(Instruction, "+");
                                            break;
                                        case I_MINUS:
                                            strcpy(Instruction, "-");
                                            break;
                                        case I_MULTIPLY:
                                            strcpy(Instruction, "*");
                                            break;
                                        case I_DIVIDE:
                                            strcpy(Instruction, "/");
                                            break;
                                        case I_DIVIDE_FULL:
                                            strcpy(Instruction, "//");
                                            break;
                                        case I_GREATER:
                                            strcpy(Instruction, ">");
                                            break;
                                        case I_GREATER_EQUAL:
                                            strcpy(Instruction, ">=");
                                            break;
                                        case I_LOWER:
                                            strcpy(Instruction, "<");
                                            break;
                                        case I_LOWER_EQUAL:
                                            strcpy(Instruction, "<=");
                                            break;
                                        case I_EQUAL:
                                            strcpy(Instruction, "==");
                                            break;
                                        case I_NOT_EQUAL:
                                            strcpy(Instruction, "!=");
                                            break;
                                        default:
                                            return SYNTAX_ERROR;
                                            break;
                                    }
                                }
                                if (stackempty(tmp_stack)) {
                                    return SYNTAX_ERROR;
                                }

                                *var4 = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_NON_TERMINAL &&
                                    token_val_to_Toperator_t(var4) == O_NON_TERMINAL &&
                                    token_val_to_Instruction(operand) != -1) {
                                    //generuj kood pre var2 operand var 4 a vrat result
                                    //push result to basic stack
                                    CheckSize(basic_stack, struct Token);
                                    stackpush(basic_stack, struct Token, *replace_generate_token); //docasne riesenie
                                } else {
                                    return SYNTAX_ERROR;
                                }
                            }
                            else
                            {
                                return SYNTAX_ERROR;
                            }
                        }
                    }
                }
					break;

				case N:
					return SYNTAX_ERROR;
					break;
				default:
					return SYNTAX_ERROR;
					break;
			}
		}
	}

	if (parser_data->return_stat == true) {
        CheckSize(basic_stack, struct Token);
        stackpush(basic_stack, struct Token, *dollar);

        while (*(token->val) != '\n' && *(token->val) != EOF) {
            CheckSize(tmp_stack, struct Token);
            stackpush(tmp_stack, struct Token, *token);
            getToken(file, token);
        }

        CheckSize(tmp_stack, struct Token);
        stackpush(tmp_stack, struct Token, *dollar);

        while (stackempty(tmp_stack) != 1) {
            CheckSize(input_stack, struct Token);
            stackpush(input_stack, struct Token, stacktop(tmp_stack,
                    struct Token));
            stackpop(tmp_stack);
        }
        //v basic stack je nas stack
        //v Input stack mame vstupujuce tokeny a na spodku $

        //a je zasobnik a b je vstup
        int i = 0;
        while (token_val_to_Toperator_t(stack_terminal_top(basic_stack)) != O_DOLLAR ||
               token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))) != O_DOLLAR) {
            Toperator_t a = token_val_to_Toperator_t(stack_terminal_top(basic_stack));
            Toperator_t b = token_val_to_Toperator_t(
                    &(stacktop(input_stack, struct Token))); //mam jeho hodnotu ale este
            //ostal na zasobniku nezabudni POP!!!
            printf("Krok: %d\n",
                   i);                                                                     //stackpop(input_stack) = getToken
            i++;

            switch (PrecTable[a][b]) {
                case E :
                    printf("symbol: =\n");

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, stacktop(input_stack,
                            struct Token));
                    stackpop(input_stack); //dalsi token
                    break;
                case L : //shift
                    printf("symbol: <\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) == O_NON_TERMINAL) //check it
                    {
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *tmp);
                        stackpop(basic_stack);
                        *tmp = stacktop(basic_stack, struct Token);
                    }

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, *reduce_symbol);

                    while (!stackempty(tmp_stack)) {
                        *tmp = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *tmp);
                    }

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, stacktop(input_stack,
                            struct Token));
                    stackpop(input_stack); //dalsi token

                    break;
                case H : //reduce
                {
                    printf("symbol: >\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    //najdenie symbolu < reduce
                    while (!stackempty(basic_stack) &&
                           token_val_to_Toperator_t(tmp) != O_TYPE_TO_REDUCE) //check it stackempty podmienku
                    {
                        *var2 = stacktop(basic_stack, struct Token);
                        stackpop(basic_stack);
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *var2);
                        *tmp = stacktop(basic_stack, struct Token);

                    }

                    if (token_val_to_Toperator_t(tmp) ==
                        O_TYPE_TO_REDUCE) //vyhodim reduce symbol a do var2 ulozim vrchol tmp a teda ID
                    {
                        stackpop(basic_stack);
                        *var2 = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                    } else {
                        return SYNTAX_ERROR;
                    }

                    //T->id
                    if (token_val_to_Toperator_t(var2) == O_ID) {
                        var2->Terminal_state = S_NON_TERM;
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *var2);

                    } else {
                        //E->(E)
                        if (token_val_to_Toperator_t(var2) == O_LEFTCOL) {
                            if (stackempty(tmp_stack)) {
                                return SYNTAX_ERROR;
                            }

                            *operand = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (token_val_to_Toperator_t(operand) != O_NON_TERMINAL) {
                                return SYNTAX_ERROR;
                            }

                            if (stackempty(tmp_stack)) {
                                return SYNTAX_ERROR;
                            }

                            *var4 = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_LEFTCOL &&
                                token_val_to_Toperator_t(var4) == O_RIGHTCOL &&
                                token_val_to_Toperator_t(operand) == O_NON_TERMINAL) {
                                //generuj kood pre var2 operand var 4 a vrat result
                                //push result to basic stack
                                CheckSize(basic_stack, struct Token);
                                stackpush(basic_stack, struct Token, *replace_generate_token); //docasne riesenie
                            } else {
                                return SYNTAX_ERROR;
                            }
                        } else {

                            //ak je na vrchole neterminal(spracovane ID)
                            if (token_val_to_Toperator_t(var2) == O_NON_TERMINAL) {

                                if (stackempty(tmp_stack)) {

                                    return SYNTAX_ERROR;
                                }

                                *operand = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                //T-> E+E -> E-E -> E*E -> E/E -> E//E -> E<>==E dorobit este zatvorky
                                if (token_val_to_Toperator_t(operand) != O_PLUS_MINUS &&
                                    token_val_to_Toperator_t(operand) != O_MULTIPLY_DIVIDE_DIVIDE_FULL &&
                                    token_val_to_Toperator_t(operand) != O_H_HE_L_LE_E_NE) {
                                    return SYNTAX_ERROR;
                                } else {
                                    printf("operand:%s\n", operand->val);

                                    switch (token_val_to_Instruction(operand)) {
                                        case I_PLUS:

                                            strcpy(Instruction, "+");
                                            break;
                                        case I_MINUS:
                                            strcpy(Instruction, "-");
                                            break;
                                        case I_MULTIPLY:
                                            strcpy(Instruction, "*");
                                            break;
                                        case I_DIVIDE:
                                            strcpy(Instruction, "/");
                                            break;
                                        case I_DIVIDE_FULL:
                                            strcpy(Instruction, "//");
                                            break;
                                        case I_GREATER:
                                            strcpy(Instruction, ">");
                                            break;
                                        case I_GREATER_EQUAL:
                                            strcpy(Instruction, ">=");
                                            break;
                                        case I_LOWER:
                                            strcpy(Instruction, "<");
                                            break;
                                        case I_LOWER_EQUAL:
                                            strcpy(Instruction, "<=");
                                            break;
                                        case I_EQUAL:
                                            strcpy(Instruction, "==");
                                            break;
                                        case I_NOT_EQUAL:
                                            strcpy(Instruction, "!=");
                                            break;
                                        default:
                                            return SYNTAX_ERROR;
                                            break;
                                    }
                                }
                                if (stackempty(tmp_stack)) {
                                    return SYNTAX_ERROR;
                                }

                                *var4 = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_NON_TERMINAL &&
                                    token_val_to_Toperator_t(var4) == O_NON_TERMINAL &&
                                    token_val_to_Instruction(operand) != -1) {
                                    //generuj kood pre var2 operand var 4 a vrat result
                                    //push result to basic stack
                                    CheckSize(basic_stack, struct Token);
                                    stackpush(basic_stack, struct Token, *replace_generate_token); //docasne riesenie
                                } else {
                                    return SYNTAX_ERROR;
                                }
                            } else {
                                return SYNTAX_ERROR;
                            }
                        }
                    }
                }
                    break;

                case N:
                    return SYNTAX_ERROR;
                    break;
                default:
                    return SYNTAX_ERROR;
                    break;
            }
        }
    }

	//while (strcmp(token->val, ":") != 0)
	if (parser_data->if_stat == true)
	{
        CheckSize(basic_stack, struct Token);
        stackpush(basic_stack, struct Token, *dollar);

        while (strcmp(token->val, ":") != 0)
        {
            if(*(token->val) == '\n' || *(token->val) == EOF)
            {
                return SYNTAX_ERROR;
            }
            CheckSize(tmp_stack, struct Token);
            stackpush(tmp_stack, struct Token, *token);
            getToken(file, token);
        }

        CheckSize(tmp_stack, struct Token);
        stackpush(tmp_stack, struct Token, *dollar);

        while (stackempty(tmp_stack) != 1)
        {
            CheckSize(input_stack, struct Token);
            stackpush(input_stack, struct Token, stacktop(tmp_stack, struct Token));
            stackpop(tmp_stack);
        }
        //v basic stack je nas stack
        //v Input stack mame vstupujuce tokeny a na spodku $

        //a je zasobnik a b je vstup
        int i=0;
        while (token_val_to_Toperator_t(stack_terminal_top(basic_stack)) != O_DOLLAR || token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))) != O_DOLLAR)
        {
            Toperator_t a = token_val_to_Toperator_t(stack_terminal_top(basic_stack));
            Toperator_t b = token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))); //mam jeho hodnotu ale este
            //ostal na zasobniku nezabudni POP!!!
            printf("Krok: %d\n",i);										                             //stackpop(input_stack) = getToken
            i++;
						printf("a b %d %d\n", a,b);

            switch (PrecTable[a][b])
            {
                case E :
                    printf("symbol: =\n");

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, stacktop(input_stack, struct Token));
                    stackpop(input_stack); //dalsi token
                    break;
                case L : //shift
                    printf("symbol: <\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) == O_NON_TERMINAL) //check it
                    {
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *tmp);
                        stackpop(basic_stack);
                        *tmp = stacktop(basic_stack, struct Token);
                    }

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, *reduce_symbol);

                    while (!stackempty(tmp_stack))
                    {
                        *tmp = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *tmp);
                    }

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, stacktop(input_stack, struct Token));
                    stackpop(input_stack); //dalsi token

                    break;
                case H : //reduce
                {
                    printf("symbol: >\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    //najdenie symbolu < reduce
                    while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) != O_TYPE_TO_REDUCE) //check it stackempty podmienku
                    {
                        *var2 = stacktop(basic_stack, struct Token);
                        stackpop(basic_stack);
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *var2);
                        *tmp = stacktop(basic_stack, struct Token);

                    }

                    if (token_val_to_Toperator_t(tmp) == O_TYPE_TO_REDUCE) //vyhodim reduce symbol a do var2 ulozim vrchol tmp a teda ID
                    {
                        stackpop(basic_stack);
                        *var2 = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                    }
                    else
                    {
                        return SYNTAX_ERROR;
                    }

                    //T->id
                    if (token_val_to_Toperator_t(var2) == O_ID)
                    {
                        var2->Terminal_state = S_NON_TERM;
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *var2);

                    }
                    else
                    {
                        //E->(E)
                        if  (token_val_to_Toperator_t(var2) == O_LEFTCOL)
                        {
                            if (stackempty(tmp_stack))
                            {
                                return SYNTAX_ERROR;
                            }

                            *operand = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (token_val_to_Toperator_t(operand) != O_NON_TERMINAL)
                            {
                                return SYNTAX_ERROR;
                            }

                            if (stackempty(tmp_stack))
                            {
                                return SYNTAX_ERROR;
                            }

                            *var4 = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_LEFTCOL && token_val_to_Toperator_t(var4) == O_RIGHTCOL && token_val_to_Toperator_t(operand) == O_NON_TERMINAL)
                            {
                                //generuj kood pre var2 operand var 4 a vrat result
                                //push result to basic stack
                                CheckSize(basic_stack, struct Token);
                                stackpush(basic_stack,struct Token,*replace_generate_token); //docasne riesenie
                            }
                            else
                            {
                                return SYNTAX_ERROR;
                            }
                        }
                        else {

                            //ak je na vrchole neterminal(spracovane ID)
                            if (token_val_to_Toperator_t(var2) == O_NON_TERMINAL) {

                                if (stackempty(tmp_stack)) {

                                    return SYNTAX_ERROR;
                                }

                                *operand = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                //T-> E+E -> E-E -> E*E -> E/E -> E//E -> E<>==E dorobit este zatvorky
                                if (token_val_to_Toperator_t(operand) != O_PLUS_MINUS &&
                                    token_val_to_Toperator_t(operand) != O_MULTIPLY_DIVIDE_DIVIDE_FULL &&
                                    token_val_to_Toperator_t(operand) != O_H_HE_L_LE_E_NE) {
                                    return SYNTAX_ERROR;
                                } else {
                                    printf("operand:%s\n", operand->val);

                                    switch (token_val_to_Instruction(operand)) {
                                        case I_PLUS:

                                            strcpy(Instruction, "+");
                                            break;
                                        case I_MINUS:
                                            strcpy(Instruction, "-");
                                            break;
                                        case I_MULTIPLY:
                                            strcpy(Instruction, "*");
                                            break;
                                        case I_DIVIDE:
                                            strcpy(Instruction, "/");
                                            break;
                                        case I_DIVIDE_FULL:
                                            strcpy(Instruction, "//");
                                            break;
                                        case I_GREATER:
                                            strcpy(Instruction, ">");
                                            break;
                                        case I_GREATER_EQUAL:
                                            strcpy(Instruction, ">=");
                                            break;
                                        case I_LOWER:
                                            strcpy(Instruction, "<");
                                            break;
                                        case I_LOWER_EQUAL:
                                            strcpy(Instruction, "<=");
                                            break;
                                        case I_EQUAL:
                                            strcpy(Instruction, "==");
                                            break;
                                        case I_NOT_EQUAL:
                                            strcpy(Instruction, "!=");
                                            break;
                                        default:
                                            return SYNTAX_ERROR;
                                            break;
                                    }
                                }
                                if (stackempty(tmp_stack)) {
                                    return SYNTAX_ERROR;
                                }

                                *var4 = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_NON_TERMINAL &&
                                    token_val_to_Toperator_t(var4) == O_NON_TERMINAL &&
                                    token_val_to_Instruction(operand) != -1) {
                                    //generuj kood pre var2 operand var 4 a vrat result
                                    //push result to basic stack
                                    CheckSize(basic_stack, struct Token);
                                    stackpush(basic_stack, struct Token, *replace_generate_token); //docasne riesenie
                                } else {
                                    return SYNTAX_ERROR;
                                }
                            }
                            else
                            {
                                return SYNTAX_ERROR;
                            }
                        }
                    }
                }
                    break;

                case N:
                    return SYNTAX_ERROR;
                    break;
                default:
                    return SYNTAX_ERROR;
                    break;
            }
        }
	}

	if (parser_data->while_stat == true)
	{
        CheckSize(basic_stack, struct Token);
        stackpush(basic_stack, struct Token, *dollar);

        while (strcmp(token->val, ":") != 0)
        {
            if(*(token->val) == '\n' || *(token->val) == EOF)
            {
                return SYNTAX_ERROR;
            }
            CheckSize(tmp_stack, struct Token);
            stackpush(tmp_stack, struct Token, *token);
            getToken(file, token);
        }

        CheckSize(tmp_stack, struct Token);
        stackpush(tmp_stack, struct Token, *dollar);

        while (stackempty(tmp_stack) != 1)
        {
            CheckSize(input_stack, struct Token);
            stackpush(input_stack, struct Token, stacktop(tmp_stack, struct Token));
            stackpop(tmp_stack);
        }
        //v basic stack je nas stack
        //v Input stack mame vstupujuce tokeny a na spodku $

        //a je zasobnik a b je vstup
        int i=0;
        while (token_val_to_Toperator_t(stack_terminal_top(basic_stack)) != O_DOLLAR || token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))) != O_DOLLAR)
        {
            Toperator_t a = token_val_to_Toperator_t(stack_terminal_top(basic_stack));
            Toperator_t b = token_val_to_Toperator_t(&(stacktop(input_stack, struct Token))); //mam jeho hodnotu ale este
            //ostal na zasobniku nezabudni POP!!!
            printf("Krok: %d\n",i);										                             //stackpop(input_stack) = getToken
            i++;

            switch (PrecTable[a][b])
            {
                case E :
                    printf("symbol: =\n");

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, stacktop(input_stack, struct Token));
                    stackpop(input_stack); //dalsi token
                    break;
                case L : //shift
                    printf("symbol: <\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) == O_NON_TERMINAL) //check it
                    {
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *tmp);
                        stackpop(basic_stack);
                        *tmp = stacktop(basic_stack, struct Token);
                    }

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, *reduce_symbol);

                    while (!stackempty(tmp_stack))
                    {
                        *tmp = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *tmp);
                    }

                    CheckSize(basic_stack, struct Token);
                    stackpush(basic_stack, struct Token, stacktop(input_stack, struct Token));
                    stackpop(input_stack); //dalsi token

                    break;
                case H : //reduce
                {
                    printf("symbol: >\n");

                    *tmp = stacktop(basic_stack, struct Token);

                    //najdenie symbolu < reduce
                    while (!stackempty(basic_stack) && token_val_to_Toperator_t(tmp) != O_TYPE_TO_REDUCE) //check it stackempty podmienku
                    {
                        *var2 = stacktop(basic_stack, struct Token);
                        stackpop(basic_stack);
                        CheckSize(tmp_stack, struct Token);
                        stackpush(tmp_stack, struct Token, *var2);
                        *tmp = stacktop(basic_stack, struct Token);

                    }

                    if (token_val_to_Toperator_t(tmp) == O_TYPE_TO_REDUCE) //vyhodim reduce symbol a do var2 ulozim vrchol tmp a teda ID
                    {
                        stackpop(basic_stack);
                        *var2 = stacktop(tmp_stack, struct Token);
                        stackpop(tmp_stack);
                    }
                    else
                    {
                        return SYNTAX_ERROR;
                    }

                    //T->id
                    if (token_val_to_Toperator_t(var2) == O_ID)
                    {
                        var2->Terminal_state = S_NON_TERM;
                        CheckSize(basic_stack, struct Token);
                        stackpush(basic_stack, struct Token, *var2);

                    }
                    else
                    {
                        //E->(E)
                        if  (token_val_to_Toperator_t(var2) == O_LEFTCOL)
                        {
                            if (stackempty(tmp_stack))
                            {
                                return SYNTAX_ERROR;
                            }

                            *operand = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (token_val_to_Toperator_t(operand) != O_NON_TERMINAL)
                            {
                                return SYNTAX_ERROR;
                            }

                            if (stackempty(tmp_stack))
                            {
                                return SYNTAX_ERROR;
                            }

                            *var4 = stacktop(tmp_stack, struct Token);
                            stackpop(tmp_stack);

                            if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_LEFTCOL && token_val_to_Toperator_t(var4) == O_RIGHTCOL && token_val_to_Toperator_t(operand) == O_NON_TERMINAL)
                            {
                                //generuj kood pre var2 operand var 4 a vrat result
                                //push result to basic stack
                                CheckSize(basic_stack, struct Token);
                                stackpush(basic_stack,struct Token,*replace_generate_token); //docasne riesenie
                            }
                            else
                            {
                                return SYNTAX_ERROR;
                            }
                        }
                        else {

                            //ak je na vrchole neterminal(spracovane ID)
                            if (token_val_to_Toperator_t(var2) == O_NON_TERMINAL) {

                                if (stackempty(tmp_stack)) {

                                    return SYNTAX_ERROR;
                                }

                                *operand = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                //T-> E+E -> E-E -> E*E -> E/E -> E//E -> E<>==E dorobit este zatvorky
                                if (token_val_to_Toperator_t(operand) != O_PLUS_MINUS &&
                                    token_val_to_Toperator_t(operand) != O_MULTIPLY_DIVIDE_DIVIDE_FULL &&
                                    token_val_to_Toperator_t(operand) != O_H_HE_L_LE_E_NE) {
                                    return SYNTAX_ERROR;
                                } else {
                                    printf("operand:%s\n", operand->val);

                                    switch (token_val_to_Instruction(operand)) {
                                        case I_PLUS:

                                            strcpy(Instruction, "+");
                                            break;
                                        case I_MINUS:
                                            strcpy(Instruction, "-");
                                            break;
                                        case I_MULTIPLY:
                                            strcpy(Instruction, "*");
                                            break;
                                        case I_DIVIDE:
                                            strcpy(Instruction, "/");
                                            break;
                                        case I_DIVIDE_FULL:
                                            strcpy(Instruction, "//");
                                            break;
                                        case I_GREATER:
                                            strcpy(Instruction, ">");
                                            break;
                                        case I_GREATER_EQUAL:
                                            strcpy(Instruction, ">=");
                                            break;
                                        case I_LOWER:
                                            strcpy(Instruction, "<");
                                            break;
                                        case I_LOWER_EQUAL:
                                            strcpy(Instruction, "<=");
                                            break;
                                        case I_EQUAL:
                                            strcpy(Instruction, "==");
                                            break;
                                        case I_NOT_EQUAL:
                                            strcpy(Instruction, "!=");
                                            break;
                                        default:
                                            return SYNTAX_ERROR;
                                            break;
                                    }
                                }
                                if (stackempty(tmp_stack)) {
                                    return SYNTAX_ERROR;
                                }

                                *var4 = stacktop(tmp_stack, struct Token);
                                stackpop(tmp_stack);

                                if (stackempty(tmp_stack) && token_val_to_Toperator_t(var2) == O_NON_TERMINAL &&
                                    token_val_to_Toperator_t(var4) == O_NON_TERMINAL &&
                                    token_val_to_Instruction(operand) != -1) {
                                    //generuj kood pre var2 operand var 4 a vrat result
                                    //push result to basic stack
                                    CheckSize(basic_stack, struct Token);
                                    stackpush(basic_stack, struct Token, *replace_generate_token); //docasne riesenie
                                } else {
                                    return SYNTAX_ERROR;
                                }
                            }
                            else
                            {
                                return SYNTAX_ERROR;
                            }
                        }
                    }
                }
                    break;

                case N:
                    return SYNTAX_ERROR;
                    break;
                default:
                    return SYNTAX_ERROR;
                    break;
            }
        }
	}

    free(var2);
    free(operand);
    free(var4);

    free(tmp);
    free(dollar);
    free(reduce_symbol);
    free(replace_generate_token);

    free(basic_stack);
    free(input_stack);
    free(tmp_stack);

    free(Instruction);

	return 0;
}



// funkcia vracia terminal na zasobniku najlbizsie vrcholu
struct Token* stack_terminal_top(Tstack* searched_stack)
{
	struct Token* tmp = malloc(sizeof(struct Token));
	struct Token* top_terminal = malloc(sizeof(struct Token));
	Tstack* tmp_stack = malloc(sizeof(Tstack));

	stackinit(tmp_stack, struct Token);


	*tmp = stacktop(searched_stack, struct Token);

	while (!stackempty(searched_stack) && token_val_to_Toperator_t(tmp) == O_NON_TERMINAL) //todo pre premenne
	{
		stackpush(tmp_stack, struct Token, *tmp);
		stackpop(searched_stack);
		*tmp = stacktop(searched_stack, struct Token);
	}

	*top_terminal = *tmp;

	while (!stackempty(tmp_stack))
	{
		*tmp = stacktop(tmp_stack, struct Token);
		stackpop(tmp_stack);
		stackpush(searched_stack, struct Token, *tmp);
	}

	free(tmp_stack);
	free(tmp);
	//printf("TOP:%s\n", top_terminal->val);
	return top_terminal;
}

Toperator_t token_val_to_Toperator_t(struct Token* token)
{
	if (token->type == T_OPERATOR && strcmp(token->val, "+") == 0)
	{
		return O_PLUS_MINUS;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "-") == 0)
	{
		return O_PLUS_MINUS;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "*") == 0)
	{
		return O_MULTIPLY_DIVIDE_DIVIDE_FULL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "/") == 0)
	{
		return O_MULTIPLY_DIVIDE_DIVIDE_FULL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "//") == 0)
	{
		return O_MULTIPLY_DIVIDE_DIVIDE_FULL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "(") == 0)
	{
		return O_LEFTCOL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, ")") == 0)
	{
		return O_RIGHTCOL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, ">") == 0)
	{
		return O_H_HE_L_LE_E_NE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, ">=") == 0)
	{
		return O_H_HE_L_LE_E_NE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "<") == 0)
	{
		return O_H_HE_L_LE_E_NE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "<=") == 0)
	{
		return O_H_HE_L_LE_E_NE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "==") == 0)
	{
		return O_H_HE_L_LE_E_NE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "!=") == 0)
	{
		return O_H_HE_L_LE_E_NE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "#") == 0)
	{
		return O_TYPE_TO_REDUCE;
	}

	if (token->Terminal_state == S_TERM && (token->type == T_ID || token->type == T_INTEGER || token->type == T_STRING || token->type == T_DBL || token->type == T_DBL_E || token->type == T_DBL_ES))
	{
		return O_ID;
	}

	if (token->Terminal_state == S_NON_TERM)
	{
		return O_NON_TERMINAL;
	}

	return O_DOLLAR;
}

Instruction token_val_to_Instruction(struct Token* token)
{
	if (token->type == T_OPERATOR && strcmp(token->val, "+") == 0)
	{
		return I_PLUS;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "-") == 0)
	{
		return I_MINUS;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "*") == 0)
	{
		return I_MULTIPLY;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "/") == 0)
	{
		return I_DIVIDE;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "//") == 0)
	{
		return I_DIVIDE_FULL;
	}


	if (token->type == T_OPERATOR && strcmp(token->val, ">") == 0)
	{
		return I_GREATER;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, ">=") == 0)
	{
		return I_GREATER_EQUAL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "<") == 0)
	{
		return I_LOWER;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "<=") == 0)
	{
		return I_LOWER_EQUAL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "==") == 0)
	{
		return I_EQUAL;
	}

	if (token->type == T_OPERATOR && strcmp(token->val, "!=") == 0)
	{
		return I_NOT_EQUAL;
	}

	return -1;
}
