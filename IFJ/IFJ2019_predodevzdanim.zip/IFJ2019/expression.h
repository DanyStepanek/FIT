/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Juraj Lazorik (xlazor02)                             *
 *	Date: 11.12.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#ifndef IFJ_EXPRESSION_H
#define IFJ_EXPRESSION_H

#include "parser.h"

#define ARRAY_SIZE 7

typedef enum {
	L = 100,		// < 
	H = 101,		// >
	E = 102,		// =
	N = 103,		// N
}TablePriority_t;

typedef enum Toperator_t {
	O_PLUS_MINUS,			// +
	//O_MINUS,		// -
	O_MULTIPLY_DIVIDE_DIVIDE_FULL,		// *
	//O_DIVIDE,		// /
	//O_DIVIDE_FULL,	// //
	O_LEFTCOL,		// (
	O_RIGHTCOL,		// )
	O_ID,			// id
	O_H_HE_L_LE_E_NE,		// >
	//O_HIGHER_OR_EQ,	// >=
	//O_LOWER,		// <
	//O_LOWER_OR_EQ,	// <=
	//O_EQUAL,		// ==
	//O_NOT_EQUAL,	// !=
	O_DOLLAR,		// $

	O_NON_TERMINAL,	//
	O_TYPE_TO_REDUCE //maybe dont need
}Toperator_t;

typedef enum Instruction {
	I_PLUS=0,
	I_MINUS,
	I_MULTIPLY,
	I_DIVIDE,
	I_DIVIDE_FULL,
	I_GREATER,
	I_GREATER_EQUAL,
	I_LOWER,
	I_LOWER_EQUAL,
	I_EQUAL,
	I_NOT_EQUAL

} Instruction;


struct Token* stack_terminal_top(Tstack* searched_stack);
Toperator_t token_val_to_Toperator_t(struct Token* token);
Instruction token_val_to_Instruction(struct Token* token);



#endif