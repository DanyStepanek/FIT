/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Juraj Lazorik (xlazor02)                             *
 *	Date: 11.12.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#ifndef IFJ_GENERATOR_J_H
#define IFJ_GENERATOR_J_H

#include "expression.h"
#include "dynamic_string.h"

/*
 * Hlavicky funkci v souboru parser.h, z duvodu potizi pri vzajemnem
 * includovani techto souboru.
 */

#endif //IFJ_GENERATOR_J_H
