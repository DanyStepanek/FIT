var searchData=
[
  ['name',['name',['../structMethod.html#aaa3bc473db253cbd522121f15781bd25',1,'Method']]],
  ['nofpoints',['nofPoints',['../structPointBoxData.html#acca7bde471ab3396be16f21efda7c639',1,'PointBoxData::nofPoints()'],['../structPointCircleData.html#a7abecef6dbc69a26cc54066632bee9f0',1,'PointCircleData::nofPoints()'],['../structPointSquareData.html#ae6ea4fe73b1bd8c83ff2de1d6183b841',1,'PointSquareData::nofPoints()']]],
  ['normal',['normal',['../structBunnyVertex.html#aa7f67904a835c896f368dd2e37cc46db',1,'BunnyVertex']]]
];
