/*
	IFJ Projekt 2018
	Scanner
	David Triska

*/

#include "Scanner.h"

/*

int scanner_ALL(Tlist* t, FILE* inputFile){

}
*/