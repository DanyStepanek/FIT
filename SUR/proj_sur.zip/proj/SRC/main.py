from img_classifier import *
#from voice_classifier import *

print('muj magicky klasifikator ;*')
