/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 26.11.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/
#ifndef IFJ_GENERATOR_H
#define IFJ_GENERATOR_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "err_code.h"
#include "other_functions.h"

// hodnoty které se ukládájí do atributu op_code
typedef enum {
    C_OPERATOR = 1000, //pro jednomistne operatory
    C_DBL_ES = 1001, //double signed exponent
    C_DBL_E = 1002, //double exponent
    C_DBL = 1003, //double
    C_INTEGER = 1004, //ZERO taky
    C_STRING = 1005,
    C_ID = 1006, //identifikator
    C_FUNC,
    C_LEN

} CodeType;

typedef struct CodeData{
  char* name;
  char* value;
  char* frame;
} CodeData;

typedef struct InnerCode{
  CodeType op_code;
  int params_count;
  CodeData* params[];
} InnerCode;



CodeData* fill_code_data(char* name, char* value, char* frame);

InnerCode* fill_inner_code(CodeType op_code, CodeData* params[], int params_count);

void free_code_data(CodeData* data);

void free_inner_code(InnerCode* code);

void generate(InnerCode* code);

#endif
