/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 2.10.2019                                                 *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/


#include "parser.h"

STable* global_frame;
STable* local_frame;
STable* tmp_frame;
TList* frame_list;
Tstack* token_stack;
Parse_data* parser_data;
struct TData* id;
FILE *file;
PStack* if_stack;
PStack* while_stack;
Dynamic_string output_string;

int expr_(struct Token* token){

	int res;

	res = process_expression(token, parser_data, file,global_frame,tmp_frame,frame_list);

  if (res != 0)
  {
	  call_error(res, res);
	  exit(res);
  }

  return 0;
}

int print_(struct Token* token){

  if(strcmp(token->val, "(") != 0 ){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

  int err_code = 0;

  while(strcmp(token->val, ")") != 0){

    if(token->type == T_ID){
			//pro rozsliseni, zda se nejedna o levou hodnotu prirazeni.
      parser_data->r_value = true;
      err_code = id_(token);
      parser_data->r_value = false;

      generate_WRITE_id(parser_data,id->name);
    }
    else if(token->type >= T_DBL_ES && token->type <= T_STRING){

      convert_string2codeString(token->val, &output_string);
        generate_WRITE(parser_data,output_string.str);
        string_clear(&output_string);

    }
    else{
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") == 0){

      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    }
    else if(strcmp(token->val, ")") == 0){

    }
    else{
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
  }

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(token->type != T_EOL && token->type != T_EOF){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

    return 0;
}

int inputs_(struct Token* token){

	if(strcmp(token->val, "(") != 0 ){
		call_error(SYNTAX_ERROR, SYNTAX_ERROR);
		exit(SYNTAX_ERROR);
	}

	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
	if(strcmp(token->val, ")") != 0){
	    //ak dalsi symbol nie je ) urcite to bude aspon syntakticka chyba ale este overime ci tam nahodou nie je nieco ine
        if(token->type >= T_OPERATOR && token->type <= T_ID){
            call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
            exit(SEM_PAR_ERROR);
        }
		call_error(SYNTAX_ERROR, SYNTAX_ERROR);
		exit(SYNTAX_ERROR);
	}

	if(parser_data->l_value != NULL){
        generate_READ(parser_data,parser_data->l_value,"string");
	}

	return 0;
}

int inputi_(struct Token* token){

	if(strcmp(token->val, "(") != 0 ){
		call_error(SYNTAX_ERROR, SYNTAX_ERROR);
		exit(SYNTAX_ERROR);
	}

	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") != 0){
        //ak dalsi symbol nie je ) urcite to bude aspon syntakticka chyba ale este overime ci tam nahodou nie je nieco ine
        if(token->type >= T_OPERATOR && token->type <= T_ID){
            call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
            exit(SEM_PAR_ERROR);
        }
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        exit(SYNTAX_ERROR);
    }
    if(parser_data->l_value != NULL) {
        generate_READ(parser_data, parser_data->l_value, "int");
    }
  return 0;
}

double inputf_(struct Token* token){

	if(strcmp(token->val, "(") != 0 ){
		call_error(SYNTAX_ERROR, SYNTAX_ERROR);
		exit(SYNTAX_ERROR);
	}

	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") != 0){
        //ak dalsi symbol nie je ) urcite to bude aspon syntakticka chyba ale este overime ci tam nahodou nie je nieco ine
        if(token->type >= T_OPERATOR && token->type <= T_ID){
            call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
            exit(SEM_PAR_ERROR);
        }
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        exit(SYNTAX_ERROR);
    }
    if(parser_data->l_value != NULL) {
        generate_READ(parser_data, parser_data->l_value, "float");
    }
  return 0;
}

int len_(struct Token* token){

  generate_createFrame(parser_data);
  int length = 0;

// prvni parametr.
  if(strcmp(token->val, "(") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_STRING){
      length = strlen(token->val);
      generate_new_argument_value(parser_data,token->val,"string","1");
    }
    else if(token->type == T_ID){

			if(strcmp(token->val, "None") == 0){
				call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
				exit(4);
			}

        if (!parser_data->function)
        {
            if (!in_table(global_frame, token->val))
            {
                exit(SEMANTIC_ERROR);
            }
        }
        else
        {
            if (!in_table(global_frame, token->val))
            {
                if (!in_table(tmp_frame, token->val))
                {
                    exit(SEMANTIC_ERROR);
                }
            }
        }


        generate_new_argument_id(parser_data,token->val, "1");

      length = strlen(id->value);
    }
    else{
      call_error(SEMANTIC_TYP_ERROR, 4);
      exit(4);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") == 0){
      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      if(token->type == T_EOL){
        return length;
      }
      else{
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        exit(SYNTAX_ERROR);
      }
    }
    else{
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
  }
/****************************************/
    generate_function_call(parser_data,"length");

    if(parser_data->l_value != NULL){
        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
    }

  return 0;
}

int substr_(struct Token* token){

    generate_createFrame(parser_data);

    char* tmp_string;
    int begin = 0;
    int str_length = 0;
    int len = 0;

    if(strcmp(token->val, "(") != 0 ){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
// prvni parametr
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type == T_STRING){
      str_length = strlen(token->val);
      tmp_string = token->val;
        generate_new_argument_value(parser_data,token->val,"string","1");
    }
    else if(token->type == T_ID){

			if(strcmp(token->val, "None") == 0){
				call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
				exit(4);
			}

        if (!parser_data->function)
        {
            if (!in_table(global_frame, token->val))
            {
                exit(SEMANTIC_ERROR);
            }
        }
        else
        {
            if (!in_table(global_frame, token->val))
            {
                if (!in_table(tmp_frame, token->val))
                {
                    exit(SEMANTIC_ERROR);
                }
            }
        }
    	str_length = strlen(id->value);
      tmp_string = id->value;
        generate_new_argument_value(parser_data,token->val,"string","1");
    }
    else if(( token->type >= 1000 && token->type <= 1004 ) && (strcmp(token->val, ")") != 0 && strcmp(token->val, ",") != 0)){
			call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
      exit(4);
    }
		else{
			call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
			exit(5);
		}
/**********************************************************************/
// druhy parametr
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

    if(token->type == T_INTEGER){
      begin = atoi(token->val);
      if(begin < 0 || begin > str_length){
        parser_data->is_none = true;
				return -1;
      }
        generate_new_argument_value(parser_data,token->val,"int","2");
    }
    else if(token->type == T_ID){

			if(strcmp(token->val, "None") == 0){
				call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
				exit(4);
			}

        if (!parser_data->function)
        {
            if (!in_table(global_frame, token->val))
            {
                exit(SEMANTIC_ERROR);
            }
        }
        else
        {
            if (!in_table(global_frame, token->val))
            {
                if (!in_table(tmp_frame, token->val))
                {
                    exit(SEMANTIC_ERROR);
                }
            }
        }

      begin = atoi(id->value);
      if(begin < 0 || begin > str_length){
				parser_data->is_none = true;
				return -1;
      }
        generate_new_argument_value(parser_data,token->val,"int","2");
    }
		else if(( (token->type >= 1000 && token->type <= 1003) || token->type == 1005) && (strcmp(token->val, ")") != 0 && strcmp(token->val, ",") != 0)){
			call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
			exit(4);
		}
		else{
			call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
			exit(5);
		}

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
/***********************************************************************/
// treti parametr
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type == T_INTEGER){
      len = atoi(token->val);
      if(len < 0){
        parser_data->is_none = true;
				return -1;
      }
        generate_new_argument_value(parser_data,token->val,"int","3");
    }
    else if(token->type == T_ID){

			if(strcmp(token->val, "None") == 0){
				call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
				exit(4);
			}

        if (!parser_data->function)
        {
            if (!in_table(global_frame, token->val))
            {
                exit(SEMANTIC_ERROR);
            }
        }
        else
        {
            if (!in_table(global_frame, token->val))
            {
                if (!in_table(tmp_frame, token->val))
                {
                    exit(SEMANTIC_ERROR);
                }
            }
        }

      len = atoi(id->value);
      if(len < 0){
				parser_data->is_none = true;
				return -1;
      }
        generate_new_argument_value(parser_data,token->val,"int","3");
    }
		else if(( (token->type >= 1000 && token->type <= 1003) || token->type == 1005) && (strcmp(token->val, ")") != 0 && strcmp(token->val, ",") != 0)){
			call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
			exit(4);
		}
		else{
			call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
			exit(5);
		}

    str_length = strlen(tmp_string);
    for(int i = begin; i <= len; i++){
      if(i == str_length){
        break;
      }
    }

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
/*********************************************************************/
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }

    generate_function_call(parser_data,"substr");

    if(parser_data->l_value != NULL){
        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
    }

  return 0;
}

int ord_(struct Token* token){

    generate_createFrame(parser_data);

    int value = 0;
    int str_length = 0;

    if(strcmp(token->val, "(") != 0 ){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
//prvni parametr
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type == T_STRING){
      str_length = strlen(token->val);
      //tmp_string = token->val;
        generate_new_argument_value(parser_data,token->val,"string","1");
    }
    else if(token->type == T_ID){

			if(strcmp(token->val, "None") == 0){
				call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
				exit(4);
			}

        if (!parser_data->function)
        {
            if (!in_table(global_frame, token->val))
            {
                exit(SEMANTIC_ERROR);
            }
        }
        else
        {
            if (!in_table(global_frame, token->val))
            {
                if (!in_table(tmp_frame, token->val))
                {
                    exit(SEMANTIC_ERROR);
                }
            }
        }

        generate_new_argument_value(parser_data,token->val,"string","1");
      str_length = strlen(id->value);
      //tmp_string = id->value;
    }
		else if(( token->type >= 1000 && token->type <= 1004 ) && (strcmp(token->val, ")") != 0 && strcmp(token->val, ",") != 0)){
			call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
			exit(4);
		}
		else{
			call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
			exit(5);
		}

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ",") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
/**********************************************************************/
// druhy parametr
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type == T_INTEGER){
      value = atoi(token->val);
      if(value < 0 || value > str_length){
        parser_data->is_none = true;
				return -1;
      }
        generate_new_argument_value(parser_data,token->val,"string","2");
    }
    else if(token->type == T_ID){

			if(strcmp(token->val, "None") == 0){
				call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
				exit(4);
			}

        if (!parser_data->function)
        {
            if (!in_table(global_frame, token->val))
            {
                exit(SEMANTIC_ERROR);
            }
        }
        else
        {
            if (!in_table(global_frame, token->val))
            {
                if (!in_table(tmp_frame, token->val))
                {
                    exit(SEMANTIC_ERROR);
                }
            }
        }

      value = atoi(id->value);
      if(value < 0 || value > str_length){
				parser_data->is_none = true;
				return -1;
      }

        generate_new_argument_value(parser_data,token->val,"string","2");
    }
		else if(( (token->type >= 1000 && token->type <= 1003) || token->type == 1005) && (strcmp(token->val, ")") != 0 && strcmp(token->val, ",") != 0)){
			call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
			exit(4);
		}
		else{
			call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
			exit(5);
		}

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(strcmp(token->val, ")") != 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
/**********************************************************************/

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }

    generate_function_call(parser_data,"ord");

    if(parser_data->l_value != NULL){
        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
    }

  return 0;
}

char chr_(struct Token* token){

    generate_createFrame(parser_data);

  int value = 0;
  if(strcmp(token->val, "(") != 0 ){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }
//prvni parametr
  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }

  if(token->type == T_INTEGER){
    value = atoi(token->val);
    generate_new_argument_value(parser_data,token->val,"int","1");
  }
  else if(token->type == T_ID){

		if(strcmp(token->val, "None") == 0){
			call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
			exit(4);
		}
      if (!parser_data->function)
      {
          if (!in_table(global_frame, token->val))
          {
              exit(SEMANTIC_ERROR);
          }
      }
      else
      {
          if (!in_table(global_frame, token->val))
          {
              if (!in_table(tmp_frame, token->val))
              {
                  exit(SEMANTIC_ERROR);
              }
          }
      }

      generate_new_argument_value(parser_data,token->val,"int","1");
    value = atoi(id->value);

  }
	else if(( (token->type >= 1000 && token->type <= 1003) || token->type == 1005) && (strcmp(token->val, ")") != 0 && strcmp(token->val, ",") != 0)){
		call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
		exit(4);
	}
	else{
		call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
		exit(5);
	}

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, ")") != 0){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }
/*******************************************************************/
  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(token->type != T_EOL){
      if(token->type !=T_EOF){
          call_error(SYNTAX_ERROR, SYNTAX_ERROR);
          exit(SYNTAX_ERROR);
      }
  }

    generate_function_call(parser_data,"chr");

    if(parser_data->l_value != NULL){
        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
    }

  return (char)value;
}

int pass_(struct Token* token){
  if(token->type == T_EOL || token->type == T_EOF){
    return 0;
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }
}

int else_(struct Token* token){
	//kontrola urovne pro pripad zanoreni
	while(parser_data->uroven != parser_stack_pop(if_stack)){
		if(parser_stack_top(if_stack) == -1){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}
	}

  if(strcmp(token->val, ":") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
  }
  else{

    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

	int uroven = 0;
	int vracena_uroven = 0;

	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = vracena_uroven;
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				//vracena uroven je mensi nez uroven tohoto bloku prikazu, proto vynoreni o uroven vys.
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
			else if(token->type == T_EOF){
				return 0;
			}
			id_(token);

			if(token->type == T_DEDENT){
				//vracena uroven je mensi nez uroven tohoto bloku prikazu, proto vynoreni o uroven vys.
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					return 0;
				}
			}
			else if(token->type == T_EOF){
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}
	}
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

  return 0;
}

int if_(struct Token* token){

    char* if_level = malloc(sizeof(char)*10);

	parser_stack_push(if_stack, peekLexStack(LexStack));

    sprintf(if_level,"%d",if_stack->top);
    generate_if_head(parser_data);

  parser_data->if_stat = true;

  if(strcmp(token->val, ":") == 0){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
  }

  expr_(token);

  generate_conditional_jump(parser_data, if_level);
  parser_data->if_stat = false;

  if(strcmp(token->val, ":") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

	int uroven = 0;
	int vracena_uroven = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = vracena_uroven;
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				//vracena uroven je mensi nez uroven tohoto bloku prikazu, proto vynoreni o uroven vys nebo zavolani else.
				if(vracena_uroven < uroven) {
					parser_data->uroven = vracena_uroven;
					if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
					if(strcmp(token->val, "else") == 0){
						if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
            generate_else(parser_data,if_level);
						else_(token);
					}
					else if(token->type == T_EOF){
            generate_if_end(parser_data,if_level);
						return 0;
					}
					else{
						call_error(SYNTAX_ERROR, SYNTAX_ERROR);
						exit(SYNTAX_ERROR);
					}
          generate_if_end(parser_data,if_level);
					return 0;
				}
			}
			else if(token->type == T_EOF){
        generate_if_end(parser_data,if_level);
        return 0;
			}
			id_(token);

			if(token->type == T_DEDENT){
				//vracena uroven je mensi nez uroven tohoto bloku prikazu, proto vynoreni o uroven vys nebo zavolani else.
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
					if(strcmp(token->val, "else") == 0){
						if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
            generate_else(parser_data,if_level);
						else_(token);
					}
					else if(token->type == T_EOF){
            generate_if_end(parser_data,if_level);
						return 0;
					}
					else{
						call_error(SYNTAX_ERROR, SYNTAX_ERROR);
						exit(SYNTAX_ERROR);
					}
          generate_if_end(parser_data,if_level);
					return 0;
				}
			}
			else if(token->type == T_EOF){
        generate_if_end(parser_data,if_level);
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}

    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL && token->type != T_EOF && token->type != T_DEDENT){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
    }
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }


  return 0;
}

int while_(struct Token* token){

    char* while_level = malloc(sizeof(char)*10);

	parser_stack_push(while_stack, peekLexStack(LexStack));

	sprintf(while_level,"%d",while_stack->top);
  generate_while_head(parser_data,while_level); // todo doriesit index
  parser_data->while_stat = true;

  expr_(token);

  generate_conditional_jump(parser_data, while_level);

  parser_data->while_stat = false;

  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, ":") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if(token->type != T_EOL){
      call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      parser_data->run_err_code = SYNTAX_ERROR;
      exit(SYNTAX_ERROR);
    }
  }

	int uroven = 0;
	int vracena_uroven = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = vracena_uroven;
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
				//vracena uroven je mensi nez uroven tohoto bloku prikazu, proto vynoreni o uroven vys.
				if(vracena_uroven < uroven){
					parser_stack_pop(while_stack);
					parser_data->uroven = vracena_uroven;
                    generate_while_end(parser_data,while_level);
					return 0;
				}
			}
			else if(token->type == T_EOF){
        generate_while_end(parser_data,while_level);
        return 0;
			}
			id_(token);

			if(token->type == T_DEDENT){
				//vracena uroven je mensi nez uroven tohoto bloku prikazu, proto vynoreni o uroven vys.
				if(vracena_uroven < uroven){
					parser_stack_pop(while_stack);
					parser_data->uroven = vracena_uroven;
          generate_while_end(parser_data,while_level);
					return 0;
				}
			}

			if(token->type == T_EOF){
        generate_while_end(parser_data,while_level);
				return 0;
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
		}
	}
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

	parser_stack_pop(while_stack);
  return 0;
}

int return_(struct Token* token){

  //return muze byt jen ve funkci
  if(!parser_data->def_function){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

  if(token->type != T_EOL){
		parser_data->return_stat = true;
		int tmp = expr_(token);
		parser_data->return_stat = false;
		return tmp;
  }
  else{
		parser_data->is_none = true;
		return -1;
  }
}

int def_(struct Token* token){

	parser_data->def_function = true;
	parser_data->function = true;

  char* function_name;
  int params_count = 0;

  tmp_frame = malloc(sizeof(STable));
  if(check_malloc(tmp_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  init_table(tmp_frame);

  if(token->type == T_ID){
      function_name = token->val;
      parser_data->actual_func = token->val;
  }
  else{
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    parser_data->run_err_code = SYNTAX_ERROR;
    exit(SYNTAX_ERROR);
  }

  generate_function_start(function_name);
// zpracovani parametru
  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, "(") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    while(strcmp(token->val, ")") != 0){
    	if(token->type == T_ID){
				//create parameter as a local variable in frame.
				strcpy(id->name, token->val);

      	put_item(tmp_frame, id);

      	parser_data->params[params_count] = token->val;

        char * index = malloc(sizeof(char)*10);
        sprintf(index,"%d",params_count);
        generate_new_param(id->name,index);

        params_count += 1;
      }
      else{
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
        exit(SYNTAX_ERROR);
      }

      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      if(strcmp(token->val, ",") == 0){
        if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      }
      else if(strcmp(token->val, ")") == 0){
        ;
      }
      else{
        call_error(SYNTAX_ERROR, SYNTAX_ERROR);
        parser_data->run_err_code = SYNTAX_ERROR;
        exit(SYNTAX_ERROR);
      }
    }
	}
  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
	if(strcmp(token->val, ":")){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }
/**********************************************************************/
//telo funkce
  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(token->type != T_EOL){
    call_error(SYNTAX_ERROR, SYNTAX_ERROR);
    exit(SYNTAX_ERROR);
  }

	int uroven = 0;
	int vracena_uroven = 0;
	vracena_uroven = getToken(file, token);
	if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }
	if(token->type == T_INDENT){
		uroven = vracena_uroven;
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		while(token->type != T_EOF){
			if(token->type == T_DEDENT){
      	if(vracena_uroven < uroven) {
          parser_data->uroven = vracena_uroven;
          break;
        }
      }
			else if(token->type == T_EOF){
				exit(0);
			}
			id_(token);

			if(token->type == T_DEDENT){
				if(vracena_uroven < uroven){
					parser_data->uroven = vracena_uroven;
					break;
				}
			}
			else if(token->type == T_EOF){
                if(in_list(frame_list,function_name) == 1)
                {
                    call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
                    exit(SEMANTIC_ERROR);
                }
				exit(0);
			}
			vracena_uroven = getToken(file, token);
			if(vracena_uroven == -1){ exit(LEXICAL_ERROR); }

		}
	}
  else{
  	call_error(SYNTAX_ERROR, SYNTAX_ERROR);
  	exit(SYNTAX_ERROR);
  }

    if(in_list(frame_list,function_name) == 1)
    {
      call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
    	exit(SEMANTIC_ERROR);
    }
	list_insert_item(frame_list, tmp_frame, function_name, parser_data->params, params_count);

    tmp_frame = NULL;

    generate_update_return(parser_data);

	parser_data->def_function = false;
	parser_data->function = false;

	generate_function_end();
	return 0;
}

int assign_(struct Token* token){

  if(token->type == T_OPERATOR){
		if(strcmp(token->val, "(") == 0 || strcmp(token->val, ")") == 0 || strcmp(token->val, ",") == 0){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}

		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
			parser_data->assign_stat = true;

    	expr_(token);
			parser_data->assign_stat = false;

  }
	else{
		call_error(SYNTAX_ERROR, SYNTAX_ERROR);
		exit(SYNTAX_ERROR);
	}

  return 0;
}

int check_params(struct Token* token){

    generate_createFrame(parser_data);

    int ciarka_flag = 0;
    char * index = malloc(sizeof(char)*10);
    int ma_argumenty_flag = 0;


  if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
  if(strcmp(token->val, "(") == 0){
      for(int i = 0; i < parser_data->params_count; i++){

          if(ciarka_flag == 1 && strcmp(token->val,")") == 0){
              call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
              exit(SEM_PAR_ERROR);
          }

      	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }


      	if (ciarka_flag == 1){
            call_error(SYNTAX_ERROR, SYNTAX_ERROR);
            exit(SYNTAX_ERROR);
      	}

      	if(token->type == T_ID || (token->type >= T_DBL_ES && token->type <= T_STRING)){



      	    if (token->type == T_ID){
                if(!parser_data->function)
                {
                    if(!in_table(global_frame,token->val))
                    {
                        exit(SEMANTIC_ERROR);
                    }
                    sprintf(index,"%d",i);
                    generate_new_argument_id(parser_data,token->val, index);
                    ma_argumenty_flag =1;
                }
                else
                {
                    if(!in_table(global_frame,token->val))
                    {
                        if (!in_table(tmp_frame,token->val))
                        {
                            exit(SEMANTIC_ERROR);
                        }
                    }
                    sprintf(index,"%d",i);
                    generate_new_argument_id(parser_data,token->val, index);
                    ma_argumenty_flag =1;
                }
      	    } else{

                switch (token->type) {
                    case T_STRING:
                        sprintf(index,"%d",i);
                        generate_new_argument_value(parser_data, token->val, "string", index);
                        ma_argumenty_flag =1;
                        break;
                    case T_INTEGER:
                        sprintf(index,"%d",i);
                        generate_new_argument_value(parser_data, token->val, "int", index);
                        ma_argumenty_flag =1;
                        break;
                    case T_DBL:
                    case T_DBL_E:
                    case T_DBL_ES:
                        sprintf(index,"%d",i);
                        generate_new_argument_value(parser_data, token->val, "float", index);
                        ma_argumenty_flag =1;
                        break;
                    default:
                        break;
                }

      	    }

            if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
            if((i + 1) == parser_data->params_count){
                break;
            }
            else
            {
                if(strcmp(token->val, ",") != 0)
                {
                    ciarka_flag = 1;
                }
            }

        }
        else{
            call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
            exit(SEM_PAR_ERROR);
        }

      }

        if(!ma_argumenty_flag)
        {
            if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); } //zmena zakomentovane
        }


    	if(strcmp(token->val, ")") == 0){
      	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      	if(token->type != T_EOL){
      	    if (token->type != T_EOF){
                call_error(SYNTAX_ERROR, SYNTAX_ERROR);
                exit(SYNTAX_ERROR);
      	    }
      	}
    	}
			else{

            if (token->type >= T_OPERATOR && token->type <= T_ID && (strcmp(token->val, ")") != 0))
            {
                call_error(SEM_PAR_ERROR, SEM_PAR_ERROR);
                exit(SEM_PAR_ERROR);
            }

			    //syntax or semantic?
				call_error(SYNTAX_ERROR, SYNTAX_ERROR);
				exit(SYNTAX_ERROR);
			}
  }
  else{
    call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
    exit(SEMANTIC_ERROR);
  }

  return 0;
}

int id_(struct Token* token){

    char* nazov_funkce = malloc(sizeof(char)*strlen(token->val));

  if(strcmp(token->val, "print") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    print_(token);
  }
  else if(strcmp(token->val, "inputs") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    inputs_(token);
  }
  else if(strcmp(token->val, "inputi") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    inputi_(token);
  }
  else if(strcmp(token->val, "inputf") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    inputf_(token);
  }
  else if(strcmp(token->val, "len") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    len_(token);

}
  else if(strcmp(token->val, "substr") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    substr_(token);

  }
  else if(strcmp(token->val, "ord") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    ord_(token);
  }
  else if(strcmp(token->val, "chr") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    chr_(token);
  }
  else if(strcmp(token->val, "pass") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    pass_(token);
  }
  else if(strcmp(token->val, "if") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    if_(token);
  }
  else if(strcmp(token->val, "else") == 0) {
		if(if_stack->top == 0){
		  call_error(SYNTAX_ERROR, SYNTAX_ERROR);
      exit(SYNTAX_ERROR);
		}
		if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		else_(token);
  }
  else if(strcmp(token->val, "while") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    while_(token);
  }
  else if(strcmp(token->val, "return") == 0){
  	if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    return_(token);
  }
  else if(strcmp(token->val, "def") == 0){
    if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
		if(parser_data->def_function){
			call_error(SYNTAX_ERROR, SYNTAX_ERROR);
			exit(SYNTAX_ERROR);
		}
    def_(token);

  }
  else if(token->type == T_SPC || token->type == T_TAB){
      if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
      return 0;
  }
  else if(token->type == T_EOL ||token->type == T_DEDENT){
      return 0;
  }
  // ID
  else{
		if(parser_data->r_value){
			if(parser_data->def_function){
				if(in_table(tmp_frame, token->val)){
					get_item(tmp_frame, id, token->val);
					return 0;
				}
				else if(in_table(global_frame, token->val)){
					get_item(global_frame, id, token->val);
					return 0;
				}
				//pokud ID je funkce
				else if((local_frame = list_get_item(frame_list, token->val, parser_data->params, &parser_data->params_count)) != NULL){
				    generate_createFrame(parser_data);

                    nazov_funkce = token->val;
					check_params(token);
                    generate_function_call(parser_data,nazov_funkce);
                    if(parser_data->l_value != NULL){
                        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
                    }
					return 0;
				}
				else{
					call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
					exit(SEMANTIC_ERROR);
				}
			}
			else{
				if(in_table(global_frame, token->val)){
					get_item(global_frame, id, token->val);
					return 0;
				}
				//pokud ID je funkce
				else if((local_frame = list_get_item(frame_list, token->val, parser_data->params, &parser_data->params_count)) != NULL){
                    nazov_funkce = token->val;
                    check_params(token);
                    generate_function_call(parser_data,nazov_funkce);
                    if(parser_data->l_value != NULL){
                        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
                    }
					return 0;
				}
				else{
					call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
					exit(SEMANTIC_ERROR);
				}
			}
		}
		//l_value
		else{
			if(parser_data->def_function){
					//pokud ID je funkce
				if((local_frame = list_get_item(frame_list, token->val, parser_data->params, &parser_data->params_count)) != NULL){
                    nazov_funkce = token->val;
                    check_params(token);
                    generate_function_call(parser_data,nazov_funkce);
                    if(parser_data->l_value != NULL){
                        generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
                    }
					return 0;
				}
				else if(strcmp(parser_data->actual_func, token->val) == 0){
					call_error(SEMANTIC_ERROR, SEMANTIC_ERROR);
					exit(SEMANTIC_ERROR);
				}

				strcpy(id->name, token->val);
        parser_data->l_value = id->name;

        if(token->type == T_ID)
        {
          if(!parser_data->function)
          {
            if(!in_table(global_frame,token->val))
            {
              generate_DEFVAR(parser_data,token->val);
            }
          }
          else
          {
            if(!in_table(global_frame,token->val))
            {
              if (!in_table(tmp_frame,token->val))
              {
                generate_DEFVAR(parser_data,token->val);
              }
            }
          }
        }

        generate_DEFVAR(parser_data,token->val);

				if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
				assign_(token);
                put_item(tmp_frame, id);
			}
			else{
					//pokud ID je funkce
				if((local_frame = list_get_item(frame_list, token->val, parser_data->params, &parser_data->params_count)) != NULL){
        	nazov_funkce = token->val;
          check_params(token);
          generate_function_call(parser_data,nazov_funkce);
          if(parser_data->l_value != NULL){
          generate_MOVE_retval_to_Lvalue(parser_data,parser_data->l_value);
          }
					return 0;
				}

				strcpy(id->name, token->val);

                if(token->type == T_ID)
                {
                    if(!parser_data->function)
                    {
                        if(!in_table(global_frame,token->val))
                        {
                            generate_DEFVAR(parser_data,token->val);
                        }
                    }
                    else
                    {
                        if(!in_table(global_frame,token->val))
                        {
                            if (!in_table(tmp_frame,token->val))
                            {
                                generate_DEFVAR(parser_data,token->val);
                            }
                        }
                    }
                }



				parser_data->l_value = id->name;
				if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
				assign_(token);
                put_item(global_frame, id);
			}
		}
	}
	return parser_data->run_err_code;
}

// <prog>
int prog_(struct Token* token){

	bylEOL = 1;
  min_level = getToken(file, token);
	if(min_level != 0){ exit(LEXICAL_ERROR); }
	bylEOL = 0;

  while(token->type != T_EOF && bylEOF == 0){

    switch(token->type){
      case T_ID:
        parser_data->run_err_code = id_(token);
        break;
      case T_TAB:
        break;
      case T_EOL:
        parser_data->r_value = false;
        break;
      case T_SPC:
        break;
      case T_INDENT:
				call_error(LEXICAL_ERROR, LEXICAL_ERROR);
				exit(LEXICAL_ERROR);
        break;
      case T_DEDENT:
				if(isEmptyLexStack(LexStack)){
					call_error(SYNTAX_ERROR, SYNTAX_ERROR);
					exit(SYNTAX_ERROR);
				}
        break;
      default:
        parser_data->blind_code = true;
        expr_(token);
        parser_data->blind_code = false;
    }

		if(parser_data->run_err_code != 0){
			return parser_data->run_err_code;
		}

    if(!parser_data->function){
        if(getToken(file, token) == -1){ exit(LEXICAL_ERROR); }
    }
    else{
      parser_data->function = false;
    }
  }

  return parser_data->run_err_code;
}

int parse(FILE* f){

  frame_list = malloc(sizeof(TList));
  if(check_malloc(frame_list) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  global_frame = malloc(sizeof(STable));
  if(check_malloc(global_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  local_frame = malloc(sizeof(STable));
  if(check_malloc(local_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  tmp_frame = malloc(sizeof(STable));
  if(check_malloc(tmp_frame) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  token_stack = malloc(sizeof(Tstack));
  if(check_malloc(token_stack) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  parser_data = malloc(sizeof(struct Parse_data));
  if(check_malloc(parser_data) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  id = malloc(sizeof(struct TData));
  if(check_malloc(id) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }
  id->name = malloc(sizeof(char) * 100);
  id->value = malloc(sizeof(char) * 100);

  struct Token* t = malloc(sizeof(struct Token));
  if(check_malloc(t) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

	if_stack = malloc(sizeof(PStack));
	if(check_malloc(if_stack) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

	while_stack = malloc(sizeof(PStack));
	if(check_malloc(if_stack) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  file = f;

/********INIT**********************************/
  initToken(t);
  init_table(global_frame);
  init_table(local_frame);
  list_init(frame_list);
  init_table(tmp_frame);
	parser_stack_init(if_stack);
	parser_stack_init(while_stack);


  parser_data->token = malloc(sizeof(struct Token));
  if(check_malloc(parser_data->token) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  parser_data->actual_id = malloc(sizeof(struct TData));
  if(check_malloc(parser_data->actual_id) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }
  parser_data->actual_func = malloc(sizeof(char) * 100);  //nazev aktualni funkce ve ktere jsem.. globalni ramec == NULL
  if(check_malloc(parser_data->actual_func) == -1){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  parser_data->l_value = false;  //leva strana prirazeni(a = 2) => l_value = a
  parser_data->function = false;
  parser_data->while_stat = false;  //if in while_statement
  parser_data->if_stat = false; //if in if_statement
  parser_data->defined = false; //if promenna nebo funkce je definovana
  parser_data->declare = false;
  parser_data->r_value = false;
  parser_data->first_error = true;

  parser_data->name = malloc(sizeof(char) * 1000);
  parser_data->value = malloc(sizeof(char) * 2000);
  parser_data->frame = malloc(sizeof(char) * 4);

/*********MAIN_LOOP***********************/
  int err_code = 0;
	parser_data->uroven = 0;

  //<prog>->begin
  if((err_code = prog_(t)) != 0){
    call_error(err_code, err_code);

  }

/**********FREE_ALL*************************/

  free(parser_data->token);
  free(parser_data->actual_id);
  free(parser_data->actual_func);
  free(parser_data->name);
  free(parser_data->value);
  free(parser_data->frame);
  free(parser_data);
	free(if_stack);
	free(while_stack);

  resetToken(t);
  clear_table(global_frame);
  clear_table(tmp_frame);


  list_clear(frame_list);

  free(frame_list);
  free(t);
  free(global_frame);
  free(local_frame);

  return err_code;
}
