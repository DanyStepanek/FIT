/******************************************************************** 
 *  About: Main function          									*
 *		   															*
 *		    	 													*
 *																	*
 ********************************************************************
 *	IFJ projekt: "Implementace prekladace                       	*
 *				  imperativniho jazyka IFJ18."      				*
 *	Author(s): Daniel Stepanek (xstepa61)                       	*
 *	Date: 10.11.2018                                            	*
 *	VUT FIT Brno 2BIT                                           	*
 *                                                                  *
 *******************************************************************/
#include<stdio.h>
#include<stdlib.h>

#include "scanner.h"
#include "parser.h"
#include "err_code.h"
#include "interpret.h"



int main(int argc,char *argv[]){
	int check = 0;
	
	//inicializace struktury pro ukladani nactenych tokenu
	Tlist *t = init_Tlist();
//	Token *token = init_Token();
	
	buffer = (char *) malloc(sizeof(char)*100);
	if(buffer == NULL){
		fprintf(stderr,"Buffer allocation failed\n");
		exit(1);
	}

	if(argc == 2){
		file = fopen(argv[1],"r");
		if (file == NULL){
			fprintf(stderr,"The file cannot be opened.\n");
			exit(1);
		}
		check = syntax();	
			
	}
		if(check != 0){
			int line_n = 0;
			while(num_of_lines[line_n] != -1){
				fprintf(stderr,"%s:%d:  error:  \n", argv[1], num_of_lines[line_n]);
				line_n++;
			}
			
			fprintf(stderr,"Target [* %s *] is incorrect. \n  ***  Error [%d]: Compilation failed.  ***\n", argv[1],  check);
			
		}
		else
			printf("Target [* %s *] is correct. \n *** Compilation succeeded.  ***\n", argv[1]);
		
		//dealokace veskere alokovane pameti pouzite v Tlist
		free_Tlist(t);
	//	free_Token(token);
		// dealokace pro scanner 
		free(buffer);
		fclose(file);
return 0;
}
