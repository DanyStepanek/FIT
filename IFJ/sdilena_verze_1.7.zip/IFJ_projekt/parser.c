#include "parser.h"


int syntax(){
	int control = 0;
	int check = 0;	
	while(1){
		control = get_token(file);
	
		if(control == 0){	//if get_token return valid token
			switch(token->id){
				case 0:
					
					break;
			
				case 1:
			
					break;
				
				case 2:
					gen_string(token);
					break;
			
				case 3:
					gen_id(token);
					break;
			
			
			}
				free_Token(token);
		}
		else if(control == 1){	//EOF
			break;
		}
		else
			check = control;

		
	}
		
	//Something get wrong
	if(check != 0)
		return check;

	return 0;
}