//
// Created by juraj on 02.12.19.
//

#include "generator_j.h"

#define built_in_function_len                                 \
        "\n#Body of function length(s) [%1]"

#define built_in_function_substr \
        "\n#Body of function substr(s,i,n) [%1,%2,%3]"

#define built_in_function_ord \
        "\n#Body of function ord(s,i) [%1,%2]"

#define built_in_function_chr \
        "\n#Body of function chr(i) [%1]"

Dynamic_string main;
Dynamic_string function;


void convert_string2codeString(char *inputString, Dynamic_string *outputString) {
    char c;
    for(int i=0; i < strlen(inputString); i++) {
        c = inputString[i];
        switch(c) {
            case ' ':
                string_add_Cstr(outputString, "\\032");
                break;
            case '#':
                string_add_Cstr(outputString, "\\035");
                break;
            case '\n':
                string_add_Cstr(outputString, "\\010");
                break;
            case '\t':
                string_add_Cstr(outputString, "\\009");
                break;
            default:
                string_add_char(outputString, c);
                break;
        }
    }
}

void generate_function_header()
{
    string_add_Cstr(&function, ".IFJcode19\n");
    string_add_Cstr(&function, "DEFVAR GF@&exp_result\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand1\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand3\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand1_type\n");
    string_add_Cstr(&function, "DEFVAR GF@&operand3_type\n");
    string_add_Cstr(&function, "JUMP &main&\n");

}

void generate_main_header()
{
    string_add_Cstr(&main, "LABEL &main&\n");
    string_add_Cstr(&main, "CREATEFRAME\n");
    string_add_Cstr(&main, "PUSHFRAME\n");

}

void generate_built_in_functions()
{
    string_add_Cstr(&function, built_in_function_len);
    string_add_Cstr(&function, built_in_function_substr);
    string_add_Cstr(&function, built_in_function_ord);
    string_add_Cstr(&function, built_in_function_chr);

}

void generate_start()
{
    string_init(&function);
    string_init(&main);
    generate_function_header();
    generate_built_in_functions();
    generate_main_header();
}

void generate_print_code() {
    printf("%s\n%s\n", string_get_string(&function), string_get_string(&main));
}

void generate_function_start(char* actual_func)
{
    string_add_Cstr(&function, "LABEL &");
    string_add_Cstr(&function, actual_func);
    string_add_Cstr(&function, "\n");
    string_add_Cstr(&function, "PUSHFRAME\n");
    string_add_Cstr(&function, "DEFVAR LF@&return\n");
    string_add_Cstr(&function, "MOVE LF@&return None@None\n");
    string_add_Cstr(&function, "MOVE GF@&exp_result None@None\n");

}

void generate_function_end()
{
    string_add_Cstr(&function, "POPFRAME\n");
    string_add_Cstr(&function, "RETURN\n");

}

void generate_new_param(char* param, char* index)
{
    string_add_Cstr(&function, "DEFVAR LF@");
    string_add_Cstr(&function, param);
    string_add_char(&function, '\n');
    string_add_Cstr(&function, "MOVE LF@");
    string_add_Cstr(&function, param);
    string_add_Cstr(&function, " LF@%");
    string_add_Cstr(&function, index);
    string_add_char(&function, '\n');

}

void generate_createFrame(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "CREATEFRAME\n");
    }
    else
    {
        string_add_Cstr(&main, "CREATEFRAME\n");
    }

}

void generate_new_argument_id(Parse_data* parser_data,char* arg_name, char *index)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "DEFVAR TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "MOVE TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, ' ');
        string_add_Cstr(&function, "LF@");
        string_add_Cstr(&function, arg_name);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main, "DEFVAR TF@%");
        string_add_Cstr(&main, index);
        string_add_char(&function, '\n');
        string_add_Cstr(&main, "MOVE TF@%");
        string_add_Cstr(&main, index);
        string_add_char(&main, ' ');
        string_add_Cstr(&main, "LF@");
        string_add_Cstr(&main, arg_name);
        string_add_char(&main, '\n');
    }
}

void generate_new_argument_value(Parse_data* parser_data,char* value, char* type, char *index)
{
    if(parser_data->function) {
        string_add_Cstr(&function, "DEFVAR TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "MOVE TF@%");
        string_add_Cstr(&function, index);
        string_add_char(&function, ' ');
        string_add_Cstr(&function, type);
        string_add_Cstr(&function, "@");
        string_add_Cstr(&function, value);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main, "DEFVAR TF@%");
        string_add_Cstr(&main, index);
        string_add_char(&function, '\n');
        string_add_Cstr(&main, "MOVE TF@%");
        string_add_Cstr(&main, index);
        string_add_char(&main, ' ');
        string_add_Cstr(&main, type);
        string_add_Cstr(&main, "@");
        string_add_Cstr(&main, value);
        string_add_char(&main, '\n');
    }
}

void generate_function_call(Parse_data* parser_data,char* function_name)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "CALL &");
        string_add_Cstr(&function, function_name);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main, "CALL &");
        string_add_Cstr(&main, function_name);
        string_add_char(&main, '\n');
    }
}

void generate_MOVE_retval_to_Lvalue(Parse_data* parser_data,char *l_value_fnc)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "MOVE LF@");
        string_add_Cstr(&function, l_value_fnc);
        string_add_Cstr(&function, " TF@&return\n");
    }
    else
    {
        string_add_Cstr(&main, "MOVE LF@");
        string_add_Cstr(&main, l_value_fnc);
        string_add_Cstr(&main, " TF@&return\n");
    }
}

void generate_while_head(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "# ************************ WHILE <> DO ************************* #\n");
        string_add_Cstr(&function, "LABEL $loop%start%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main, "# ************************ WHILE <> DO ************************* #\n");
        string_add_Cstr(&main, "LABEL $loop%start%");
        string_add_Cstr(&main, labelID);
        string_add_char(&main, '\n');
    }
}

void generate_conditional_jump(Parse_data* parser_data, char *labelID)
{
    if(parser_data->function){
        if(parser_data->while_stat) {
            string_add_Cstr(&function, "JUMPIFEQ $loop%end%");
            string_add_Cstr(&function, labelID);
            string_add_Cstr(&function, " GF@%exp_result bool@false\n");
        }
        else {
            string_add_Cstr(&function, "JUMPIFEQ $%else%");
            string_add_Cstr(&function, labelID);
            string_add_Cstr(&function, " GF@&exp_result bool@false\n");
        }
    }
    else {
        if(parser_data->while_stat) {
            string_add_Cstr(&main, "JUMPIFEQ $loop%end%");
            string_add_Cstr(&main, labelID);
            string_add_Cstr(&main, " GF@&exp_result bool@false\n");
        }
        else {
            string_add_Cstr(&main, "JUMPIFEQ $%else%");
            string_add_Cstr(&main, labelID);
            string_add_Cstr(&main, " GF@&exp_result bool@false\n");
        }
    }
}

void generate_while_end(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function) {
        string_add_Cstr(&function, "JUMP $loop%start%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "# ************************* END WHILE ************************** #\n");
        string_add_Cstr(&function, "LABEL $loop%end%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else {
        string_add_Cstr(&main, "JUMP $loop%start%");
        string_add_Cstr(&main, labelID);
        string_add_char(&main, '\n');
        string_add_Cstr(&main, "# ************************* END WHILE ************************** #\n");
        string_add_Cstr(&main, "LABEL $loop%end%");
        string_add_Cstr(&main, labelID);
        string_add_char(&main, '\n');
    }
}

void generate_if_head(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "# ************************* IF <> THEN ************************* #\n");

    }
    else
    {
        string_add_Cstr(&main, "# ************************* IF <> THEN ************************* #\n");
    }
}

void generate_else(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "JUMP $if%end%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
        string_add_Cstr(&function, "# **************************** ELSE **************************** #\n");
        string_add_Cstr(&function, "LABEL $%else%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main, "JUMP $if%end%");
        string_add_Cstr(&main, labelID);
        string_add_char(&main, '\n');
        string_add_Cstr(&main, "# **************************** ELSE **************************** #\n");
        string_add_Cstr(&main, "LABEL $%else%");
        string_add_Cstr(&main, labelID);
        string_add_char(&main, '\n');
    }
}

void generate_if_end(Parse_data* parser_data,char *labelID)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "# *************************** END IF *************************** #\n");
        string_add_Cstr(&function, "LABEL $if%end%");
        string_add_Cstr(&function, labelID);
        string_add_char(&function, '\n');
    }
    else
    {
        string_add_Cstr(&main, "# *************************** END IF *************************** #\n");
        string_add_Cstr(&main, "LABEL $if%end%");
        string_add_Cstr(&main, labelID);
        string_add_char(&main, '\n');
    }
}

void generate_NIL_value(Parse_data* parser_data,char *identifier)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "MOVE LF@");
        string_add_Cstr(&function, identifier);
        string_add_Cstr(&main, " None@None");
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main, "MOVE LF@");
        string_add_Cstr(&main, identifier);
        string_add_Cstr(&main, " None@None");
        string_add_char(&main,'\n');
    }
}

void generate_PUSHS_id(Parse_data* parser_data,char* identifier)
{

    if(parser_data->function)
    {
        string_add_Cstr(&function, "PUSHS LF@");
        string_add_Cstr(&function, identifier);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main, "PUSHS LF@");
        string_add_Cstr(&main, identifier);
        string_add_char(&main,'\n');
    }
}

void generate_PUSHS_value(Parse_data* parser_data,char* type, char* value)
{
    if(parser_data->function)
    {
        string_add_Cstr(&function, "PUSHS ");
        string_add_Cstr(&function, type);
        string_add_Cstr(&function, "@");
        string_add_Cstr(&function, value);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main, "PUSHS ");
        string_add_Cstr(&main, type);
        string_add_Cstr(&main, "@");
        string_add_Cstr(&main, value);
        string_add_char(&main,'\n');
    }
}

void generate_INT2FLOAT(Parse_data* parser_data,bool operand1)
{
    if(parser_data->function) {
        if(operand1) {
            string_add_Cstr(&function, "POPS GF@&operand1\n");
            string_add_Cstr(&function, "INT2FLOATS\n");
            string_add_Cstr(&function, "PUSHS GF@&operand1\n");
        }
        else {
            string_add_Cstr(&function, "INT2FLOATS\n");
        }
    }
    else {
        if(operand1) {
            string_add_Cstr(&main, "POPS GF@&operand1\n");
            string_add_Cstr(&main, "INT2FLOATS\n");
            string_add_Cstr(&main, "PUSHS GF@&operand1\n");
        }
        else {
            string_add_Cstr(&main, "INT2FLOATS\n");
        }
    }
}
/* todo
void generate_stack_OPERATION(RuleType rule) {
    switch(rule) {
        case E_PLUS_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "ADDS\n")
            : string_add_Cstr(&main_s, "ADDS\n");
            break;
        case E_CONCAT_E:
            if(inFunction) {
                string_add_Cstr(&functions_s, "POPS GF@%operand3\n");
                string_add_Cstr(&functions_s, "POPS GF@%operand1\n");
                string_add_Cstr(&functions_s, "CONCAT GF@%exp_result GF@%operand1 GF@%operand3\n");
                string_add_Cstr(&functions_s, "PUSHS GF@%exp_result\n");
            }
            else {
                string_add_Cstr(&main_s, "POPS GF@%operand3\n");
                string_add_Cstr(&main_s, "POPS GF@%operand1\n");
                string_add_Cstr(&main_s, "CONCAT GF@%exp_result GF@%operand1 GF@%operand3\n");
                string_add_Cstr(&main_s, "PUSHS GF@%exp_result\n");
            }
            break;
        case E_MINUS_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "SUBS\n")
            : string_add_Cstr(&main_s, "SUBS\n");
            break;
        case E_MUL_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "MULS\n")
            : string_add_Cstr(&main_s, "MULS\n");
            break;
        case E_DIV_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "DIVS\n")
            : string_add_Cstr(&main_s, "DIVS\n");
            break;
        case E_IDIV_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "IDIVS\n")
            : string_add_Cstr(&main_s, "IDIVS\n");
            break;
        case E_LT_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "LTS\n")
            : string_add_Cstr(&main_s, "LTS\n");
            break;
        case E_LE_E:
            if(inFunction) {
                string_add_Cstr(&functions_s, "GTS\n");
                string_add_Cstr(&functions_s, "NOTS\n");
            }
            else {
                string_add_Cstr(&main_s, "GTS\n");
                string_add_Cstr(&main_s, "NOTS\n");
            }
            break;
        case E_GT_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "GTS\n")
            : string_add_Cstr(&main_s, "GTS\n");
            break;
        case E_GE_E:
            if(inFunction) {
                string_add_Cstr(&functions_s, "LTS\n");
                string_add_Cstr(&functions_s, "NOTS\n");
            }
            else {
                string_add_Cstr(&main_s, "LTS\n");
                string_add_Cstr(&main_s, "NOTS\n");
            }
            break;
        case E_EQ_E:
            (inFunction)
            ? string_add_Cstr(&functions_s, "EQS\n")
            : string_add_Cstr(&main_s, "EQS\n");
            break;
        case E_NEQ_E:
            if(inFunction) {
                string_add_Cstr(&functions_s, "EQS\n");
                string_add_Cstr(&functions_s, "NOTS\n");
            }
            else {
                string_add_Cstr(&main_s, "EQS\n");
                string_add_Cstr(&main_s, "NOTS\n");
            }
            break;
    }
}*/

void generate_POPS_toEXPresult(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "POPS GF@&exp_result\n");
    }
    else
    {
        string_add_Cstr(&main, "POPS GF@&exp_result\n");
    }
}

void generate_MOVE_exp_to_Lvalue(Parse_data* parser_data,char* lvalue_id)
{
    if (parser_data->function) {
        string_add_Cstr(&function, "MOVE LF@");
        string_add_Cstr(&function, lvalue_id);
        string_add_Cstr(&function, " GF@&exp_result\n");
    } else {
        string_add_Cstr(&main, "MOVE LF@");
        string_add_Cstr(&main, lvalue_id);
        string_add_Cstr(&main, " GF@&exp_result\n");
    }
}

void generate_update_return(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "MOVE LF@$return GF@&exp_result\n");
    }
    else
    {
        string_add_Cstr(&main, "MOVE LF@$return GF@&exp_result\n");
    }
}

void generate_READ(Parse_data* parser_data,char* value_id, char* value_type) {
    if (parser_data->function)
    {
        string_add_Cstr(&function, "READ LF@");
        string_add_Cstr(&function, value_id);
        string_add_char(&function, ' ');
        string_add_Cstr(&function, value_type);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main, "READ GF@");
        string_add_Cstr(&main, value_id);
        string_add_char(&main, ' ');
        string_add_Cstr(&main, value_type);
        string_add_char(&main,'\n');
    }
}

void generate_WRITE_id(Parse_data* parser_data,char *identifier)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "WRITE LF@");
        string_add_Cstr(&function, identifier);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main, "WRITE LF@");
        string_add_Cstr(&main, identifier);
        string_add_char(&main,'\n');
    }
}

void generate_WRITE(Parse_data* parser_data,char *string)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "WRITE string@");
        string_add_Cstr(&function, string);
        string_add_char(&function,'\n');
    }
    else
    {
        string_add_Cstr(&main, "WRITE string@");
        string_add_Cstr(&main, string);
        string_add_char(&main,'\n');
    }
}

void generate_DIV_by_0(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "POPS GF@&operand3\n");
        string_add_Cstr(&function, "JUMPIFNEQ $NO_DIV_BY_0 GF@&operand3 int@0\n");
        string_add_Cstr(&function, "EXIT int@9\n");
        string_add_Cstr(&function, "LABEL $NO_DIV_BY_0\n");
        string_add_Cstr(&function, "PUSHS GF@&operand3\n");
    }
    else
    {
        string_add_Cstr(&main, "POPS GF@&operand3\n");
        string_add_Cstr(&main, "JUMPIFNEQ $NO_DIV_BY_0 GF@&operand3 int@0\n");
        string_add_Cstr(&main, "EXIT int@9\n");
        string_add_Cstr(&main, "LABEL $NO_DIV_BY_0\n");
        string_add_Cstr(&main, "PUSHS GF@&operand3\n");
    }
}

void generate_DIV_by_0f(Parse_data* parser_data)
{
    if (parser_data->function)
    {
        string_add_Cstr(&function, "POPS GF@&operand3\n");
        string_add_Cstr(&function, "JUMPIFNEQ $NO_DIV_BY_0 GF@&operand3 float@0x0p+0\n");
        string_add_Cstr(&function, "EXIT int@9\n");
        string_add_Cstr(&function, "LABEL $NO_DIV_BY_0\n");
        string_add_Cstr(&function, "PUSHS GF@&operand3\n");
    }
    else
    {
        string_add_Cstr(&main, "POPS GF@&operand3\n");
        string_add_Cstr(&main, "JUMPIFNEQ $NO_DIV_BY_0 GF@&operand3 float@0x0p+0\n");
        string_add_Cstr(&main, "EXIT int@9\n");
        string_add_Cstr(&main, "LABEL $NO_DIV_BY_0\n");
        string_add_Cstr(&main, "PUSHS GF@&operand3\n");
    }
}

void generate_truly_false(Parse_data* parser_data)
{
    if(parser_data->function) {
        string_add_Cstr(&function, "POPS GF@&exp_result\n");
        string_add_Cstr(&function, "POPS GF@&exp_result\n");
        string_add_Cstr(&function, "PUSHS bool@false\n");
        string_add_Cstr(&function, "PUSHS bool@true\n");
    }
    else {
        string_add_Cstr(&main, "POPS GF@&exp_result\n");
        string_add_Cstr(&main, "POPS GF@&exp_result\n");
        string_add_Cstr(&main, "PUSHS bool@false\n");
        string_add_Cstr(&main, "PUSHS bool@true\n");
    }
}

/* todo
 #define STRING_kT 0
#define INT_kT 1
#define FLOAT_kT 2

void generate_TYPE_control(bool operand_1, unsigned known_type, char* function_id, sItemDataType *finalDataType) {
    static unsigned indexLabel = 0;
    char currentLabel[8] = {};
    sprintf(currentLabel, "%d", indexLabel++);

    string_add_Cstr(&functions_s, "POPS GF@%operand3\n");
    string_add_Cstr(&functions_s, "POPS GF@%operand1\n");

    if(known_type == FLOAT_kT) {
        *finalDataType = sI_TYPE_FLOAT;
    }
    else if(known_type == INT_kT){
        *finalDataType = sI_TYPE_UNDEFINED;
    }

    if(known_type != STRING_kT) {
        if(operand_1) {
            string_add_Cstr(&functions_s, "TYPE GF@%op1_type GF@%operand1\n");
            string_add_Cstr(&functions_s, "JUMPIFEQ $end$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op1_type string@");
            (known_type == INT_kT)
            ? string_add_Cstr(&functions_s, "int\n")
            : string_add_Cstr(&functions_s, "float\n");
            string_add_Cstr(&functions_s, "JUMPIFEQ $convert$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op1_type string@");
            (known_type == INT_kT)
            ? string_add_Cstr(&functions_s, "float\n") // !!!
            : string_add_Cstr(&functions_s, "int\n");
            string_add_Cstr(&functions_s, "EXIT int@4\nLABEL $convert$");               /// LABEL $convert$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);

            string_add_Cstr(&functions_s, "\nJUMPIFEQ $convertOP3$");                   /// UMPIFEQ $convertOP3$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op1_type string@float\n");

            string_add_Cstr(&functions_s, "PUSHS GF@%operand1\nINT2FLOATS\nPOPS GF@%operand1\n");

            string_add_Cstr(&functions_s, "JUMP $endConverts$");                        /// JUMP $endConverts$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
            string_add_Cstr(&functions_s, "LABEL $convertOP3$");                        /// LABEL $convertOP3$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
            string_add_Cstr(&functions_s, "PUSHS GF@%operand3\nINT2FLOATS\nPOPS GF@%operand3\n");
            string_add_Cstr(&functions_s, "LABEL $endConverts$");                       /// LABEL $endConverts$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
        }
        else {
            string_add_Cstr(&functions_s, "TYPE GF@%op3_type GF@%operand3\n");
            string_add_Cstr(&functions_s, "JUMPIFEQ $end$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op3_type string@");
            (known_type == INT_kT)
            ? string_add_Cstr(&functions_s, "int\n")
            : string_add_Cstr(&functions_s, "float\n");
            string_add_Cstr(&functions_s, "JUMPIFEQ $convert$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op3_type string@");
            (known_type == INT_kT)
            ? string_add_Cstr(&functions_s, "float\n")
            : string_add_Cstr(&functions_s, "int\n");
            string_add_Cstr(&functions_s, "EXIT int@4\nLABEL $convert$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);

            string_add_Cstr(&functions_s, "\nJUMPIFEQ $convertOP1$");                   /// UMPIFEQ $convertOP1$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op3_type string@float\n");

            string_add_Cstr(&functions_s, "\nPUSHS GF@%operand3\nINT2FLOATS\nPOPS GF@%operand3\n");

            string_add_Cstr(&functions_s, "JUMP $endConverts$");                        /// JUMP $endConverts$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
            string_add_Cstr(&functions_s, "LABEL $convertOP1$");                        /// LABEL $convertOP3$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
            string_add_Cstr(&functions_s, "PUSHS GF@%operand1\nINT2FLOATS\nPOPS GF@%operand1\n");
            string_add_Cstr(&functions_s, "LABEL $endConverts$");                       /// LABEL $endConverts$
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
        }
        string_add_Cstr(&functions_s, "LABEL $end$");
        string_add_Cstr(&functions_s, function_id);
        string_add_Cstr(&functions_s, "$");
        string_add_Cstr(&functions_s, currentLabel);
        string_add_char(&functions_s, '\n');
    }
    else {
        if(operand_1) {
            string_add_Cstr(&functions_s, "TYPE GF@%op1_type GF@%operand1\n");
            string_add_Cstr(&functions_s, "JUMPIFEQ $end_string$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op1_type string@");
            string_add_Cstr(&functions_s, "string\n");
            string_add_Cstr(&functions_s, "EXIT int@4\nLABEL $end_string$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
        }
        else {
            string_add_Cstr(&functions_s, "TYPE GF@%op3_type GF@%operand3\n");
            string_add_Cstr(&functions_s, "JUMPIFEQ $end_string$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_Cstr(&functions_s, " GF@%op3_type string@");
            string_add_Cstr(&functions_s, "string\n");
            string_add_Cstr(&functions_s, "EXIT int@4\nLABEL $end_string$");
            string_add_Cstr(&functions_s, function_id);
            string_add_Cstr(&functions_s, "$");
            string_add_Cstr(&functions_s, currentLabel);
            string_add_char(&functions_s, '\n');
        }
        *finalDataType = sI_TYPE_STRING;
    }
    string_add_Cstr(&functions_s, "PUSHS GF@%operand1\nPUSHS GF@%operand3\n");
}

void generate_TYPE_S_control(char* function_id) {
    static unsigned indexLabel = 0;
    char currentLabel[8] = {};
    sprintf(currentLabel, "%d", indexLabel++);

    string_add_Cstr(&functions_s, "POPS GF@%operand3\n");
    string_add_Cstr(&functions_s, "POPS GF@%operand1\n");
    string_add_Cstr(&functions_s, "TYPE GF@%op1_type GF@%operand1\n");
    string_add_Cstr(&functions_s, "TYPE GF@%op3_type GF@%operand3\n");
    string_add_Cstr(&functions_s, "JUMPIFEQ $end_s$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    string_add_Cstr(&functions_s, " GF@%op1_type GF@%op3_type\n");
    string_add_Cstr(&functions_s, "JUMPIFEQ $error$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    string_add_Cstr(&functions_s, " GF@%op1_type string@string\n");
    string_add_Cstr(&functions_s, "JUMPIFEQ $error$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    string_add_Cstr(&functions_s, " GF@%op3_type string@string\n");

    string_add_Cstr(&functions_s, "JUMPIFEQ $convert_op3$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    string_add_Cstr(&functions_s, " GF@%op1_type string@float\n");
    string_add_Cstr(&functions_s, "PUSHS GF@%operand1\nINT2FLOATS\nPOPS GF@%operand1\n");
    string_add_Cstr(&functions_s, "JUMP $end_s$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);

    string_add_Cstr(&functions_s, "\nLABEL $convert_op3$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    string_add_Cstr(&functions_s, "\nPUSHS GF@%operand3\nINT2FLOATS\nPOPS GF@%operand3\n");
    string_add_Cstr(&functions_s, "JUMP $end_s$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);

    string_add_Cstr(&functions_s, "\nLABEL $error$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    string_add_Cstr(&functions_s, "\nEXIT int@4\n");
    string_add_Cstr(&functions_s, "LABEL $end_s$");
    string_add_Cstr(&functions_s, function_id);
    string_add_Cstr(&functions_s, "$");
    string_add_Cstr(&functions_s, currentLabel);
    // concatenate
    string_add_Cstr(&functions_s, "\nPUSHS GF@%operand1\n");
    string_add_Cstr(&functions_s, "PUSHS GF@%operand3\n");
}*/
