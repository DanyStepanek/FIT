#include "parser.h"


#define RELEASE free_Token(token)
#define CONTENT token->value->string


#define 	NUMBER	1
#define 	NUMBER_DOUBLE	2
#define 	IDENTIFIER	3 
#define 	KEYWORD	4
#define 	OPERATOR	5
#define 	STRING	6
#define 	EOL	7
#define 	tEOF	8

#define	CONSTANT	0
#define	VARIABLE	1
#define	FUNCTION	2

	
	Node *root;	//pointer to root (symtable)

int syntax(){
	char* var = (char*) malloc(100);
	char* label = (char*) malloc(100);
	char* symb1 = (char*) malloc(100);
	char* symb2 = (char*) malloc(100);
	int type = 0;

	Node *node;

	
	if(!generator_start()) return -1;
	
	Node_init(&node);
	root = node;
	
	do {
		
		type = get_token();
		
	//	generate_move(token->value->string, token->value->string);
		
		
		
		switch(type){
				
			case NUMBER:
				//printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
			break;
			
			case NUMBER_DOUBLE:
			//	printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
			break;
			
			case IDENTIFIER:
				
				//<stat> -> input<item>
				if(strcmp(CONTENT, "inputi") == 0){
					//generate_read()


				}
				//<stat> -> input<item>
				else if(strcmp(CONTENT, "inputf") == 0){
					//generate_read()


				}
				//<stat> -> input<item>
				else if(strcmp(CONTENT, "inputs") == 0){
					//generate_read()


				}
				//<stat> -> print<item> <item_list>
				else if(strcmp(CONTENT, "print") == 0){
					RELEASE;
					type = get_token();
					if(strcmp(CONTENT, "(") == 0){
						RELEASE;
						type = get_token();
					}
					
					strcpy(symb1, CONTENT);
					generate_write(symb1);


				}
				//<stat> ->  length<item>
				else if(strcmp(CONTENT, "length") == 0){
					//generate_length()
					RELEASE;
					type = get_token();
					if(strcmp(CONTENT, "(") == 0){
						RELEASE;
						type = get_token();
						int len = strlen(CONTENT);
						
					}
					else {
						call_error(4, IDENTIFIER);
					}

				}
				//<stat> -> substr<item>
				else if(strcmp(CONTENT, "substr") == 0){
					//generate_substr()


				}
				//<stat> -> ord<item>
				else if(strcmp(CONTENT, "ord") == 0){
					//generate_ord()


				}
				//<stat> -> chr<item>
				else if(strcmp(CONTENT, "chr") == 0){
					//generate_chr()


				}
				
				else {
					strcpy(var, CONTENT);
					
					Node_create(&node, IDENTIFIER, token);
					node->data->global = true;
					
					RELEASE;
					type = get_token();
				
					// id = <assign>
					if(strcmp(CONTENT, "=")== 0){
						RELEASE;
						//	expr_arithmetic(var, symb1);
						type = get_token();
						strcpy(symb1, CONTENT);
						
						RELEASE;
						type = get_token();
						if(type == EOL)
							generate_move(var, symb1);
					}
					
				}
				
				
				
			break;
			
			case KEYWORD:
			
				//<stat> -> if<expr> EOL <st_list> else EOL <st_list> end EOL
				if(strcmp(CONTENT, "if") == 0){
					//generate_if()


				}
				//<stat> ->while <expr> do EOL <st_list> end EOL
				else if(strcmp(CONTENT, "while") == 0){
					//generate_while()


				}
				//<stat> -> return <expr>
				else if(strcmp(CONTENT, "return") == 0){
					//generate_return()


				}
				//<stat> ->def id <param>
				else if(strcmp(CONTENT, "def") == 0){
					//generate_def()


				}
			break;
			
			case OPERATOR:
			//	printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
			break;
			
			case STRING:
			//	printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
			break;
			
			case EOL:
			//	printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
			break;
			
			case tEOF:
			//	printf("token contains: %s, length %d, type %d \n",token->value->string, token->value->size, token->id); 
			break;
			
			default:
				return type;
			
			
			
			
		}	//end of switch(type)
		
		
		
		
		
				
/*******************************/	
			
		RELEASE;
			
	}  while (type != tEOF);
	print_tree(&node);
	Tree_delete(&node);
	free(var);
	free(symb1);
	free(symb2);
	free(label);
	
	generate_main_end();

	return 0;
}
	
	

