/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 2.10.2019                                                 *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/


#ifndef IFJ_PARSER_H
#define IFJ_PARSER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include "scanner.h"
#include "symtable.h"
#include "stack.h"
#include "list.h"
#include "err_code.h"
#include "other_functions.h"
#include "expression.h"
#include "generator.h"



typedef struct Parse_data{
  struct Token* token;
  struct TData* actual_id;

  char* actual_func;  //nazev aktualni funkce ve ktere jsem.. globalni ramec == NULL
  char* l_value;  //leva strana prirazeni(a = 2) => l_value = a

  char* name;   //pro generovani
  char* value;  //pro generovani
  char* frame;  //pro generovani
  CodeType op_code; //pro generovani

  bool function;
  bool while_stat;  //if in while_statement
  bool if_stat; //if in if_statement
  bool return_stat;
  bool assign_stat;
  bool defined; //if promenna nebo funkce je definovana
  bool declare;
  bool r_value;
  bool first_error;
  bool def_function;

  int run_err_code;
  int err_code;
  int params_count;
  int uroven;

  void* r_values[100]; //prava strana prirazeni, myslim ze vic jak 100 jich nebude
  char* params[]; //parametry funkce


} Parse_data;

int id_(struct Token* token);

int parse(FILE* f);

int process_expression(struct Token* token, Parse_data* parser_data, FILE* file,STable* global_frame,STable* local_frame,STable* tmp_frame);

#endif
