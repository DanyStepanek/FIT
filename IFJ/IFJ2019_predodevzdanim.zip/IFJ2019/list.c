/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                    *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 25.11.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#include "list.h"



void list_init(TList* l){
  if(l == NULL){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  l->count = 0;
  l->first = NULL;
  l->act = NULL;

}

void list_clear(TList* l){
  if(l == NULL){
    return;
  }

  struct TItem* tmp_item = l->act;
  while(tmp_item != NULL){
    tmp_item = l->act->prev;
    clear_table(l->act->table);
    free(l->act->table_name);
    free(l->act);
    l->act = tmp_item;
  }

  list_init(l);

  return;
}


 
int list_empty(TList* l){
  if(l == NULL){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  if(l->count == 0){
    return 1;
  }
  else{
    return 0;
  }
}

int in_list(TList* t, char* name){

    struct TItem* tmp = t->first;

    for(int i = 0; i < t->count; i++){
        if(strcmp(tmp->table_name, name) == 0){
            return 1;
        }

        tmp = t->first->next;
    }

    return 0;

}

/*
 *  Predpoklad: l->act ukazuje na posledni vlozeny prvek, tudiz staci vlozit za aktivni a prenest aktivitu
 *
 */
void list_insert_item(TList* l, STable* item, char* table_name, char** params, int params_count){
  if(l == NULL){
    call_error(INTERNAL_ERROR, INTERNAL_ERROR);
    exit(INTERNAL_ERROR);
  }

  if(l->first == NULL){
    struct TItem* tmp_item = malloc(sizeof(struct TItem));
    if(check_malloc(tmp_item) == -1){
      call_error(INTERNAL_ERROR, INTERNAL_ERROR);
      exit(INTERNAL_ERROR);
    }

    tmp_item->prev = NULL;
    tmp_item->next = NULL;

    tmp_item->table_name = malloc(sizeof(char) * (strlen(table_name) + 1));
    if(check_malloc(tmp_item->table_name) == -1){
      call_error(INTERNAL_ERROR, INTERNAL_ERROR);
      exit(INTERNAL_ERROR);
    }
    strcpy(tmp_item->table_name, table_name);
    tmp_item->table = item;

    l->first = tmp_item;
    l->count++;
    l->act = l->first;
  }
  else{
    struct TItem* tmp_item = malloc(sizeof(struct TItem));
    if(check_malloc(tmp_item) == -1){
      call_error(INTERNAL_ERROR, INTERNAL_ERROR);
      exit(INTERNAL_ERROR);
    }

    tmp_item->prev = l->act;
    tmp_item->next = NULL;

    tmp_item->table_name = malloc(sizeof(char) * (strlen(table_name) + 1));
    if(check_malloc(tmp_item->table_name) == -1){
      call_error(INTERNAL_ERROR, INTERNAL_ERROR);
      exit(INTERNAL_ERROR);
    }
    strcpy(tmp_item->table_name, table_name);
    tmp_item->table = item;

    l->act->next = tmp_item;
    l->count++;
    l->act = l->act->next;
  }

  l->act->params_count = params_count;

  for(int i = 0; i < params_count; i++){
    l->act->params[i] = params[i];
  }

  return;
}

STable* list_get_item(TList* l, char* table_name, char** params, int* params_count){

  struct TItem* tmp_item = l->first;

  while(tmp_item != NULL){
      if(strcmp(tmp_item->table_name, table_name) == 0){
        for(int i = 0; i < tmp_item->params_count; i++){
          params[i] = tmp_item->params[i];
        }
        *params_count = tmp_item->params_count;
        return tmp_item->table;
      }

      tmp_item = tmp_item->next;
  }

  return NULL;
}
