
/*                @Project: IFJ
-----------------------------------------------------
  @Author: Ondrej Bravenec xbrave03@stud.fit.vutbr.cz
-----------------------------------------------------
*/

#include "stack.h"
/*
 *Inicializace zasobniku
 *Parametry: Zasobnik
 */
void stack_init(tStack *S)
{
	S->First = NULL;
}

/*
 *Vkladani prvku do zasobniku
 *Parametry: Zasobnik, vkladane data
 */
void stack_push(tStack *S, int data)
{
	if (S->First == NULL)
    {
        tElement aux = malloc(sizeof(struct tSElement));
        if(aux == NULL)
        {
            return;
        }
        aux->data = data;
        aux->ptr_next = NULL;
        S->First = aux;
    }
    else
    {
        tElement aux = malloc(sizeof(struct tSElement));
        if(aux == NULL)
        {
            return;
        }
        aux->data = data;
        aux->ptr_next = S->First;
        S->First = aux;
    }
}

/*
 *Odebrani nejvyssiho prvku ze zasobniku a zkopirovani dat
 *Parametry: Zasobnik, zkopirovana data
 */
 void stack_pop(tStack *S, int data)
 {
     if (S->First != NULL)
    {
        data = S->First->data;
        tElement aux = S->First;
        S->First = S->First->ptr_next;
        free(aux);
    }
 }

 /*
 *Uvedeni zasobniku do puvodniho stavu
 *Parametry: Zasobnik
 */
 void stack_free(tStack *S)
{
    if (S->First != NULL)
    {
        while (S->First != NULL)
        {
            tElement aux = S->First;
            S->First = S->First->ptr_next;
            free(aux);
        }
    }
}


 /*
 *Kontrola zda neni zasobnik prazdny
 *Parametry: Zasobnik
 */
int stack_empty(tStack *S)
{
    return S->First == NULL; //kdyz se rovnaji vraci 1
}

