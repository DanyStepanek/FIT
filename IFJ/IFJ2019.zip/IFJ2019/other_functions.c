#include<stdio.h>
#include<stdlib.h>


int check_malloc(void* pointer){

  if(pointer == NULL){
    fprintf(stderr,"Internall error: Malloc failed.\n");
    return -1;
  }

  return 0;
}
