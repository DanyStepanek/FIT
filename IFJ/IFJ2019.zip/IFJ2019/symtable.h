/********************************************************************
 *	IFJ projekt: Implementace prekladace                   	        *
 *				  imperativniho jazyka IFJ19.	                            *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 2.10.2019                                                 *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/
 #ifndef IFJ_SYMTABLE_H
 #define IFJ_SYMTABLE_H

#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include "err_code.h"


#define MAX_SYMTABLE_SIZE 27457

#define DEBUG_OUTPUT 0


struct TData{
  char* name;
  char* value;
  int type;
  struct TData* next;
};

typedef struct {
  int items_count;
  int size;
  struct TData* items[MAX_SYMTABLE_SIZE];
} STable;



void init_table(STable *t);

int in_table(STable* t, char* key);

int get_hashkey(char* str);

void put_item(STable* t, struct TData* data);

void clear_table(STable* t);

void get_item(STable* t, struct TData* data, char* key);


#endif
