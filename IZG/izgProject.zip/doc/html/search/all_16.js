var searchData=
[
  ['Úkoly_20v_20cpu_20části',['Úkoly v cpu části',['../group__cpu__side.html',1,'']]],
  ['Úkoly_20v_20shaderech',['Úkoly v shaderech',['../group__shader__side.html',1,'']]]
];
