var searchData=
[
  ['linearalgebra_2ec',['linearAlgebra.c',['../linearAlgebra_8c.html',1,'']]],
  ['linearalgebra_2eh',['linearAlgebra.h',['../linearAlgebra_8h.html',1,'']]]
];
