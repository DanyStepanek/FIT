var searchData=
[
  ['stack',['Stack',['../stack_8h.html#acccdaeb94a63f3757825012007215c0d',1,'stack.h']]]
];
