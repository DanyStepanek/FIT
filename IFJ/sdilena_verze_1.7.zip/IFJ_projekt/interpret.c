//interpret jazyka ifj18
//generator kodu

#include "interpret.h"
int i = 0;
void gen_string(Token* token){
	i++;
	printf("%3d	write	%s\n", i , token->value->string);

}


void gen_id(Token* token){
	i++;
	printf("%3d	@ID 	%s\n", i , token->value->string);
}

void gen_expr(Token* token){
	
	
}