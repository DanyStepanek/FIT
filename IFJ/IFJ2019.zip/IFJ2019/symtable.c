#include "symtable.h"




void init_table(STable *t){

  t->items_count = 0;
  t->size = MAX_SYMTABLE_SIZE;
  for(int i = 0; i < MAX_SYMTABLE_SIZE; i++){
    t->items[i] = NULL;
  }

  return;
}


int get_hashkey(char* str){
  unsigned long hash = 0, x = 0;

  	for (char c = *str; c != '\0'; c = *(++str))
  	{
  		hash = (hash << 4) + c;
  		if ((x = hash & 0xF0000000L) != 0)
  		{
  			hash ^= (x >> 24);
  		}
  		hash &= ~x;
  	}

  	return hash % MAX_SYMTABLE_SIZE;
}

void put_item(STable* t, struct TData* data){

  if(t->items == NULL){
    return;
  }

  int i = get_hashkey(data->name);

  if(t->items[i] == NULL){
    t->items[i] = malloc(sizeof(struct TData));
    if(t->items[i] == NULL){
      fprintf(stderr, "Internall error (symtable): Malloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }

    t->items[i]->name = malloc(sizeof(char) * (strlen(data->name) + 1));
    if(t->items[i]->name == NULL){
      fprintf(stderr, "Internall error (symtable): Malloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    strcpy(t->items[i]->name, data->name);


    t->items[i]->value = malloc(sizeof(char) * (strlen(data->value) + 1));
    if(t->items[i]->value == NULL){
      fprintf(stderr, "Internall error (symtable): Malloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    strcpy(t->items[i]->value, data->value);

    t->items[i]->type = data->type;
    t->items[i]->next = NULL;
    t->items_count += 1;
  }
  else if(strcmp(t->items[i]->name, data->name) == 0){
    char* new_item;
    new_item = realloc(t->items[i]->value, strlen(data->value) + 1);
    if(new_item == NULL){
      fprintf(stderr, "Internall error (stack): Realloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    t->items[i]->value = new_item;
    strcpy(t->items[i]->value, data->value);
    t->items[i]->type = data->type;
  }
  else{
    struct TData* item = t->items[i];
    struct TData* tmp;
    while(item != NULL){
      if(strcmp(item->name, data->name) == 0){
        char* new_item;
        new_item = realloc(item->value, strlen(data->value) + 1);
        if(new_item == NULL){
          fprintf(stderr, "Internall error (stack): Realloc operation failed.\n");
          exit(INTERNAL_ERROR);
        }
        item->value = new_item;
        strcpy(item->value, data->value);

        item->type = data->type;
        return;
      }
      tmp = item;
      item = t->items[i]->next;
    }

    item = malloc(sizeof(struct TData));

    item->name = malloc(sizeof(char) * (strlen(data->name) + 1));
    if(item->name == NULL){
      fprintf(stderr, "Internall error (symtable): Malloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    strcpy(item->name, data->name);

    item->value = malloc(sizeof(char) * (strlen(data->value) + 1));
    if(item->value == NULL){
      fprintf(stderr, "Internall error (symtable): Malloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    strcpy(item->value, data->value);

    item->type = data->type;
    item->next = NULL;

    tmp->next = item;

  }

  return;
}

void clear_table(STable* t){
  if(t == NULL){
//    fprintf(stderr,"Internal error: SYMTABLE: Invalid pointer\n");
//    exit(-1);
    return;
  }
  if(t->items == NULL){
    return;
  }

  for(int i = 0; i < t->size; i++){
    if(t->items[i] != NULL){
      if(t->items[i]->next != NULL){
        struct TData* item = t->items[i]->next;
        struct TData* tmp = item;
        while(tmp != NULL){
          tmp = item->next;

          free(item->name);
          free(item->value);
          free(item);

          item = tmp;
        }
      }

      free(t->items[i]);
    }
  }

  t->items_count = 0;

  return;
}

int in_table(STable* t, char* key){

  int i = get_hashkey(key);

  return(t->items[i] ? 1 : 0);

}

void get_item(STable* t, struct TData* data, char* key){


  if(t == NULL){
    fprintf(stderr,"Internal error: SYMTABLE: Invalid pointer\n");
    exit(INTERNAL_ERROR);
  }
  if(t->items_count == 0){
    fprintf(stderr,"Internal error: SYMTABLE: Items count = 0\n");
    exit(INTERNAL_ERROR);
  }

  int i = get_hashkey(key);

  if(t->items[i] == NULL){
    data = NULL;
    return;
  }


  if(strcmp(t->items[i]->name, key) == 0){
    char* new_name;
    new_name = realloc(data->name, strlen(t->items[i]->name) + 1);
    if(new_name == NULL){
      fprintf(stderr, "Internall error (stack): Realloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    data->name = new_name;
    strcpy(data->name, t->items[i]->name);


    char* new_value;
    new_value = realloc(data->value, strlen(t->items[i]->value) + 1);
    if(new_value == NULL){
      fprintf(stderr, "Internall error (stack): Realloc operation failed.\n");
      exit(INTERNAL_ERROR);
    }
    data->value = new_value;
    strcpy(data->value, t->items[i]->value);

    data->type = t->items[i]->type;
    data->next = t->items[i]->next;

    return;
  }
  else{
    struct TData* item = t->items[i];
    while(item != NULL){

      if(strcmp(item->name, key) == 0){
        char* new_name;
        new_name = realloc(data->name, strlen(t->items[i]->name) + 1);
        if(new_name == NULL){
          fprintf(stderr, "Internall error (stack): Realloc operation failed.\n");
          exit(INTERNAL_ERROR);
        }
        data->name = new_name;
        strcpy(data->name, t->items[i]->name);

        char* new_value;
        new_value = realloc(data->name, strlen(t->items[i]->value) + 1);
        if(new_value == NULL){
          fprintf(stderr, "Internall error (stack): Realloc operation failed.\n");
          exit(INTERNAL_ERROR);
        }
        data->value = new_value;
        strcpy(data->value, t->items[i]->value);

        data->type = t->items[i]->type;
        data->next = item->next;

        return;
      }
      item = item->next;
    }
  }

  data = NULL;

  return;
}
