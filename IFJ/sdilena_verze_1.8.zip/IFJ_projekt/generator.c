
//generator jazyka ifj18code
//generator kodu

#include "generator.h"
int i = 0;

void gen_print(Token* token){
	i++;
	printf("%3d	write	%s\n", i , token->value->string);

}


void gen_id(Token* token){
	i++;
	printf("%3d	@ID 	%s\n", i , token->value->string);
}

void gen_expr(Token* token){
	i++;
	printf("%3d	@EXPR 	%s\n", i , token->value->string);
}
