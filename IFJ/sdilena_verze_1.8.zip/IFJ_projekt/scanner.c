

#include "scanner.h"

typedef enum{
	sSTART,
	sNUMBER,
	sNUMBER_DOUBLE,
	sIDENTIFIER,
	sOPERATOR,
	sSTRING,
	sEOF,
	sEOL,
	sLINE_COMMENT,
	sBLOCK_COMMENT,
	sERROR


} State;

Token *createToken(char *buffer, int t){
	int size = 0;
	Token *token = init_Token();
	
	for(int i=0;buffer[i]!='\0';i++){
		size++;
	}
		
	fill_Token(token, buffer, size, t);

	return token;
}


	bool missed_token = false;	//to check if we create token before
	bool missed_eol = false;
	
Token* get_token(){
	
	bool sign_double = false;	//voluntary sign (number_double)
	bool e_E_dot = false;	//if number is double
		
	char curr_char = '\0';
	static char prev_char;
	int control = sSTART;
	int i = 0;
	Token* token = init_Token();
	
	
	while(1){
		
		if(control == sSTART && prev_char != curr_char)
			curr_char = prev_char;
		else
			curr_char = getchar();
	
		
		//curr_char = prev_char;
	//	else if(missed_token == true) {
	//		curr_char = prev_char;
	//		missed_token = false;
	//	}
		
	//	printf("prev: %c\n ",prev_char);
	//	printf("curr: %c\n",curr_char);
		switch(control){
			//CREATE NEW TOKEN
			case sSTART:
			
				if(islower(curr_char) || curr_char == '_'){
					prev_char = curr_char;
					buffer[i++] = curr_char;
					control = sIDENTIFIER;
				}
	
				else if(isdigit(curr_char)){
					prev_char = curr_char;
					buffer[i++] = curr_char;
					control = sNUMBER;
				}
			
				else if(curr_char == '"'){
						control = sSTRING;
				}
				
				else if(curr_char == '#'){	
					prev_char = curr_char;
					control = sLINE_COMMENT;
				}
				
				else if(ispunct(curr_char) && curr_char != '_' && curr_char != '#' && curr_char != '"'){
					prev_char = curr_char;
					buffer[i++] = curr_char;
					control = sOPERATOR;
				}
				
				else if(curr_char == EOF){
					control = sEOF;
				}
				
				else if(curr_char == '\n'){
				
					control = sEOL;
				}
				
				else if(isspace(curr_char)){
					prev_char = curr_char;
					control = sSTART;
				}
				
				else {
					call_error(2,sERROR);
					exit(2);
				}
			
			break;
				
	
			case sNUMBER:
				if(isdigit(curr_char)){
					buffer[i++] = curr_char;
					prev_char = curr_char;
				
				}
				else if(curr_char == 'e' || curr_char == 'E' || curr_char == '.'){
					buffer[i++] = curr_char;
					control = sNUMBER_DOUBLE;
					e_E_dot = true;
				}	
				else if(curr_char == '\n' || (isspace(curr_char)) || ispunct(curr_char)){
					buffer[i] = '\0';
					token = createToken(buffer, sNUMBER);
					printf("vytvoril jsem token %s \n",token->value->string);
					prev_char = curr_char;
								
					return token;
				}
				else {	//LEXICAL_ERROR
					call_error(2,sNUMBER);
					exit(control);
				}	
					
			break;
			
			case sNUMBER_DOUBLE:
				if(isdigit(curr_char)){
					buffer[i++] = curr_char;
					prev_char = curr_char;
				}
				else if((curr_char == '+' || curr_char == '-' ) && sign_double == false && e_E_dot == true){
					sign_double = true;
					buffer[i++] = curr_char;
				}		
				else if((curr_char == '\n' || (isspace(curr_char)) || ispunct(curr_char)) &&
							(prev_char != 'e' || prev_char != 'E' || prev_char != '.')){
					buffer[i] = '\0';
					token = createToken(buffer, sNUMBER_DOUBLE);
					printf("vytvoril jsem token %s \n",token->value->string);
					prev_char = curr_char;
					return token;
				}
				else {	//LEXICAL_ERROR
					call_error(2,sNUMBER_DOUBLE);
					exit(control);
				}	
								
			break;
			
			case sIDENTIFIER:
					if(curr_char != '\n' && !(isspace(curr_char)) && !(ispunct(curr_char))){
						buffer[i++] = curr_char;
			
					}
					else {
						buffer[i] = '\0';
						token = createToken(buffer, sIDENTIFIER);
						printf("vytvoril jsem token %s \n",token->value->string);
						prev_char = curr_char;
					
						return token;
				}
			break;
			
			case sOPERATOR:
				if((prev_char == '<' || prev_char == '>') && curr_char == '=' && i <= 1)
					buffer[i++] = curr_char;
				else if(prev_char == '=' && (curr_char == '=' || curr_char == '!') && i <= 1){
					buffer[i++] = curr_char;
					prev_char = curr_char;
				}	
				else if(!(ispunct(curr_char)) || curr_char == '"'){
					buffer[i] = '\0';
					token = createToken(buffer, sOPERATOR);
					printf("vytvoril jsem token %s \n",token->value->string);
					prev_char = curr_char;
					return token;
				}	
				else {
					call_error(2,sOPERATOR);
					exit(control);
				}	
				
				
			break;
			
			case sSTRING:
				if(curr_char != '"' && curr_char != '\n')
					buffer[i++] = curr_char;
				else if(curr_char == '"'){
					buffer[i] = '\0';
					token = createToken(buffer, sSTRING);
					printf("vytvoril jsem token %s \n",token->value->string);
					
					prev_char = '\0';
					
					return token;
				}
				else if(curr_char == '\n'){
					call_error(2,sSTRING);
					exit(control);
				}	
									
			break;
			
			case sEOF:
				if(curr_char == EOF){
					token = createToken("EOF",sEOF);
					printf("vytvoril jsem token %s \n",token->value->string);
					
					return token;
				}
			break;
			
			case sEOL:			
					token = createToken("EOL",sEOL);
					printf("vytvoril jsem token %s \n",token->value->string);
					prev_char = curr_char;
					return token;
				
				
			break;
			
			case sLINE_COMMENT:
				if(curr_char == '\n'){
					prev_char = curr_char;
					control = sSTART;
				}
				else if(curr_char == EOF)
					control = sEOF;
				
			break;
			
			case sBLOCK_COMMENT:

			break;
		
		}	//end of switch
	
	}	//end of while
	
	
	return token;
}