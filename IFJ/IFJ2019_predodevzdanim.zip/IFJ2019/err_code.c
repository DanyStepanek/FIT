/********************************************************************
 *	IFJ projekt: "Implementace prekladace                           *
 *				  imperativniho jazyka IFJ19."                      *
 *	Author(s): Daniel Stepanek (xstepa61)                           *
 *	Date: 30.10.2019                                                *
 *	VUT FIT Brno                                                    *
 *                                                                  *
 *******************************************************************/

#include "err_code.h"


int call_error(int code, int specific){


	ERR_CODE type = code;

	switch (type){

	case 1:
		fprintf(stderr,"%d: LEX_ERROR\n", specific);
		break;
	case 2:
		fprintf(stderr,"%d: SYNTAX_ERROR\n",specific);
		break;
	case 3:
		fprintf(stderr,"%d: SEMANTIC_ERROR\n",specific);
		break;
	case 5:
		fprintf(stderr,"%d: WRONG PARAMETERS\n", specific);
		break;
	case 9:
		fprintf(stderr,"%d: ZERO_DIVISION_ERROR\n",specific);
		break;
	case 99:
		fprintf(stderr,"%d: INTERNAL_ERROR\n",specific);
		break;

	}

	return code;

}
