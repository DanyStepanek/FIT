
#ifndef DYNAMIC_STRING_H_INCLUDED
#define DYNAMIC_STRING_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef struct dstring{
	unsigned int length;
	int aloc;
	char* string;
}DString;


bool init_DString(DString * );
void free_DString(DString * );
int fill_DString(DString *, char* );
bool addstr_DString(DString *, char* );


#endif