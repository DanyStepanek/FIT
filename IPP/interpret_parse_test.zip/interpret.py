#!/usr/bin/python 3
# -*- coding: utf-8 -*-
"""
Created on Mon March  20 21:58:01 2019

@author: Daniel Stepanek xstepa61
"""

import sys
import re
import xml.etree.ElementTree as ET


class ParseXML():

    def Parse(self, source):
        tree = ET.parse(source)
        root = tree.getroot()
        self.__check_root(root)
        instructions = list()

        for instruction in root:
            if instruction.tag == 'name' or instruction.tag == 'description':
                continue
            if instruction.tag == 'instruction':
                #seradi instrukce podle 'order'
                order = int(instruction.get('order'))
                instructions.insert(order-1, self.__instruction_factory(instruction))
            else:
                sys.stderr.write("Wrong XML format")
                exit(31)

        return instructions

    def __check_root(self, root):
        if root.tag != 'program' or len(root.attrib) > 3 or root.attrib.get('language') != 'IPPcode19':
            sys.stderr.write("Wrong XML header format")
            exit(31)


    def __instruction_factory(self, instruction):
        opcode = instruction.get('opcode')
        inst_content = list(instruction)
        inst_content.insert(0,opcode)
        return inst_content


class TemporaryFrame():

    _frame_dict = dict()

    def __init__(self):
        pass

    def _add(self):
        pass

    def _sub(self):
        pass

    def _get(self):
        pass

class LocalFrame():

    _frame_list = list()

    def __init__(self):
        pass

    def _add(self):
        pass

    def _sub(self):
        pass

    def _get(self):
        pass

class GlobalFrame():

    _frame_dict = dict()

    def __init__(self):
        pass

    def _add(self):
        pass

    def _sub(self):
        pass

    def _get(self):
        pass


class InstructionDict():

    opcode_dict = dict()
    opcode_dict['MOVE'] = [2,'var','symb']
    opcode_dict['CREATEFRAME'] = [0]
    opcode_dict['PUSHFRAME'] = [0]
    opcode_dict['POPRFRAME'] = [0]
    opcode_dict['DEFVAR'] = [1,'var']
    opcode_dict['CALL'] = [1,'label']
    opcode_dict['RETURN'] = [0]
    opcode_dict['PUSHS'] = [1, 'symb']
    opcode_dict['POPS'] = [1, 'var']
    opcode_dict['ADD'] = [3, 'var', 'symb', 'symb']
    opcode_dict['SUB'] = [3, 'var', 'symb', 'symb']
    opcode_dict['MUL'] = [3, 'var', 'symb', 'symb']
    opcode_dict['IDIV'] = [3, 'var', 'symb', 'symb']
    opcode_dict['LT'] = [3, 'var', 'symb', 'symb']
    opcode_dict['GT'] = [3, 'var', 'symb', 'symb']
    opcode_dict['EQ'] = [3, 'var', 'symb', 'symb']
    opcode_dict['AND'] = [3, 'var', 'symb', 'symb']
    opcode_dict['OR'] = [3, 'var', 'symb', 'symb']
    opcode_dict['NOT']= [3, 'var', 'symb', 'symb']
    opcode_dict['INT2CHAR'] = [2, 'var', 'symb']
    opcode_dict['STR2INT'] = [3, 'var', 'symb', 'symb']
    opcode_dict['READ'] = [2, 'var', 'type']
    opcode_dict['WRITE'] = [1, 'symb']
    opcode_dict['CONCAT'] = [3, 'var', 'symb', 'symb']
    opcode_dict['STRLEN'] = [2, 'var', 'symb']
    opcode_dict['GETCHAR'] = [3, 'var', 'symb', 'symb']
    opcode_dict['SETCHAR'] = [3, 'var', 'symb', 'symb']
    opcode_dict['TYPE'] = [2, 'var', 'symb']
    opcode_dict['LABEL'] = [1, 'label']
    opcode_dict['JUMP'] = [1, 'label']
    opcode_dict['JUMPIFEQ'] = [3, 'label', 'symb', 'symb']
    opcode_dict['JUMPIFNEQ'] = [3, 'label', 'symb', 'symb']
    opcode_dict['EXIT'] = [1, 'symb']
    opcode_dict['DPRINT'] = [1, 'symb']
    opcode_dict['BREAK'] = [0]

    def __init__(self):
        pass


class Instruction(InstructionDict):

    def __init__(self):
        super(InstructionDict, self).__init__()

    def Processing(self, instructions):
        #zkontroluje opcode,
        for i in range(0, len(instructions)):
            if instructions[i][0] in self.opcode_dict:
                instruction = instructions[i]
                expected_count = self.opcode_dict[instructions[i][0]][0]
                instructions[i] = self.__get_attribute(instruction, expected_count)
            else:
            #incorrect XML opcode
                sys.stderr.write("Invalid opcode\n")
                exit(32)
        return instructions

    def __get_attribute(self, instruction, expected_count):

        if(len(instruction)-1 == expected_count):
            tmplist = list()
            tmplist.insert(0, instruction[0])
            #serad argumenty
            for i in range(1, expected_count+1):
                if(instruction[i].tag == "arg1"):
                    tmplist.insert(1, [instruction[i].get('type'), instruction[i].text])
                if(instruction[i].tag == "arg2"):
                    tmplist.insert(2, [instruction[i].get('type'), instruction[i].text])
                if(instruction[i].tag == "arg3"):
                    tmplist.insert(3, [instruction[i].get('type'), instruction[i].text])
            #nahrad odkazy na argumenty dvojici [typ, hodnota]
            instruction = tmplist
            return instruction
        else:
            #incorrect XML opcode
            sys.stderr.write("Invalid count of arguments\n")
            exit(32)


class Attribute(InstructionDict):

    def __init__(self):
        super(InstructionDict, self).__init__()

    def Processing(self, instructions):
        print(instructions)

        for instruction in instructions:
            for i in range(1, len(instruction)):
                pointer_to_dict = self.opcode_dict[instruction[0]][i]
                type = instruction[i][0]
                value = str(instruction[i][1])

                if(pointer_to_dict == "var"):
                    self.__var(type, value)
                elif(pointer_to_dict == "symb"):
                    self.__symb(type, value)
                elif(pointer_to_dict == "label"):
                    self.__label(type, value)
                elif(pointer_to_dict == "type"):
                    self.__type(type, value)
                else:
                    sys.stderr.write("Invalid type of argument\n")
                    exit(50)


    def __var(self, type, value):
        #frame@special_characters or alphanumeric characters
        check = re.search('([\-\_\$\&\%\*\!\?\w]+)$', value)
        self.__check(check)

    def __symb(self, type, value):
        #frame@special_characters or alphanumeric characters
        if(type == "var"):
            check = re.search('(TF|LF|GF)@([\-\_\$\&\%\*\!\?\w]+)$', value)
            self.__check(check)

        if(type == "int"):
            check = re.search('([+-]?\d+)$', value)
            self.__check(check)

        if(type == "bool"):
            check = re.search('(true|false)$', value)
            self.__check(check)

        if(type == "string"):
            #frame@special_characters or alphanumeric characters or special escape sequences \[0-9][0-9][0-9]
            check = re.search('((\w*[\<\>\&\'\"\/\-\_]*(\\[0-9][0-9][0-9])*\w*)*)$', value)
            self.__check(check)

        if(type == "nil"):
            check = re.search('(nil)$', value)
            self.__check(check)

    def __label(self, type, value):
        check = re.search('(\w+)$', value)
        self.__check(check)

    def __type(self, type, value):
        check = re.search('(int|string|bool)$', value)
        self.__check(check)

    def __check(self,check):
        if(check == None):
            sys.stderr.write("Invalid value of argument\n")
            exit(50)
        else:
            return


class Processor():

    def __init__(self):
        pass


    def Interpret(self, source, input):
        self.__processing(source, input)


    def __processing(self, source, input):
        parseXML = ParseXML()
        instructions = parseXML.Parse(source)

        instruction = Instruction()
        instructions = instruction.Processing(instructions)
        attribute = Attribute()
        attribute.Processing(instructions)

"""
    udelat funkce pro instrukce a udelat ukladani do ramcu

"""

#Parameter --help
def PrintHelp():
    print("Napoveda ke skriptu interpret.py\n")
    print("Skript nacte XML reprezentaci programu ze zadaneho souboru pomoci STDIO,\n pote interpretuje a nasledne na STDOUT vypise odpovidajici vystup programu.\n")
    print("52 - chyba pri semantickych kontrolach vstupniho kodu v IPPcode19 (napr. pouziti nedefinovaneho navesti")
    print("53 - behova chyba interpretace – spatne typy operandu")
    print("54 - behova chyba interpretace – pristup k neexistujici promenne (ramec existuje)")
    print("55 - behova chyba interpretace – ramec neexistuje (napr. cteni z prazdneho zasobniku ramcu)")
    print("56 - behova chyba interpretace – chybejici hodnota (v promenne, na datovem zasobniku, nebo v zasobniku volani)")
    print("57 - behova chyba interpretace – spatna hodnota operandu (napr. deleni nulou, spatna navratova hodnota instrukce EXIT)")
    print("58 - behova chyba interpretace – chybna prace s retezcem")

if __name__ == "__main__":

    #Input Parameters
    isSource = False
    isInput = False
#    source = ""
#    input = ""

    if(len(sys.argv) == 2):
        if(sys.argv[1] == "--help"):
            PrintHelp()
            exit(0)

        source_list = re.search(r'(?<=--source=)(.+)', sys.argv[1])
        if(source_list):
            source = source_list.group(1)
            isSource = True
        input_list = re.search(r'(?<=--input=)(.+)', sys.argv[1])
        if(input_list):
            input = input_list.group(1)
            isInput = True

        if((isSource == False) & (isInput == False)):
            sys.stderr.write("Wrong input parameters\n")
            exit(10)

#        elif(isSource == True & isInput == False):
#            input = sys.stdin
#        elif(isInput == True & isSource == False):
#            source = sys.stdin

    elif(len(sys.argv) == 3):
        for item in sys.argv:
            source_list = re.search(r'(?<=--source=)(.+)', item)
            if(source_list):
                source = source_list.group(1)
                isSource = True

            input_list = re.search(r'(?<=--input=)(.+)', item)
            if(input_list):
                input = input_list.group(1)
                isInput = True

        if((isSource == False) | (isInput == False)):
            sys.stderr.write("Wrong input parameters\n")
            exit(10)
    else:
        sys.stderr.write("Wrong input parameters\n")
        exit(10)

    processor = Processor()
    out_code = processor.Interpret(source, input)
    exit(out_code)
